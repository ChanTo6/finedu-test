import { FieldConfig, FieldType } from 'shared-lib';

export interface CreateFieldRequest {
  order: number;
  type: FieldType;
  label: string;
  isRequired: boolean;
  config: FieldConfig;

  /** ჟიური ხედავს ამ ველის პასუხს. ნაგულისხმევად არა — პერსონალური მონაცემი მას არ ეხება. */
  visibleToJury: boolean;
}

export interface CreateFormRequest {
  title: string;
  description?: string | null;
  closeDate?: string | null;
  maxParticipants?: number | null;
  retentionDays: number;
  privacyNoticeHtml?: string | null;

  /** დასტურის წერილი — თითო კონკურსს თავისი ტექსტი (doc §3.5). ცარიელი = ნაგულისხმევი. */
  confirmationEmailSubject?: string | null;
  confirmationEmailBody?: string | null;

  /** `null` — ქავერი არ იცვლება; `''` — წაშლა; სახელი — ჩანაცვლება. */
  coverImagePath?: string | null;

  fields: CreateFieldRequest[];

  /** ფორმის ვერსია — მხოლოდ რედაქტირებისას (იხ. `FormDetail.rowVersion`). */
  rowVersion?: string | null;
}

export interface LoginResponse {
  token: string;
  user: string;
  roles: string[];
}

/** სერვერიდან გვერდებად დაბრუნებული სია (backend: `PagedResult<T>`). */
export interface PagedResult<T> {
  items: T[];
  page: number;
  pageSize: number;
  total: number;
  totalPages: number;
}

export interface SubmissionValue {
  fieldId: string;
  label: string;
  value?: string | null;
}

export interface SubmissionFile {
  id: string;
  fieldId: string;
  originalFileName: string;
  sizeBytes: number;
}

/** ერთი შემოსული განაცხადი (ადმინის ხედი). */
export interface Submission {
  id: string;
  submittedAt: string;
  consentDataProcessing: boolean;
  values: SubmissionValue[];
  files: SubmissionFile[];

  /** რამდენი განაცხადია ამავე მოწყობილობიდან (თავისი ჩათვლით). 1-ზე მეტი = ეჭვიანი. */
  sameDeviceCount: number;

  /** რამდენი განაცხადია ამავე ქსელიდან. საზიარო ქსელში (სკოლა, ბიბლიოთეკა) 1-ზე მეტი ნორმაა. */
  sameNetworkCount: number;
}
