using System.Text.RegularExpressions;
using FinEdu.Application.Common.Exceptions;

namespace FinEdu.Application.Forms;

/// <summary>
/// ქავერის ფაილის სახელის წესები — ერთ ადგილას, გვერდითი ეფექტების გარეშე.
///
/// <para>სახელს ჩვენ ვასახელებთ (GUID + სურათის გაფართოება) და კლიენტი მას მხოლოდ
/// გვიბრუნებს. სწორედ ამიტომ არის ფორმატის შემოწმება უსაფრთხოების ზომაც: მისი
/// გარეშე კლიენტს თვითნებური გზის შემოწოდება შეეძლებოდა.</para>
///
/// <para>წესები ორ ადგილას სჭირდება — ფორმის შენახვისას (რომელი სახელი ჩაიწეროს)
/// და ქავერის გაცემისას (რომელი ფაილი გაიხსნას) — ამიტომ არც ერთ სერვისში არ ცხოვრობს.</para>
/// </summary>
internal static class CoverName
{
    /// <summary>ზუსტად ის ფორმატი, რომელსაც <c>IFileStorage.SaveCoverAsync</c> გასცემს.</summary>
    private static readonly Regex Pattern =
        new("^[0-9a-f]{32}\\.(jpg|jpeg|png|gif)$", RegexOptions.IgnoreCase | RegexOptions.Compiled);

    /// <summary>ჩვენ მიერ გაცემული სახელია?</summary>
    public static bool IsStored(string? name) => name is not null && Pattern.IsMatch(name);

    /// <summary>
    /// კლიენტიდან მოსული სახელი. სამი შემთხვევა განზრახ განსხვავდება:
    /// <c>null</c> — ველი არ გამოგზავნილა (ძველი რჩება); ცარიელი სტრიქონი — ცხადი წაშლა;
    /// სახელი — მხოლოდ ჩვენ მიერ გაცემული ფორმატი მიიღება.
    /// </summary>
    public static string? Validated(string? coverName)
    {
        if (coverName is null) return null;

        var trimmed = coverName.Trim();
        if (trimmed.Length == 0) return string.Empty;

        if (!Pattern.IsMatch(trimmed))
            throw new ValidationException("coverImagePath", "ქავერის მისამართი არასწორია.");

        return trimmed;
    }

    /// <summary>შექმნისას ცარიელი და გამოტოვებული ერთი და იგივეა — ქავერი უბრალოდ არ არის.</summary>
    public static string? Normalized(string? coverName) =>
        Validated(coverName) is { Length: > 0 } name ? name : null;
}
