import { DatePipe } from '@angular/common';
import { Component, OnInit, computed, inject, input, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { Observable } from 'rxjs';
import { apiErrorMessage } from 'shared-lib';
import { AccessLevel, FormAccess } from '../../core/models/form-access';
import { FormAccessService } from '../../core/services/form-access.service';
import { FormsService } from '../../core/services/forms.service';

/**
 * ვის აქვს ამ კონკურსზე წვდომა.
 *
 * ეს **მომხმარებლების მართვა არ არის**: ანგარიშები, პაროლები და ჯგუფები AD-შია და
 * აქედან არც იქმნება და არც იშლება. აქ მხოლოდ ერთი კავშირი ინახება — „ამ AD ანგარიშს
 * ამ კონკურსზე ეს დონე აქვს". სწორედ ეს აძლევს მოდერატორს სხვისი კონკურსის მართვის
 * საშუალებას, ადმინისტრატორის უფლებების მიცემის გარეშე.
 */
@Component({
  selector: 'app-form-access',
  imports: [RouterLink, FormsModule, DatePipe],
  templateUrl: './form-access.html',
  styleUrl: './form-access.scss',
})
export class FormAccessPage implements OnInit {
  private readonly service = inject(FormAccessService);
  private readonly forms = inject(FormsService);

  /** route-იდან: /forms/:id/access */
  readonly id = input.required<string>();

  readonly AccessLevel = AccessLevel;

  readonly formTitle = signal('');
  readonly entries = signal<FormAccess[]>([]);
  readonly loading = signal(true);
  readonly error = signal('');
  readonly notice = signal('');
  readonly saving = signal(false);
  readonly busyId = signal('');

  readonly managers = computed(() =>
    this.entries().filter((e) => e.accessLevel === AccessLevel.Manager),
  );

  account = '';
  level: AccessLevel = AccessLevel.Manager;

  ngOnInit(): void {
    this.forms.get(this.id()).subscribe({ next: (f) => this.formTitle.set(f.title) });
    this.load();
  }

  load(): void {
    this.service.list(this.id()).subscribe({
      next: (list) => {
        this.entries.set(list);
        this.loading.set(false);
      },
      error: (e) => {
        this.error.set(apiErrorMessage(e, 'წვდომების სია ვერ ჩაიტვირთა.'));
        this.loading.set(false);
      },
    });
  }

  grant(): void {
    const account = this.account.trim();
    if (this.saving() || !account) return;

    this.error.set('');
    this.notice.set('');
    this.saving.set(true);

    this.service.grant(this.id(), { adAccount: account, accessLevel: this.level }).subscribe({
      next: () => {
        this.notice.set(`წვდომა მიენიჭა: ${account}`);
        this.account = '';
        this.saving.set(false);
        this.load();
      },
      error: (e) => {
        this.error.set(apiErrorMessage(e, 'წვდომის მინიჭება ვერ მოხერხდა.'));
        this.saving.set(false);
      },
    });
  }

  revoke(entry: FormAccess): void {
    if (!confirm(`მოვხსნათ წვდომა: ${entry.adAccount}?`)) return;

    this.run(
      entry.id,
      this.service.revoke(this.id(), entry.id),
      `წვდომა მოიხსნა: ${entry.adAccount}`,
    );
  }

  levelLabel(level: AccessLevel): string {
    return level === AccessLevel.Manager ? 'მმართველი' : 'დამკვირვებელი';
  }

  private run(id: string, request: Observable<void>, done: string): void {
    if (this.busyId()) return;

    this.error.set('');
    this.notice.set('');
    this.busyId.set(id);

    request.subscribe({
      next: () => {
        this.notice.set(done);
        this.busyId.set('');
        this.load();
      },
      error: (e) => {
        this.error.set(apiErrorMessage(e, 'მოქმედება ვერ შესრულდა.'));
        this.busyId.set('');
      },
    });
  }
}
