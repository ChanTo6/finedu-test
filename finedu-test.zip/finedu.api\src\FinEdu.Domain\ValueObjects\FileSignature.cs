namespace FinEdu.Domain.ValueObjects;

/// <summary>
/// ფაილის ხელმოწერის (magic bytes) შემოწმება — გაფართოება ადვილად გადასარქმევია,
/// ამიტომ შიგთავსიც უნდა შეესაბამებოდეს გამოცხადებულ ტიპს.
/// დამოკიდებულების გარეშეა განზრახ: ტიპების ნაკრები მცირეა და ფიქსირებული,
/// გარე ბიბლიოთეკა ზედმეტ თავდასხმის ზედაპირს დაამატებდა.
/// </summary>
public static class FileSignature
{
    /// <summary>რამდენი ბაიტი გვჭირდება ხელმოწერის დასადგენად.</summary>
    public const int HeaderBytes = 12;

    private static readonly byte[] Pdf = "%PDF"u8.ToArray();
    private static readonly byte[] Zip = [0x50, 0x4B];                                // docx/xlsx/pptx
    private static readonly byte[] Ole = [0xD0, 0xCF, 0x11, 0xE0, 0xA1, 0xB1, 0x1A, 0xE1]; // doc/xls/ppt
    private static readonly byte[] Jpeg = [0xFF, 0xD8, 0xFF];
    private static readonly byte[] Png = [0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A];
    private static readonly byte[] Gif87 = "GIF87a"u8.ToArray();
    private static readonly byte[] Gif89 = "GIF89a"u8.ToArray();
    private static readonly byte[] Riff = "RIFF"u8.ToArray();
    private static readonly byte[] Avi = "AVI "u8.ToArray();
    private static readonly byte[] Ftyp = "ftyp"u8.ToArray();                          // mp4/mov (offset 4)

    /// <summary>ემთხვევა თუ არა ფაილის დასაწყისი გაფართოებით გამოცხადებულ ტიპს.</summary>
    public static bool Matches(string extension, ReadOnlySpan<byte> header) => extension switch
    {
        "pdf" => Starts(header, Pdf),
        "docx" or "xlsx" or "pptx" => Starts(header, Zip),
        "doc" or "xls" or "ppt" => Starts(header, Ole),
        "jpg" or "jpeg" => Starts(header, Jpeg),
        "png" => Starts(header, Png),
        "gif" => Starts(header, Gif87) || Starts(header, Gif89),
        "avi" => Starts(header, Riff) && At(header, 8, Avi),
        "mp4" or "mov" => At(header, 4, Ftyp),
        _ => false
    };

    /// <summary>
    /// იგივე შემოწმება პირდაპირ ნაკადზე — თავსართს კითხულობს და პოზიციას აღადგენს,
    /// რომ შემდეგ ფაილი მთლიანად ჩაიწეროს.
    /// ნაკადი თუ არ არის seekable, <c>true</c> ბრუნდება — ClamAV რჩება მეორე ბარიერად.
    /// </summary>
    public static bool MatchesStream(string extension, Stream content)
    {
        if (!content.CanSeek) return true;

        var buffer = new byte[HeaderBytes];
        var origin = content.Position;
        try
        {
            content.Position = 0;
            var read = content.Read(buffer, 0, buffer.Length);
            return Matches(extension, buffer.AsSpan(0, read));
        }
        finally
        {
            content.Position = origin;
        }
    }

    private static bool Starts(ReadOnlySpan<byte> header, ReadOnlySpan<byte> prefix) =>
        header.Length >= prefix.Length && header[..prefix.Length].SequenceEqual(prefix);

    private static bool At(ReadOnlySpan<byte> header, int offset, ReadOnlySpan<byte> value) =>
        header.Length >= offset + value.Length && header.Slice(offset, value.Length).SequenceEqual(value);
}
