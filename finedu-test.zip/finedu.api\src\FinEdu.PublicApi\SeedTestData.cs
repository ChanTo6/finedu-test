using FinEdu.Domain.Entities;
using FinEdu.Domain.Enums;
using FinEdu.Domain.ValueObjects;
using FinEdu.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;

namespace FinEdu.PublicApi;

/// <summary>
/// სატესტო კონკურსები — ცარიელ ბაზაზე გაშვებისას ავტომატურად ჩაიწერება.
/// ამ ფაილის წაშლით seed მონაცემები ავტომატურად გაითიშება.
/// </summary>
public static class SeedTestData
{
    public static async Task RunAsync(IServiceProvider services)
    {
        using var scope = services.CreateScope();
        var db = scope.ServiceProvider.GetRequiredService<AppDbContext>();

        if (await db.Forms.AnyAsync())
            return;

        var now = DateTimeOffset.UtcNow;

        // ── 1. ფინანსური განათლების ესეების კონკურსი (Live) ──────────

        var essay = new Form
        {
            Title = "ფინანსური განათლების ესეების კონკურსი 2026",
            TitleHtml = "<b>ფინანსური განათლების</b> ესეების კონკურსი 2026",
            Description = "მოსწავლეებისთვის ფინანსური წიგნიერების თემაზე ესეების კონკურსი. მონაწილეობა შეუძლია X–XII კლასის მოსწავლეს.",
            CloseDate = now.AddDays(30),
            MaxParticipants = 500,
            RetentionDays = 90,
            Status = FormStatus.Live,
            ApprovedBy = "test",
            ApprovedAt = now.AddDays(-2),
            PrivacyNoticeHtml = "<p>თქვენი პერსონალური მონაცემები (სახელი, გვარი, ელ. ფოსტა, სასწავლო დაწესებულება) მუშავდება კონკურსის ჩატარების მიზნით და ინახება კონკურსის დასრულებიდან 90 დღის განმავლობაში.</p>",
            ConfirmationEmailSubject = "ესეების კონკურსი — განაცხადი მიღებულია",
            ConfirmationEmailBody = "<p>მადლობა კონკურსში მონაწილეობისთვის! თქვენი ესე მიღებულია და განიხილება.</p>",
        };
        essay.AccessList.Add(new FormAccess { AdAccount = "test", AccessLevel = AccessLevel.Manager });

        essay.Fields.Add(new FormField
        {
            FormId = essay.Id, Order = 1, Type = FieldType.ShortAnswer,
            Label = "სახელი და გვარი", IsRequired = true,
            Config = new FieldConfig { MaxWords = 5 }
        });
        essay.Fields.Add(new FormField
        {
            FormId = essay.Id, Order = 2, Type = FieldType.ShortAnswer,
            Label = "ელ. ფოსტა", IsRequired = true,
            Config = new FieldConfig { MaxWords = 5 }
        });
        essay.Fields.Add(new FormField
        {
            FormId = essay.Id, Order = 3, Type = FieldType.ShortAnswer,
            Label = "სასწავლო დაწესებულება", IsRequired = true,
            Config = new FieldConfig { MaxWords = 20 }
        });
        essay.Fields.Add(new FormField
        {
            FormId = essay.Id, Order = 4, Type = FieldType.MultipleChoice,
            Label = "კლასი", IsRequired = true,
            Config = new FieldConfig { Options = ["X კლასი", "XI კლასი", "XII კლასი"] }
        });
        essay.Fields.Add(new FormField
        {
            FormId = essay.Id, Order = 5, Type = FieldType.LongAnswer,
            Label = "ესე — რატომ არის მნიშვნელოვანი ფინანსური წიგნიერება", IsRequired = true,
            Config = new FieldConfig { MaxWords = 500 }
        });

        // ── 2. ტრენინგზე რეგისტრაცია (Live) ────────────────────────

        var training = new Form
        {
            Title = "ტრენინგი — საბანკო ზედამხედველობის საფუძვლები",
            TitleHtml = "ტრენინგი — <b>საბანკო ზედამხედველობის საფუძვლები</b>",
            Description = "ორდღიანი ტრენინგი კომერციული ბანკების თანამშრომლებისთვის. ტრენინგი ჩატარდება სებ-ის სასწავლო ცენტრში.",
            CloseDate = now.AddDays(14),
            MaxParticipants = 50,
            RetentionDays = 60,
            Status = FormStatus.Live,
            ApprovedBy = "test",
            ApprovedAt = now.AddDays(-1),
            PrivacyNoticeHtml = "<p>თქვენი მონაცემები გამოიყენება ტრენინგზე რეგისტრაციის მიზნით. მონაცემები ინახება 60 დღე.</p>",
        };
        training.AccessList.Add(new FormAccess { AdAccount = "test", AccessLevel = AccessLevel.Manager });

        training.Fields.Add(new FormField
        {
            FormId = training.Id, Order = 1, Type = FieldType.ShortAnswer,
            Label = "სახელი და გვარი", IsRequired = true,
            Config = new FieldConfig { MaxWords = 5 }
        });
        training.Fields.Add(new FormField
        {
            FormId = training.Id, Order = 2, Type = FieldType.ShortAnswer,
            Label = "ელ. ფოსტა", IsRequired = true,
            Config = new FieldConfig { MaxWords = 5 }
        });
        training.Fields.Add(new FormField
        {
            FormId = training.Id, Order = 3, Type = FieldType.ShortAnswer,
            Label = "ორგანიზაცია / ბანკი", IsRequired = true,
            Config = new FieldConfig { MaxWords = 10 }
        });
        training.Fields.Add(new FormField
        {
            FormId = training.Id, Order = 4, Type = FieldType.ShortAnswer,
            Label = "თანამდებობა", IsRequired = true,
            Config = new FieldConfig { MaxWords = 10 }
        });
        training.Fields.Add(new FormField
        {
            FormId = training.Id, Order = 5, Type = FieldType.MultipleChoice,
            Label = "რომელ დღეს ესწრებით?", IsRequired = true,
            Config = new FieldConfig { Options = ["მხოლოდ I დღე", "მხოლოდ II დღე", "ორივე დღე"] }
        });
        training.Fields.Add(new FormField
        {
            FormId = training.Id, Order = 6, Type = FieldType.Checkboxes,
            Label = "რა თემები გაინტერესებთ?", IsRequired = false,
            Config = new FieldConfig { Options = ["საკრედიტო რისკი", "ლიკვიდობის რისკი", "საოპერაციო რისკი", "კაპიტალის ადეკვატურობა"] }
        });

        // ── 3. დახურული კონკურსი (Closed) ───────────────────────────

        var closed = new Form
        {
            Title = "ეროვნული ბანკის ლოგოს დიზაინის კონკურსი",
            Description = "კონკურსი დასრულებულია. გამარჯვებული გამოვლინდა 2026 წლის სექტემბერში.",
            CloseDate = now.AddDays(-10),
            RetentionDays = 180,
            Status = FormStatus.Closed,
            ApprovedBy = "test",
            ApprovedAt = now.AddDays(-40),
            PrivacyNoticeHtml = "<p>მონაცემები ინახება კონკურსის შედეგების გამოქვეყნებამდე.</p>",
        };
        closed.AccessList.Add(new FormAccess { AdAccount = "test", AccessLevel = AccessLevel.Manager });

        closed.Fields.Add(new FormField
        {
            FormId = closed.Id, Order = 1, Type = FieldType.ShortAnswer,
            Label = "ავტორის სახელი და გვარი", IsRequired = true
        });
        closed.Fields.Add(new FormField
        {
            FormId = closed.Id, Order = 2, Type = FieldType.FileUpload,
            Label = "ლოგოს ფაილი", IsRequired = true,
            Config = new FieldConfig
            {
                MaxFiles = 1,
                AllowedExtensions = [".pdf", ".png", ".jpg"],
                MaxFileSizeBytes = 10 * 1024 * 1024
            }
        });
        closed.Fields.Add(new FormField
        {
            FormId = closed.Id, Order = 3, Type = FieldType.LongAnswer,
            Label = "კონცეფციის აღწერა", IsRequired = true,
            Config = new FieldConfig { MaxWords = 300 }
        });

        db.Forms.AddRange(essay, training, closed);
        await db.SaveChangesAsync();
    }
}
