﻿namespace FinEdu.Infrastructure.Options;

public class StorageOptions
{
    public string QuarantinePath { get; set; } = "";   // web-root-ის გარეთ
    public string PermanentPath { get; set; } = "";     // web-root-ის გარეთ

    /// <summary>
    /// ქავერ ფოტოები — ესეც web-root-ის გარეთ ინახება, მაგრამ ცალკე საქაღალდეში:
    /// ქავერი საჯაროდ გაიცემა, განაცხადების ფაილები კი — არა.
    /// </summary>
    public string CoverPath { get; set; } = "";
}

public class SmtpOptions
{
    public string Host { get; set; } = "";
    public int Port { get; set; } = 25;
    public string From { get; set; } = "donotreply@finedu.gov.ge";
    public string? User { get; set; }
    public string? Password { get; set; }

    /// <summary>ნაგულისხმევად ჩართული — გამორთვა მხოლოდ ლოკალურ smtp4dev-თან აზრიანია.</summary>
    public bool UseStartTls { get; set; } = true;

    /// <summary>
    /// მაქსიმალური ლოდინი წერილის გაგზავნაზე. წერილი HTTP მოთხოვნის შიგნით იგზავნება
    /// (ჟიურის დამატება, დადასტურება, განაცხადის ავტო-პასუხი), MailKit-ის ნაგულისხმევი
    /// 2 წუთი კი ნიშნავს, რომ „ჩაკიდებული" relay-ს დროს თითოეული მოთხოვნა ორ წუთს
    /// იკავებდა thread-ს — რამდენიმე ასეთი და სერვისი მთლიანად წყვეტდა პასუხს.
    /// ჩავარდნა ისედაც არ აუქმებს მოქმედებას: ის ლოგდება და ადმინს „ხელახლა გაგზავნა" აქვს.
    /// </summary>
    public int TimeoutSeconds { get; set; } = 30;
}

public class LdapOptions
{
    public string Host { get; set; } = "";

    /// <summary>636 = LDAPS. 389 მხოლოდ StartTls-თან ერთად დასაშვები.</summary>
    public int Port { get; set; } = 636;

    public string? UserDnFormat { get; set; }   // მაგ. "{0}@finedu.gov.ge" ან "CN={0},OU=..,DC=.."
    public string BaseDn { get; set; } = "";
    /// <summary>AD ჯგუფი, რომელიც <c>Administrator</c> როლს იძლევა (მაგ. FinEdu-Admins).</summary>
    public string AdminGroup { get; set; } = "";

    /// <summary>
    /// AD ჯგუფი, რომელიც <c>Moderator</c> როლს იძლევა (მაგ. FinEdu-Users).
    ///
    /// <para>სახელი განზრახ დარჩა <c>StandardGroup</c>: ეს კონფიგურაციის გასაღებია და
    /// უკვე განლაგებულ გარემოებში ეწერება. გადარქმევისას ძველი გასაღები ჩუმად
    /// გამოტოვდებოდა — ჯგუფი ცარიელი დარჩებოდა და მოდერატორები შეუმჩნევლად
    /// დაკარგავდნენ წვდომას. AD ჯგუფის *რეალური* სახელი აქ იწერება და არ იცვლება.</para>
    /// </summary>
    public string StandardGroup { get; set; } = "";

    /// <summary>LDAPS — არხი დაშიფრულია bind-ამდე. ნაგულისხმევი და რეკომენდებული.</summary>
    public bool UseSsl { get; set; } = true;

    /// <summary>StartTls — ალტერნატივა 389 პორტზე, bind-ამდე არხს შიფრავს.</summary>
    public bool UseStartTls { get; set; }

    /// <summary>
    /// მხოლოდ ლოკალური dev-ისთვის: LDAP დაუშიფრავად. პროდაქშენში აპლიკაცია არ აეშვება,
    /// თუ ჩართულია — პაროლები ღია ტექსტით წავიდოდა ქსელში.
    /// </summary>
    public bool AllowUnencrypted { get; set; }
}

