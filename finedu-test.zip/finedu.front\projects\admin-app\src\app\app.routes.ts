import { Routes } from '@angular/router';
import { authGuard } from './core/guards/auth-guard';

export const routes: Routes = [
  {
    path: 'login',
    loadComponent: () => import('./features/auth/login').then((m) => m.Login),
  },
  {
    path: 'forms',
    canActivate: [authGuard],
    loadComponent: () => import('./features/forms-list/forms-list').then((m) => m.FormsList),
  },
  {
    path: 'forms/new',
    canActivate: [authGuard],
    loadComponent: () =>
      import('./features/form-builder/form-builder').then((m) => m.FormBuilderPage),
  },
  {
    path: 'forms/:id/edit',
    canActivate: [authGuard],
    loadComponent: () =>
      import('./features/form-builder/form-builder').then((m) => m.FormBuilderPage),
  },
  {
    path: 'forms/:id/submissions',
    canActivate: [authGuard],
    loadComponent: () => import('./features/submissions/submissions').then((m) => m.Submissions),
  },
  {
    path: 'forms/:id/access',
    canActivate: [authGuard],
    loadComponent: () => import('./features/form-access/form-access').then((m) => m.FormAccessPage),
  },
  {
    // Excel-ის ექსპორტში ფაილების ბმულები აქ მოდის
    path: 'files/:id',
    canActivate: [authGuard],
    loadComponent: () =>
      import('./features/file-download/file-download').then((m) => m.FileDownload),
  },
  { path: '', redirectTo: 'forms', pathMatch: 'full' },
  { path: '**', redirectTo: 'forms' },
];
