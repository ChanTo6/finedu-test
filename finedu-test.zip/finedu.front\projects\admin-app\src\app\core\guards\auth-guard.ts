import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { AuthService } from '../services/auth.service';

/**
 * შესვლის შემდეგ მომხმარებელი იქ უნდა დაბრუნდეს, საითაც მიდიოდა. მნიშვნელობა
 * Excel-ის ფაილურ ბმულებს შემატა: ისინი პირდაპირ `/files/:id`-ზე მიდის და
 * `/forms`-ზე გადაგდება ჩამოტვირთვას კარგავდა.
 */
export const authGuard: CanActivateFn = (_route, state) => {
  const auth = inject(AuthService);
  const router = inject(Router);

  return (
    auth.isLoggedIn() || router.createUrlTree(['/login'], { queryParams: { returnUrl: state.url } })
  );
};
