import { Pipe, PipeTransform, inject } from '@angular/core';
import { DomSanitizer, SafeHtml } from '@angular/platform-browser';

/**
 * ადმინის მიერ დაწერილი გაფორმებული ტექსტის ჩვენება.
 *
 * <p>Angular-ის საკუთარი გამწმენდი `[innerHTML]`-ზე `style` ატრიბუტს <b>ყოველთვის</b>
 * ჭრის — ანუ ფერი და ასოს ზომა უბრალოდ გაქრებოდა. ამიტომ აქ ის გვერდის ავლით
 * გადის, ხოლო დაცვა სერვერზეა: ტექსტი შენახვისას allowlist-ით იწმინდება
 * (backend `IHtmlContent`), ანუ ბაზაში დაუშვებელი ტეგი ვერ ხვდება.</p>
 *
 * <p>ამიტომ ეს pipe მხოლოდ სერვერიდან მოსულ, უკვე გაწმენდილ ტექსტზე გამოიყენება —
 * მომხმარებლის შეყვანილ ტექსტზე არასდროს.</p>
 */
@Pipe({ name: 'trustedHtml' })
export class TrustedHtmlPipe implements PipeTransform {
  private readonly sanitizer = inject(DomSanitizer);

  transform(html: string | null | undefined): SafeHtml {
    return this.sanitizer.bypassSecurityTrustHtml(html ?? '');
  }
}
