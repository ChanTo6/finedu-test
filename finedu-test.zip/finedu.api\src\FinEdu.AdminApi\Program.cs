﻿using System.Globalization;
using System.Threading.RateLimiting;
using FinEdu.AdminApi;
using FinEdu.AdminApi.Common;
using FinEdu.Application;
using FinEdu.Application.Common.Interfaces;
using FinEdu.Infrastructure;
using FinEdu.Infrastructure.Http;
using FinEdu.Infrastructure.Identity;
using Microsoft.AspNetCore.RateLimiting;
using Serilog;

// ადმინის პანელი მხოლოდ ქართულია. ამის გარეშე ინგლისურ Windows-ზე საერთო შეტყობინებები
// (Messages.en.resx) ინგლისურად დაბრუნდებოდა — ენას სერვერის სისტემური პარამეტრი აირჩევდა.
CultureInfo.DefaultThreadCurrentUICulture = CultureInfo.GetCultureInfo("ka");

var builder = WebApplication.CreateBuilder(args);

builder.Host.UseSerilog((ctx, cfg) => cfg.ReadFrom.Configuration(ctx.Configuration).WriteTo.Console());

builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

builder.Services.AddApplication();
builder.Services.AddInfrastructure(builder.Configuration);
builder.Services.AddHttpContextAccessor();
builder.Services.AddScoped<ICurrentUser, HttpContextCurrentUser>();

builder.Services.AddFinEduJwtAuth(builder.Configuration, builder.Environment);
builder.Services.AddFinEduForwardedHeaders(builder.Configuration);
builder.Services.AddFinEduCors(builder.Configuration);
builder.Services.AddFinEduHealthChecks();

// ბრუტ-ფორსის შეზღუდვა login-ზე — თითო IP-ზე
builder.Services.AddRateLimiter(o =>
{
    o.RejectionStatusCode = StatusCodes.Status429TooManyRequests;
    o.AddPolicy("login", ctx => RateLimitPartition.GetFixedWindowLimiter(
        WebSetup.ClientKey(ctx),
        _ => new FixedWindowRateLimiterOptions
        {
            Window = TimeSpan.FromMinutes(5),
            PermitLimit = 10,
            QueueLimit = 0
        }));
});

var app = builder.Build();

app.UseForwardedHeaders();

// Swagger მხოლოდ Development-ში — პროდაქშენში API-ს რუკას არ ვაქვეყნებთ
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}
else
{
    app.UseHsts();
}

// noStore: ადმინის ყველა პასუხი პერსონალურ მონაცემებს შეიცავს — არსად არ უნდა დაიკეშოს
app.UseSecurityHeaders(noStore: true);

app.UseDbRequestLogging();

app.UseFinEduExceptionHandling();
app.UseHttpsRedirection();
app.UseCors();
app.UseRateLimiter();
app.UseDefaultFiles();
app.UseStaticFiles();
app.UseAuthentication();
app.UseAuthorization();
app.MapControllers();
app.MapFinEduHealthChecks();
app.MapFallbackToFile("index.html").AllowAnonymous();

// დროებითი: სადემონსტრაციო კონკურსები (მხოლოდ Development).
// ამ ხაზს წაშლით DemoDataSeeder.cs-თან ერთად — სხვა არაფერია დასამატებელი.
await app.SeedDemoDataAsync();

app.Run();

// WebApplicationFactory-ს საჯარო Program ტიპი სჭირდება (top-level statements-ით ის internal-ია).
public partial class Program;
