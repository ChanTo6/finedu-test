﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace FinEdu.Infrastructure.Persistence.Migrations
{
    /// <inheritdoc />
    public partial class AddHttpRequestLogs : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "HttpRequestLogs",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    Timestamp = table.Column<DateTimeOffset>(type: "datetimeoffset", nullable: false),
                    Method = table.Column<string>(type: "nvarchar(10)", maxLength: 10, nullable: false),
                    Path = table.Column<string>(type: "nvarchar(2000)", maxLength: 2000, nullable: false),
                    StatusCode = table.Column<int>(type: "int", nullable: false),
                    ElapsedMs = table.Column<long>(type: "bigint", nullable: false),
                    IpAddress = table.Column<string>(type: "nvarchar(64)", maxLength: 64, nullable: true),
                    VisitorId = table.Column<string>(type: "nvarchar(64)", maxLength: 64, nullable: true),
                    UserAgent = table.Column<string>(type: "nvarchar(512)", maxLength: 512, nullable: true),
                    Exception = table.Column<string>(type: "nvarchar(4000)", maxLength: 4000, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_HttpRequestLogs", x => x.Id);
                });

            migrationBuilder.CreateIndex(
                name: "IX_HttpRequestLogs_IpAddress",
                table: "HttpRequestLogs",
                column: "IpAddress");

            migrationBuilder.CreateIndex(
                name: "IX_HttpRequestLogs_StatusCode",
                table: "HttpRequestLogs",
                column: "StatusCode");

            migrationBuilder.CreateIndex(
                name: "IX_HttpRequestLogs_Timestamp",
                table: "HttpRequestLogs",
                column: "Timestamp");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "HttpRequestLogs");
        }
    }
}
