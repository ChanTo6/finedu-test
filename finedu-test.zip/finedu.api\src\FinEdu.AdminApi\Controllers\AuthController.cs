﻿using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using FinEdu.Application.Common.Audit;
using FinEdu.Application.Common.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.RateLimiting;

namespace FinEdu.AdminApi.Controllers;

[ApiController]
[Route("api/auth")]
[EnableRateLimiting("login")]   // ბრუტ-ფორსის დაცვა
public class AuthController(
    IAdAuthenticator ad,
    ITokenService tokens,
    ITokenRevocationStore revoked,
    IAuditLogger audit) : ControllerBase
{
    /// <summary>AD/LDAP login → JWT.</summary>
    [HttpPost("login")]
    [AllowAnonymous]   // ერთადერთი გზა ტოკენის მისაღებად — FallbackPolicy-ს გამონაკლისი
    public async Task<IActionResult> Login([FromBody] LoginRequest request, CancellationToken ct)
    {
        var user = await ad.AuthenticateAsync(request.Username, request.Password, ct);
        if (user is null)
        {
            // წარუმატებელი მცდელობაც აუდიტში — ბრუტ-ფორსის კვალი უნდა ჩანდეს.
            // actor = ვის სახელზეც სცადეს: ერთი ანგარიშის ირგვლივ მცდელობები ასე ერთად ჩანს.
            await audit.LogForActorAsync(request.Username, AuditActions.LoginFailed, "Auth", ct: ct);
            return Unauthorized(new { message = "მომხმარებელი ან პაროლი არასწორია." });
        }

        // შესვლისას JWT ჯერ არ არსებობს, ანუ ICurrentUser ცარიელია — actor ხელით მიეთითება
        await audit.LogForActorAsync(user.Account, AuditActions.LoginSucceeded, "Auth", ct: ct);
        return Ok(new { token = tokens.Create(user), user = user.DisplayName, roles = user.Roles });
    }

    /// <summary>Logout — ტოკენი მაშინვე უქმდება სერვერზე, ვადის ამოწურვას აღარ ელოდება.</summary>
    [HttpPost("logout")]
    [Authorize]
    public async Task<IActionResult> Logout(CancellationToken ct)
    {
        var jti = User.FindFirstValue(JwtRegisteredClaimNames.Jti);
        var exp = User.FindFirstValue(JwtRegisteredClaimNames.Exp);

        if (jti is not null && long.TryParse(exp, out var unix))
            await revoked.RevokeAsync(jti, DateTimeOffset.FromUnixTimeSeconds(unix), ct);

        await audit.LogAsync(AuditActions.Logout, "Auth", null, User.Identity?.Name, ct);
        return NoContent();
    }
}

public record LoginRequest(string Username, string Password);
