﻿using FinEdu.Domain.Common;
using FinEdu.Domain.Enums;

namespace FinEdu.Domain.Entities;

/// <summary>ერთი შევსებული ფორმა + GDPR თანხმობები.</summary>
public class Submission : BaseEntity
{
    public Guid FormId { get; set; }
    public Form? Form { get; set; }

    public DateTimeOffset SubmittedAt { get; set; } = DateTimeOffset.UtcNow;
    public SubmissionStatus Status { get; set; } = SubmissionStatus.Pending;

    // GDPR (doc §4.1)
    public bool ConsentDataProcessing { get; set; }        // სავალდებულო

    /// <summary>ავტო-პასუხისთვის. personal data — retention-ზე ავტომატურად იშლება.</summary>
    public string? NotificationEmail { get; set; }

    /// <summary>
    /// ბრაუზერის ანონიმური ნიშანი (cookie). ვინაობას არ ადგენს — გაორმაგებული განაცხადის
    /// ამოცნობასა და შემდგომ კვალის აღდგენას ემსახურება.
    /// განზრახ *განაცხადზე* ინახება და არა მხოლოდ აუდიტში: ჟურნალის კითხვა აპლიკაციას
    /// აკრძალული აქვს, ანუ დუბლიკატს ჟურნალიდან ვერ იპოვიდა.
    /// </summary>
    public string? VisitorId { get; set; }

    /// <summary>საიდან გამოიგზავნა. retention-ის წაშლისას განაცხადთან ერთად ქრება.</summary>
    public string? SubmitterIp { get; set; }

    /// <summary>ბრაუზერის ხელწერა — ბოტების ამოცნობის ერთადერთი მინიშნება ვინაობის შემოწმების გარეშე.</summary>
    public string? UserAgent { get; set; }

    public ICollection<SubmissionValue> Values { get; set; } = new List<SubmissionValue>();
    public ICollection<SubmissionFile> Files { get; set; } = new List<SubmissionFile>();

    /// <summary>ჟიურის ქულები ამ განაცხადზე. retention-ის წაშლისას განაცხადთან ერთად ქრება.</summary>
    public ICollection<Evaluation> Evaluations { get; set; } = new List<Evaluation>();
}
