using System.Text.RegularExpressions;
using Microsoft.AspNetCore.Http;

namespace FinEdu.Infrastructure.Http;

/// <summary>
/// ჟურნალში ჩასაწერი მისამართი — ბმულის საიდუმლო ნაწილის გარეშე.
///
/// <para>ჟიურის <c>accessToken</c> URL-ის ნაწილია (<c>/api/jury/{token}</c>) და
/// ორფაქტორიანი წვდომის ერთი ნახევარია. მისამართი კი ორ ადგილას იწერება: access-ლოგში
/// (90 დღე ინახება) და შეცდომების ჩანაწერებში — ანუ ყოველი წარუმატებელი შესვლა
/// token-ს ღია ტექსტით ტოვებდა ფაილში.</para>
///
/// <para>ლოგებზე წვდომა ბევრად უფრო ფართოა, ვიდრე ბაზაზე (ოპერაციები, backup, log
/// shipping, SIEM) — ანუ ის, რასაც ბაზაში hash-ად ვინახავთ, ჟურნალში ღიად ვერ დაწერება.
/// ჩანაწერისთვის სრულიად საკმარისია ის ფაქტი, რომ მიმართვა ჟიურის endpoint-ზე იყო;
/// „ვინ" კითხვას აუდიტის ჟურნალი პასუხობს (<c>jury.login.failed</c> ჟიურის მეილით).</para>
/// </summary>
public static class LogSafePath
{
    /// <summary>
    /// მხოლოდ hex-სეგმენტი <c>/api/jury/</c>-ის შემდეგ: გაცემული token ყოველთვის
    /// 64 hex სიმბოლოა. ასე მარშრუტების სახელები (<c>logout</c>, <c>submissions</c>,
    /// <c>files</c>) ხელუხლებელი რჩება, ხოლო აშკარად მოგონილი მნიშვნელობა ჟურნალში
    /// ისევ ჩანს — ის გამოძიებისთვის სასარგებლოა და საიდუმლოს არ შეიცავს.
    /// </summary>
    private static readonly Regex JuryAccessToken =
        new("(?<=^/api/jury/)[0-9a-fA-F]{16,}", RegexOptions.Compiled);

    public static string Of(PathString path) => Mask(path.Value);

    public static string Mask(string? path) =>
        string.IsNullOrEmpty(path) ? string.Empty : JuryAccessToken.Replace(path, "***");
}
