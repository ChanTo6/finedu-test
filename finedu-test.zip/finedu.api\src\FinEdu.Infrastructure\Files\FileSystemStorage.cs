﻿using FinEdu.Application.Common.Interfaces;
using FinEdu.Infrastructure.Options;
using Microsoft.Extensions.Options;

namespace FinEdu.Infrastructure.Files;

/// <summary>ფაილსაცავი web-root-ის გარეთ. quarantine → (scan) → permanent.</summary>
public class FileSystemStorage : IFileStorage
{
    private readonly StorageOptions _opts;

    public FileSystemStorage(IOptions<StorageOptions> opts)
    {
        _opts = opts.Value;
        Directory.CreateDirectory(_opts.QuarantinePath);
        Directory.CreateDirectory(_opts.PermanentPath);
        if (!string.IsNullOrWhiteSpace(_opts.CoverPath))
            Directory.CreateDirectory(_opts.CoverPath);
    }

    /// <summary>აბრუნებს მხოლოდ ფაილის სახელს — სრული გზა სისტემის შიგნით რჩება.</summary>
    public async Task<string> SaveCoverAsync(Stream content, string fileName, CancellationToken ct = default)
    {
        var safeName = $"{Guid.NewGuid():N}{Path.GetExtension(fileName).ToLowerInvariant()}";
        var path = Path.Combine(_opts.CoverPath, safeName);
        await using var fs = new FileStream(path, FileMode.CreateNew, FileAccess.Write);
        await content.CopyToAsync(fs, ct);
        return safeName;
    }

    public Task<Stream> OpenCoverAsync(string coverFileName, CancellationToken ct = default)
        => Task.FromResult<Stream>(new FileStream(ResolveCover(coverFileName), FileMode.Open, FileAccess.Read));

    /// <summary>
    /// მხოლოდ ფაილები — ქვესაქაღალდეებში არ ჩადის. დრო <c>CreationTimeUtc</c>-დან:
    /// გასუფთავებას სჭირდება „როდის ატვირთეს", და არა „როდის შეეხნენ".
    /// </summary>
    public Task<IReadOnlyList<StoredCover>> ListCoversAsync(CancellationToken ct = default)
    {
        var directory = new DirectoryInfo(_opts.CoverPath);
        if (!directory.Exists) return Task.FromResult<IReadOnlyList<StoredCover>>([]);

        IReadOnlyList<StoredCover> covers = directory
            .EnumerateFiles("*", SearchOption.TopDirectoryOnly)
            .Select(f => new StoredCover(f.Name, new DateTimeOffset(f.CreationTimeUtc, TimeSpan.Zero)))
            .ToList();

        return Task.FromResult(covers);
    }

    public Task DeleteCoverAsync(string coverFileName, CancellationToken ct = default)
    {
        var path = ResolveCover(coverFileName);
        if (File.Exists(path)) File.Delete(path);
        return Task.CompletedTask;
    }

    /// <summary>
    /// სახელს ქავერების საქაღალდეში აქცევს და ამოწმებს, რომ შედეგი მართლა მის შიგნით რჩება —
    /// path traversal-ის (../) საწინააღმდეგო ბოლო ბარიერი.
    /// </summary>
    private string ResolveCover(string coverFileName)
    {
        if (string.IsNullOrWhiteSpace(coverFileName) ||
            coverFileName != Path.GetFileName(coverFileName))
            throw new UnauthorizedAccessException("ქავერის არასწორი სახელი.");

        var root = Path.GetFullPath(_opts.CoverPath);
        var full = Path.GetFullPath(Path.Combine(root, coverFileName));

        if (!full.StartsWith(root + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase))
            throw new UnauthorizedAccessException("ქავერის არასწორი სახელი.");

        return full;
    }

    public async Task<string> SaveToQuarantineAsync(Stream content, string fileName, CancellationToken ct = default)
    {
        var safeName = $"{Guid.NewGuid():N}{Path.GetExtension(fileName)}";
        var path = Path.Combine(_opts.QuarantinePath, safeName);
        await using var fs = new FileStream(path, FileMode.CreateNew, FileAccess.Write);
        await content.CopyToAsync(fs, ct);
        return path;
    }

    public Task<string> MoveToPermanentAsync(string quarantinePath, CancellationToken ct = default)
    {
        var dest = Path.Combine(_opts.PermanentPath, Path.GetFileName(quarantinePath));
        File.Move(quarantinePath, dest, overwrite: false);
        return Task.FromResult(dest);
    }

    public Task DeleteAsync(string path, CancellationToken ct = default)
    {
        var safe = ResolveStored(path);
        if (File.Exists(safe)) File.Delete(safe);
        return Task.CompletedTask;
    }

    public Task<Stream> OpenReadAsync(string path, CancellationToken ct = default)
        => Task.FromResult<Stream>(new FileStream(ResolveStored(path), FileMode.Open, FileAccess.Read));

    /// <summary>
    /// განაცხადის ფაილის გზა საკუთარ საქაღალდეებში უნდა რჩებოდეს — იგივე ბოლო ბარიერი,
    /// რაც ქავერებზე (<see cref="ResolveCover"/>).
    ///
    /// <para>გზას ჩვენ ვაგენერირებთ და ბაზაში ვინახავთ, ანუ პირდაპირი გზა თავდასხმისთვის
    /// დღეს არ არსებობს. მაგრამ სწორედ ეს ვარაუდი — „ბაზაში მხოლოდ ჩვენი მონაცემია" —
    /// არის ის, რაც მიგრაციის, იმპორტის ან სხვა შეცდომის შემდეგ ჩუმად ირღვევა. ორივე
    /// მეთოდი ბაზიდან წაკითხულ სტრიქონს ფაილურ სისტემას გადასცემს, ამიტომ შემოწმება
    /// სწორედ აქ, უკანასკნელ წერტილში დგას.</para>
    /// </summary>
    private string ResolveStored(string path)
    {
        if (string.IsNullOrWhiteSpace(path))
            throw new UnauthorizedAccessException("ფაილის არასწორი გზა.");

        var full = Path.GetFullPath(path);

        if (IsUnder(full, _opts.PermanentPath) || IsUnder(full, _opts.QuarantinePath))
            return full;

        throw new UnauthorizedAccessException("ფაილის არასწორი გზა.");
    }

    private static bool IsUnder(string fullPath, string root)
    {
        if (string.IsNullOrWhiteSpace(root)) return false;

        var fullRoot = Path.GetFullPath(root).TrimEnd(Path.DirectorySeparatorChar);
        return fullPath.StartsWith(fullRoot + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase);
    }
}
