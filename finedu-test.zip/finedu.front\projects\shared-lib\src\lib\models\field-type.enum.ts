// backend-ის FieldType-ის იდენტური (ერთი და იგივე რიცხვები).
export enum FieldType {
  ShortAnswer = 1,
  LongAnswer = 2,
  MultipleChoice = 3,
  Checkboxes = 4,
  LinearScale = 5,
  FileUpload = 6,
}
