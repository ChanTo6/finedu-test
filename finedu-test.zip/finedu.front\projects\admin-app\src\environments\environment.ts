export const environment = {
  production: false,
  // Admin API (შიდა) — dev
  apiUrl: 'https://localhost:7002/api',
};
