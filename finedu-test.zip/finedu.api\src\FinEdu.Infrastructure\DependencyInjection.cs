﻿using FinEdu.Application.Common.Interfaces;
using FinEdu.Application.Common.Options;
using FinEdu.Infrastructure.Email;
using FinEdu.Infrastructure.Export;
using FinEdu.Infrastructure.Files;
using FinEdu.Infrastructure.Identity;
using FinEdu.Infrastructure.Logging;
using FinEdu.Infrastructure.Options;
using FinEdu.Infrastructure.Persistence;
using FinEdu.Infrastructure.Security;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace FinEdu.Infrastructure;

public static class DependencyInjection
{
    public static IServiceCollection AddInfrastructure(this IServiceCollection services, IConfiguration config)
    {
        services.AddDbContext<AppDbContext>(o =>
            o.UseSqlServer(config.GetConnectionString("Default")));
        services.AddScoped<IAppDbContext>(sp => sp.GetRequiredService<AppDbContext>());

        services.Configure<StorageOptions>(config.GetSection("Storage"));
        services.Configure<SmtpOptions>(config.GetSection("Smtp"));
        services.Configure<SubmissionGuardOptions>(config.GetSection("SubmissionGuard"));
        services.Configure<AdminAppOptions>(config.GetSection("AdminApp"));

        // LDAP დაუშიფრავად პაროლებს ღია ტექსტით აგზავნის — არასწორი კონფიგი გაშვებისასვე უნდა გაჩერდეს,
        // და არა პირველ login-ზე. (PublicApi-ს LDAP არ აქვს — იქ Host ცარიელია და შემოწმება გამოტოვდება.)
        services.AddOptions<LdapOptions>()
            .Bind(config.GetSection("Ldap"))
            .Validate(o => string.IsNullOrWhiteSpace(o.Host) || o.UseSsl || o.UseStartTls || o.AllowUnencrypted,
                "Ldap: დაშიფვრა სავალდებულოა — ჩართეთ Ldap:UseSsl (პორტი 636) ან Ldap:UseStartTls.")
            .Validate(o => string.IsNullOrWhiteSpace(o.Host) || !string.IsNullOrWhiteSpace(o.BaseDn),
                "Ldap:BaseDn სავალდებულოა — მის გარეშე AD ჯგუფები ვერ შემოწმდება და როლი ვერ მიენიჭება.")
            .Validate(o => string.IsNullOrWhiteSpace(o.Host) ||
                           !string.IsNullOrWhiteSpace(o.AdminGroup) || !string.IsNullOrWhiteSpace(o.StandardGroup),
                "Ldap: მიუთითეთ AdminGroup და/ან StandardGroup — ჯგუფის გარეშე ვერავინ შემოვა.")
            .ValidateOnStart();

        // მდგომარეობის გარეშეა (მხოლოდ გზები კონფიგიდან), კონსტრუქტორი კი საქაღალდეებს
        // ქმნის — scoped-ად ეს სისტემურ გამოძახებას ყოველ მოთხოვნაზე იმეორებდა.
        services.AddSingleton<IFileStorage, FileSystemStorage>();

        // მდგომარეობის გარეშე, კონსტრუქტორში allowlist-ის აწყობა ერთხელ ღირს
        services.AddSingleton<IHtmlContent, HtmlContent>();
        services.AddScoped<IAdAuthenticator, LdapAuthenticator>();
        services.AddScoped<IEmailSender, SmtpEmailSender>();
        services.AddSingleton<IExcelExporter, ClosedXmlExporter>();
        services.AddScoped<IAuditLogger, AuditLogger>();

        return services;
    }
}
