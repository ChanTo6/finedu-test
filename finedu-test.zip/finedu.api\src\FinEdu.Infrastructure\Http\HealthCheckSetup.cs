using FinEdu.Infrastructure.Persistence;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Diagnostics.HealthChecks;
using Microsoft.AspNetCore.Routing;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Diagnostics.HealthChecks;

namespace FinEdu.Infrastructure.Http;

/// <summary>
/// Liveness / readiness endpoint-ები (IIS-ის, load balancer-ის და მონიტორინგისთვის).
///   /health       — პროცესი ცოცხალია (გარე დამოკიდებულებებს არ ეხება)
///   /health/ready — მზადაა მოთხოვნების მისაღებად (ბაზა ხელმისაწვდომია)
/// </summary>
public static class HealthCheckSetup
{
    private const string ReadyTag = "ready";

    public static IServiceCollection AddFinEduHealthChecks(this IServiceCollection services)
    {
        services.AddHealthChecks()
            .AddDbContextCheck<AppDbContext>("database", tags: [ReadyTag]);
        return services;
    }

    public static IEndpointRouteBuilder MapFinEduHealthChecks(this IEndpointRouteBuilder endpoints)
    {
        // AllowAnonymous ცხადად: ადმინის ზონაში ავტორიზაცია ნაგულისხმევად სავალდებულოა
        // (FallbackPolicy), load balancer-ს კი ტოკენი არ აქვს და ვერც ექნება.
        // პასუხი მხოლოდ სტატუსია — დეტალები არ გაიცემა.

        // liveness — არცერთი შემოწმება, უბრალოდ „პროცესი პასუხობს"
        endpoints.MapHealthChecks("/health", new HealthCheckOptions { Predicate = _ => false })
            .AllowAnonymous();

        endpoints.MapHealthChecks("/health/ready", new HealthCheckOptions
        {
            Predicate = c => c.Tags.Contains(ReadyTag)
        }).AllowAnonymous();

        return endpoints;
    }
}
