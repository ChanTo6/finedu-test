﻿using FinEdu.Application.Common.Models;

namespace FinEdu.Application.Forms;

public interface IFormService
{
    Task<Guid> CreateAsync(CreateFormRequest request, CancellationToken ct = default);
    Task UpdateAsync(Guid id, UpdateFormRequest request, CancellationToken ct = default);
    Task<FormDto> GetByIdAsync(Guid id, CancellationToken ct = default);
    Task<IReadOnlyList<FormSummaryDto>> ListAsync(CancellationToken ct = default);

    // ქავერის ატვირთვა, გაცემა და გასუფთავება ცალკე სერვისშია — იხ. IFormCoverService.

    /// <summary>საჯარო კატალოგი: გამოცხადებული (Live) კონკურსები, რომლებიც ჯერ იღებენ განაცხადებს.</summary>
    Task<IReadOnlyList<PublicFormListItemDto>> ListPublicAsync(CancellationToken ct = default);

    /// <summary>საჯარო: მხოლოდ Live ფორმა, token-ით.</summary>
    Task<PublicFormDto> GetPublicByTokenAsync(string token, CancellationToken ct = default);

    // 2-დონიანი დადასტურება
    Task SubmitForApprovalAsync(Guid id, CancellationToken ct = default);
    Task ApproveAsync(Guid id, CancellationToken ct = default);
    Task CloseAsync(Guid id, CancellationToken ct = default);

    /// <summary>ავტო-დახურვა — ვადა გასული ან ლიმიტ-შევსებული Live ფორმები (Worker-ი იძახებს).</summary>
    Task<int> AutoCloseDueAsync(CancellationToken ct = default);
}
