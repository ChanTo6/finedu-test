using FinEdu.Application.Common.Exceptions;
using FinEdu.Application.Common.Interfaces;
using FinEdu.Domain.Entities;
using FinEdu.Domain.Enums;
using Microsoft.EntityFrameworkCore;

namespace FinEdu.Application.Common.Security;

/// <summary>
/// per-project წვდომა (doc §4.1): თანამშრომელი ხედავს მხოლოდ იმ კონკურსის მონაცემებს,
/// რომელზეც წვდომა აქვს მინიჭებული; Administrator — ყველას.
/// </summary>
public interface IFormAccessGuard
{
    /// <summary>ფორმების კითხვას ზღუდავს მიმდინარე მომხმარებლისთვის ხელმისაწვდომებით.</summary>
    IQueryable<Form> Accessible(IQueryable<Form> forms);

    /// <summary>
    /// კითხვის წვდომა: სიაში ყოფნა კმარა (დამკვირვებელიც და მმართველიც).
    /// უარის შემთხვევაში ForbiddenException.
    /// </summary>
    Task EnsureCanAccessAsync(Guid formId, CancellationToken ct = default);

    /// <summary>
    /// ცვლილების წვდომა: მხოლოდ <see cref="AccessLevel.Manager"/> ან Administrator.
    ///
    /// <para>ცალკე მეთოდი იმიტომ, რომ „ნახვა" და „შეცვლა" ერთი შემოწმებით მოწმდებოდა —
    /// დამკვირვებელს ფორმის რედაქტირება, ჟიურის მართვა და სხვისთვის წვდომის მინიჭებაც
    /// შეეძლო. ანუ ორი დონე ბაზაში ეწერა, მაგრამ არაფერს ცვლიდა.</para>
    /// </summary>
    Task EnsureCanManageAsync(Guid formId, CancellationToken ct = default);
}

public class FormAccessGuard(IAppDbContext db, ICurrentUser currentUser) : IFormAccessGuard
{
    private const string DeniedMessage = "ამ კონკურსის მონაცემებზე წვდომა არ გაქვთ.";
    private const string ManageDeniedMessage =
        "ამ კონკურსის შეცვლა მხოლოდ მმართველს შეუძლია. თქვენ დამკვირვებლის წვდომა გაქვთ.";

    public IQueryable<Form> Accessible(IQueryable<Form> forms)
    {
        if (currentUser.IsAdministrator) return forms;

        var account = currentUser.Account;
        return forms.Where(f => f.AccessList.Any(a => a.AdAccount == account));
    }

    public async Task EnsureCanAccessAsync(Guid formId, CancellationToken ct = default)
    {
        if (currentUser.IsAdministrator) return;

        var allowed = await db.FormAccessList.AsNoTracking()
            .AnyAsync(a => a.FormId == formId && a.AdAccount == currentUser.Account, ct);

        if (!allowed) throw new ForbiddenException(DeniedMessage);
    }

    public async Task EnsureCanManageAsync(Guid formId, CancellationToken ct = default)
    {
        if (currentUser.IsAdministrator) return;

        var level = await db.FormAccessList.AsNoTracking()
            .Where(a => a.FormId == formId && a.AdAccount == currentUser.Account)
            .Select(a => (AccessLevel?)a.AccessLevel)
            .FirstOrDefaultAsync(ct);

        // წვდომა საერთოდ არ აქვს და დამკვირვებელია — ორი სხვადასხვა შეტყობინება:
        // პირველ შემთხვევაში კონკურსის არსებობაც არ უნდა გაამხილოს.
        if (level is null) throw new ForbiddenException(DeniedMessage);
        if (level != AccessLevel.Manager) throw new ForbiddenException(ManageDeniedMessage);
    }
}
