﻿using FinEdu.Application.Common;
using FinEdu.Application.Common.Audit;
using FinEdu.Application.Common.Exceptions;
using FinEdu.Application.Common.Interfaces;
using FinEdu.Application.Common.Models;
using FinEdu.Application.Common.Options;
using FinEdu.Application.Common.Security;
using FinEdu.Application.Files;
using FinEdu.Application.Submissions.Validators;
using System.Data;
using FinEdu.Domain.Entities;
using FinEdu.Domain.Enums;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using FinEdu.Application.Resources;

namespace FinEdu.Application.Submissions;

public class SubmissionService(
    IAppDbContext db,
    IFileService fileService,
    IEmailSender email,
    IFileStorage storage,
    IFormAccessGuard accessGuard,
    IAuditLogger audit,
    ICurrentUser currentUser,
    IOptions<SubmissionGuardOptions> guardOptions,
    ILogger<SubmissionService> logger) : ISubmissionService
{
    private readonly SubmissionValidator _validator = new();
    private readonly SubmissionGuardOptions _guard = guardOptions.Value;

    // ნაგულისხმევი ტექსტი — გამოიყენება მაშინ, როცა კონკურსს თავისი არ აქვს (doc §3.5)
    private const string DefaultConfirmationSubject = "განაცხადი მიღებულია";
    private const string DefaultConfirmationBody =
        "<p>მოგესალმებით, თქვენი განაცხადი მიღებულია. მადლობა მონაწილეობისთვის.</p>";

    public async Task<Guid> CreateAsync(string token, CreateSubmissionRequest request,
        IReadOnlyList<SubmissionFileInput> files, CancellationToken ct = default)
    {
        var form = await db.Forms.Include(f => f.Fields)
            .FirstOrDefaultAsync(f => f.PublicToken == token && f.Status == FormStatus.Live, ct)
            ?? throw new NotFoundException(nameof(Form), token);

        // ვადა და ლიმიტი — იგივე წესი, რაც კატალოგსა და ავტო-დახურვაში (doc §3.4)
        if (!form.IsWithinCloseDate(DateTimeOffset.UtcNow))
            throw new DomainException(Messages.FormClosedDeadline);

        if (form.MaxParticipants is not null && !form.HasFreeCapacity(await CountSubmissionsAsync(form.Id, ct)))
            throw new DomainException(Messages.FormClosedLimit);

        // დინამიური ვალიდაცია (მეილის ფორმატის ჩათვლით) — ნორმალიზებამდე
        _validator.Validate(form, request, files);

        // მეილი ერთ ფორმატში ინახება: შედარება რომ რეგისტრზე არ იყოს დამოკიდებული და
        // მოგვიანებით დამატებულმა ინდექსმაც იმუშაოს (ჟიურის მისამართებიც ასე ინახება).
        var notificationEmail = NormalizeEmail(request.NotificationEmail);

        await EnsureNotDuplicateAsync(form.Id, notificationEmail, ct);

        // ფაილების სკანი + შენახვა. თუ რომელიმე ჩავარდა (მაგ. ვირუსი მე-2 ფაილში),
        // უკვე შენახულებიც უნდა წაიშალოს — თორემ დისკზე დარჩებოდა პერსონალური ფაილი,
        // რომელზეც ბაზაში ჩანაწერი არ არსებობს და retention-ის წაშლაც ვერასდროს მისწვდება.
        var savedFiles = new List<SubmissionFile>();
        try
        {
            foreach (var f in files)
                savedFiles.Add(await fileService.SaveAndScanAsync(f.FieldId, f, ct));
        }
        catch
        {
            foreach (var saved in savedFiles)
                await storage.DeleteAsync(saved.StoredPath, CancellationToken.None);
            throw;
        }

        var submission = new Submission
        {
            FormId = form.Id,
            Status = SubmissionStatus.Completed,
            ConsentDataProcessing = request.ConsentDataProcessing,
            NotificationEmail = notificationEmail,
            // ვინ გამოაგზავნა — ვინაობა არა, მაგრამ კვალი: retention-ის წაშლისას ქრება
            VisitorId = currentUser.VisitorId,
            SubmitterIp = currentUser.IpAddress,
            UserAgent = SafeText.Clean(currentUser.UserAgent, 512),
            Values = request.Values
                .Where(v => !string.IsNullOrWhiteSpace(v.Value))
                .Select(v => new SubmissionValue { FieldId = v.FieldId, Value = v.Value })
                .ToList(),
            Files = savedFiles
        };

        try
        {
            // ლიმიტის ხელახალი შემოწმება *ჩაწერასთან ერთად*, სერიალიზებულ ტრანზაქციაში:
            // ზემოთა შემოწმება მარტო არ კმარა — ორი პარალელური განაცხადი ორივე გაივლიდა
            // და ლიმიტს გადააჭარბებდნენ. ფაილების დამუშავება განზრახ ტრანზაქციის გარეთაა,
            // რომ ClamAV-ის სკანირებამ ბაზა დიდხანს არ დაბლოკოს.
            await using var tx = await db.Database.BeginTransactionAsync(IsolationLevel.Serializable, ct);

            if (form.MaxParticipants is not null && !form.HasFreeCapacity(await CountSubmissionsAsync(form.Id, ct)))
                throw new DomainException(Messages.FormClosedLimit);

            // დუბლიკატის ხელახალი შემოწმება ჩაწერასთან ერთად: ზემოთა შემოწმებიდან
            // ჩაწერამდე ფაილების სკანირებას წამები სჭირდება — ორი პარალელური გაგზავნა
            // ორივე გაივლიდა (იგივე race, რაც მონაწილეთა ლიმიტზე).
            await EnsureNotDuplicateAsync(form.Id, notificationEmail, ct);

            db.Submissions.Add(submission);
            await db.SaveChangesAsync(ct);

            // აუდიტი *ტრანზაქციის შიგნით*: commit-ის შემდეგ ჩაწერისას ჟურნალის ჩავარდნა
            // განაცხადს ჩანაწერის გარეშე დატოვებდა. აქ ან ორივე ჩაიწერება, ან ვერცერთი.
            await audit.LogAsync(AuditActions.SubmissionCreated, nameof(Submission), submission.Id.ToString(),
                $"form={form.Id}; files={savedFiles.Count}", ct);

            await tx.CommitAsync(ct);
        }
        catch
        {
            // ჩაწერა ვერ მოხერხდა — ატვირთული ფაილები დისკზე არ უნდა დარჩეს
            foreach (var saved in savedFiles)
                await storage.DeleteAsync(saved.StoredPath, CancellationToken.None);
            throw;
        }

        // ავტო-პასუხი (doc §3.5) — ტრანზაქციის გარეთ. მეილის ჩავარდნამ მიღებული
        // განაცხადი არ უნდა გააუქმოს, ამიტომ შეცდომა ლოგდება და არ იგდება.
        if (!string.IsNullOrWhiteSpace(notificationEmail))
        {
            try
            {
                await email.SendAsync(
                    notificationEmail,
                    form.ConfirmationEmailSubject is { Length: > 0 } s ? s : DefaultConfirmationSubject,
                    form.ConfirmationEmailBody is { Length: > 0 } b ? b : DefaultConfirmationBody,
                    ct);
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "დადასტურების მეილი ვერ გაიგზავნა · submission={SubmissionId}", submission.Id);
            }
        }

        return submission.Id;
    }

    /// <summary>
    /// ერთი ადამიანის მრავალი განაცხადის შეზღუდვა ვინაობის შემოწმების გარეშე.
    ///
    /// <para>
    /// სამი ნიშანი გამოიყენება: ბრაუზერის cookie, საკონტაქტო მეილი და IP-ის დღიური ლიმიტი.
    /// არცერთი არ არის გარანტია (cookie იშლება, IP იცვლება, მეილი ახალი იქმნება) — ეს
    /// შემაფერხებელი ზომაა და შემდგომი გამოძიების საშუალება. შეტყობინება მიზანმიმართულად
    /// ცხადია: მოქალაქემ უნდა გაიგოს, რომ განაცხადი უკვე მიღებულია და ხელახლა არ ცადოს.
    /// </para>
    /// </summary>
    private async Task EnsureNotDuplicateAsync(Guid formId, string? notificationEmail, CancellationToken ct)
    {
        var visitorId = currentUser.VisitorId;
        var ip = currentUser.IpAddress;

        if (_guard.OneEntryPerVisitor && !string.IsNullOrEmpty(visitorId))
        {
            var already = await db.Submissions.AnyAsync(
                s => s.FormId == formId && s.VisitorId == visitorId && s.Status != SubmissionStatus.Rejected, ct);

            if (already)
                throw new DomainException(Messages.AlreadySubmittedFromDevice);
        }

        // მისამართი უკვე ნორმალიზებულია (NormalizeEmail) — შედარება პირდაპირ, სვეტზე
        // ფუნქციის გამოძახების გარეშე, რომ ინდექსის გამოყენებას არაფერი უშლიდეს.
        if (_guard.OneEntryPerEmail && !string.IsNullOrWhiteSpace(notificationEmail))
        {
            var already = await db.Submissions.AnyAsync(
                s => s.FormId == formId && s.NotificationEmail == notificationEmail
                     && s.Status != SubmissionStatus.Rejected, ct);

            if (already)
                throw new DomainException(Messages.AlreadySubmittedWithEmail);
        }

        // IP-ის დღიური ლიმიტი — rate limiter მეხსიერებაშია და გადატვირთვისას ნულდება,
        // ეს კი ბაზაში ითვლება, ანუ სკრიპტს რესტარტის ლოდინი ვერ უშველის.
        if (_guard.MaxPerIpPerDay > 0 && !string.IsNullOrEmpty(ip))
        {
            var since = DateTimeOffset.UtcNow.AddDays(-1);
            var count = await db.Submissions.CountAsync(
                s => s.FormId == formId && s.SubmitterIp == ip && s.SubmittedAt >= since, ct);

            if (count >= _guard.MaxPerIpPerDay)
                throw new DomainException(Messages.TooManyFromNetwork);
        }
    }

    /// <summary>მეილი ერთ ფორმატში — ისევე, როგორც ჟიურის მისამართები (JuryAdminService).</summary>
    private static string? NormalizeEmail(string? email) =>
        string.IsNullOrWhiteSpace(email) ? null : email.Trim().ToLowerInvariant();

    /// <summary>ლიმიტში ჩასათვლელი განაცხადები — უარყოფილი არ ითვლება.</summary>
    private Task<int> CountSubmissionsAsync(Guid formId, CancellationToken ct) =>
        db.Submissions.CountAsync(s => s.FormId == formId && s.Status != SubmissionStatus.Rejected, ct);

    public async Task<PagedResult<SubmissionDto>> ListByFormAsync(
        Guid formId, PageQuery query, CancellationToken ct = default)
    {
        // per-project წვდომა: სხვისი კონკურსის განაცხადები არ უნდა ჩანდეს (doc §4.1)
        await accessGuard.EnsureCanAccessAsync(formId, ct);

        var fields = await db.FormFields.AsNoTracking()
            .Where(f => f.FormId == formId)
            .ToDictionaryAsync(f => f.Id, f => f.Label, ct);

        var filtered = db.Submissions.AsNoTracking().Where(s => s.FormId == formId);

        // ძებნა პასუხების ტექსტში: ველები დინამიურია, ამიტომ კონკრეტული სვეტი არ არსებობს.
        // ID-ითაც იძებნება — Excel-ში სწორედ ის ჩანს და მისით უკან დაბრუნება ბუნებრივია.
        if (query.SafeSearch is { } search)
        {
            filtered = filtered.Where(s =>
                s.Values.Any(v => v.Value != null && v.Value.Contains(search)) ||
                s.Id.ToString() == search);
        }

        var total = await filtered.CountAsync(ct);

        // ორი კოლექციის Include ერთ SQL-ში დეკარტულ ნამრავლს იძლევა (values × files):
        // 20-პასუხიან და 3-ფაილიან განაცხადზე 60 სტრიქონი ბრუნდება 23-ის ნაცვლად.
        // AsSplitQuery თითო კოლექციას ცალკე მოთხოვნით იღებს.
        var submissions = await filtered
            .OrderByDescending(s => s.SubmittedAt)
            .ThenBy(s => s.Id)   // ერთ წამში შემოსულებს გვერდებს შორის რომ არ გადაუხტეს
            .Skip(query.Skip)
            .Take(query.SafePageSize)
            .Include(s => s.Values)
            .Include(s => s.Files)
            .AsSplitQuery()
            .ToListAsync(ct);

        // ცვლილება არ ხდება, მაგრამ ეს პერსონალურ მონაცემებზე წვდომაა — შემმოწმებელს
        // უნდა შეეძლოს დაინახოს, ვინ და როდის ნახა კონკურსის განაცხადები.
        await audit.LogAsync(AuditActions.SubmissionsViewed, nameof(Form), formId.ToString(),
            $"page={query.SafePage}; count={submissions.Count}; total={total}", ct);

        var (byDevice, byNetwork) = await DuplicateCountsAsync(formId, submissions, ct);

        var items = submissions.Select(s => new SubmissionDto(
            s.Id, s.SubmittedAt, s.ConsentDataProcessing,
            s.Values.Select(v => new SubmissionValueDto(
                v.FieldId, fields.GetValueOrDefault(v.FieldId, ""), v.Value)).ToList(),
            s.Files.Select(f => new SubmissionFileDto(
                f.Id, f.FieldId, f.OriginalFileName, f.SizeBytes)).ToList(),
            s.VisitorId is null ? 1 : byDevice.GetValueOrDefault(s.VisitorId, 1),
            s.SubmitterIp is null ? 1 : byNetwork.GetValueOrDefault(s.SubmitterIp, 1))).ToList();

        return new PagedResult<SubmissionDto>(items, query.SafePage, query.SafePageSize, total);
    }

    /// <summary>
    /// „ამავე მოწყობილობიდან/ქსელიდან რამდენი" — დათვლა <b>მთელ კონკურსზე</b> და არა
    /// მიმდინარე გვერდზე: გვერდზე დათვლა ორ სხვადასხვა გვერდზე მოხვედრილ დუბლიკატს
    /// ვერ დაინახავდა და გაფრთხილება უბრალოდ გაქრებოდა.
    ///
    /// <para>მოთხოვნა მხოლოდ ამ გვერდზე შემხვედრ ნიშნებს ეხება — ანუ მისი ზომა
    /// გვერდის ზომითაა შემოსაზღვრული და არა კონკურსის მოცულობით.</para>
    /// </summary>
    private async Task<(Dictionary<string, int> Device, Dictionary<string, int> Network)>
        DuplicateCountsAsync(Guid formId, List<Submission> page, CancellationToken ct)
    {
        var visitorIds = page.Where(s => s.VisitorId != null).Select(s => s.VisitorId!).Distinct().ToList();
        var ips = page.Where(s => s.SubmitterIp != null).Select(s => s.SubmitterIp!).Distinct().ToList();

        var byDevice = visitorIds.Count == 0
            ? new Dictionary<string, int>()
            : await db.Submissions.AsNoTracking()
                .Where(s => s.FormId == formId && s.VisitorId != null && visitorIds.Contains(s.VisitorId))
                .GroupBy(s => s.VisitorId!)
                .Select(g => new { Key = g.Key, Count = g.Count() })
                .ToDictionaryAsync(x => x.Key, x => x.Count, ct);

        var byNetwork = ips.Count == 0
            ? new Dictionary<string, int>()
            : await db.Submissions.AsNoTracking()
                .Where(s => s.FormId == formId && s.SubmitterIp != null && ips.Contains(s.SubmitterIp))
                .GroupBy(s => s.SubmitterIp!)
                .Select(g => new { Key = g.Key, Count = g.Count() })
                .ToDictionaryAsync(x => x.Key, x => x.Count, ct);

        return (byDevice, byNetwork);
    }

    public async Task<int> DeleteExpiredAsync(CancellationToken ct = default)
    {
        var now = DateTimeOffset.UtcNow;
        var dueFormIds = await db.Forms.AsNoTracking()
            .Where(f => f.RetentionUntil != null && f.RetentionUntil <= now)
            .Select(f => f.Id)
            .ToListAsync(ct);

        if (dueFormIds.Count == 0) return 0;

        var submissions = await db.Submissions
            .Include(s => s.Files)
            .Where(s => dueFormIds.Contains(s.FormId))
            .ToListAsync(ct);

        if (submissions.Count == 0) return 0;

        // ფიზიკური ფაილები *ბაზამდე*: retention-ის ვადა გასულია და პერსონალური მონაცემი
        // დისკზე ვერ უნდა დარჩეს. თუ ბაზის წაშლა ჩავარდება, ჩანაწერები რჩება და job-ი
        // შემდეგ გაშვებაზე თავიდან ცდის (წაშლა იდემპოტენტურია). შებრუნებული თანმიმდევრობა
        // კი ჩავარდნისას ფაილს ვადის შემდეგაც დისკზე ტოვებდა — ჩანაწერის გარეშე,
        // ანუ სამუდამოდ და უპატრონოდ.
        foreach (var file in submissions.SelectMany(s => s.Files))
            await storage.DeleteAsync(file.StoredPath, ct);

        // წაშლა და ჟურნალი ერთ ტრანზაქციაში: არააღდგენადი წაშლა უკვალოდ ვერ უნდა მოხდეს —
        // ჟურნალი ერთადერთი მტკიცებულებაა, რომ მონაცემი retention-ის წესით გაქრა და არა ხელით.
        // თითო კონკურსზე ცალკე ჩანაწერი, რომ EntityId რეალურ ID-ს შეესაბამებოდეს.
        await using var tx = await db.Database.BeginTransactionAsync(ct);

        db.Submissions.RemoveRange(submissions);   // cascade → Values + Files + Evaluations

        // ცხადი SaveChanges: წაშლა არ უნდა იყოს დამოკიდებული იმაზე, რომ ჟურნალის ჩაწერა
        // გვერდით ეფექტად ფლეშავს ცვლილებებს — აუდიტის ერთი ცვლილებაც კი (მაგ. ცალკე
        // კონტექსტზე გადატანა) წაშლას ჩუმად გააუქმებდა.
        await db.SaveChangesAsync(ct);

        foreach (var group in submissions.GroupBy(s => s.FormId))
            await audit.LogAsync(AuditActions.RetentionPurged, nameof(Form), group.Key.ToString(),
                $"submissions={group.Count()}", ct);

        await tx.CommitAsync(ct);
        return submissions.Count;
    }
}
