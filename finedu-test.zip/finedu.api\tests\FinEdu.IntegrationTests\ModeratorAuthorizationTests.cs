﻿using System.IdentityModel.Tokens.Jwt;
using System.Net;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text.Json;
using FinEdu.Application.Common.Security;
using Microsoft.AspNetCore.Hosting;

namespace FinEdu.IntegrationTests;

/// <summary>
/// იგივე ჰოსტი, ოღონდ მომხმარებელი მხოლოდ <c>Moderator</c>-ია.
/// ყველა დანარჩენი ტესტი ადმინისტრატორად შედის, ანუ ორდონიანი წესი HTTP დონეზე
/// საერთოდ არ იფარებოდა — controller-ის ატრიბუტის შემთხვევითი წაშლა შეუმჩნეველი დარჩებოდა.
/// </summary>
public class ModeratorApiFactory : AdminApiFactory
{
    protected override void ConfigureWebHost(IWebHostBuilder builder)
    {
        base.ConfigureWebHost(builder);

        // appsettings.Development.json-ში DevAuth:Roles = [Administrator, Moderator].
        // კონფიგურაციის მასივი ინდექსით გადაიფარება და არა მთლიანად — ამიტომ ორივე
        // პოზიცია ცხადად უნდა ჩაიწეროს, თორემ Administrator ადგილზე დარჩებოდა.
        builder.UseSetting("DevAuth:Roles:0", Roles.Moderator);
        builder.UseSetting("DevAuth:Roles:1", Roles.Moderator);
    }
}

/// <summary>
/// მოდერატორის საზღვარი: მართვა შეუძლია, დადასტურება — არა.
/// სერვისის დონეზე ეს წესი unit ტესტებით იფარება; აქ ის მოწმდება, რომ პოლიტიკები
/// და მარშრუტები რეალურ მილსადენშიც სწორად არის შეკრული.
/// </summary>
public class ModeratorAuthorizationTests : IAsyncLifetime
{
    private readonly ModeratorApiFactory _factory = new();
    private HttpClient _client = null!;

    public async Task InitializeAsync()
    {
        _client = _factory.CreateClient();

        var login = await _client.PostAsJsonAsync("/api/auth/login",
            new { username = "tester", password = "test-password" });
        login.EnsureSuccessStatusCode();

        var body = await login.Content.ReadFromJsonAsync<JsonElement>();

        // სწორედ ეს არის ტესტის წინაპირობა: შესული მომხმარებელი ადმინისტრატორი არ არის
        var roles = body.GetProperty("roles").EnumerateArray().Select(r => r.GetString()).ToList();
        Assert.Equal([Roles.Moderator], roles);

        var token = body.GetProperty("token").GetString()!;

        // როლი *ტოკენშიც* უნდა ეწეროს — პოლიტიკები claim-ს კითხულობენ და არა
        // login-ის პასუხს. ძველი სახელი აქ აღარ უნდა ჩნდებოდეს.
        var claims = new JwtSecurityTokenHandler().ReadJwtToken(token).Claims
            .Where(c => c.Type == "role")
            .Select(c => c.Value)
            .ToList();

        Assert.Equal([Roles.Moderator], claims);

        _client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
    }

    public Task DisposeAsync()
    {
        _factory.Dispose();
        return Task.CompletedTask;
    }

    /// <summary>ფორმის შექმნა შემქმნელს მმართველის წვდომას აძლევს — ეს მოდერატორს შეუძლია.</summary>
    private async Task<string> CreateFormAsync()
    {
        var response = await _client.PostAsJsonAsync("/api/forms", new
        {
            title = "მოდერატორის კონკურსი",
            retentionDays = 30,
            privacyNoticeHtml = "<p>პირობები</p>",
            fields = new[] { new { order = 0, type = 1, label = "სახელი", isRequired = false, config = new { } } }
        });
        response.EnsureSuccessStatusCode();

        return (await response.Content.ReadFromJsonAsync<JsonElement>()).GetProperty("id").GetString()!;
    }

    private async Task<string> AddJurorAsync(string formId)
    {
        var response = await _client.PostAsJsonAsync($"/api/forms/{formId}/jury",
            new { email = "juror@example.com", displayName = "შემფასებელი" });
        response.EnsureSuccessStatusCode();

        return (await response.Content.ReadFromJsonAsync<JsonElement>()).GetProperty("id").GetString()!;
    }

    // ── რა შეუძლია ──────────────────────────────────────────────────

    [Fact]
    public async Task Moderator_can_manage_own_contest()
    {
        var formId = await CreateFormAsync();

        Assert.Equal(HttpStatusCode.OK, (await _client.GetAsync($"/api/forms/{formId}")).StatusCode);
        Assert.Equal(HttpStatusCode.OK, (await _client.GetAsync($"/api/forms/{formId}/jury")).StatusCode);
    }

    /// <summary>ჟიურის დამატება მოთხოვნად ინახება — წერილი ჯერ არ იგზავნება.</summary>
    [Fact]
    public async Task Moderator_addition_is_stored_as_a_pending_request()
    {
        var formId = await CreateFormAsync();
        await AddJurorAsync(formId);

        var list = await _client.GetFromJsonAsync<JsonElement>($"/api/forms/{formId}/jury");
        var juror = list.EnumerateArray().Single();

        Assert.Equal(1, juror.GetProperty("status").GetInt32());   // PendingApproval
        Assert.Null(juror.GetProperty("approvedBy").GetString());
        Assert.Equal("tester", juror.GetProperty("requestedBy").GetString());

        // PIN ჯერ არ გაცემულა — DTO-შიც ცარიელია
        Assert.Equal(JsonValueKind.Null, juror.GetProperty("pinExpiresAt").ValueKind);
    }

    // ── რა არ შეუძლია ───────────────────────────────────────────────

    [Fact]
    public async Task Moderator_cannot_approve_a_jury_request()
    {
        var formId = await CreateFormAsync();
        var jurorId = await AddJurorAsync(formId);

        var response = await _client.PostAsync($"/api/forms/{formId}/jury/{jurorId}/approve", null);

        Assert.Equal(HttpStatusCode.Forbidden, response.StatusCode);
    }

    [Fact]
    public async Task Moderator_cannot_delete_a_jury_request()
    {
        var formId = await CreateFormAsync();
        var jurorId = await AddJurorAsync(formId);

        var response = await _client.DeleteAsync($"/api/forms/{formId}/jury/{jurorId}");

        Assert.Equal(HttpStatusCode.Forbidden, response.StatusCode);
    }

    /// <summary>იგივე ორდონიანი წესი ფორმაზეც — მოდერატორი აგზავნის, ადმინი ამტკიცებს.</summary>
    [Fact]
    public async Task Moderator_cannot_approve_a_form()
    {
        var formId = await CreateFormAsync();

        Assert.Equal(HttpStatusCode.NoContent,
            (await _client.PostAsync($"/api/forms/{formId}/submit", null)).StatusCode);

        var approve = await _client.PostAsync($"/api/forms/{formId}/approve", null);

        Assert.Equal(HttpStatusCode.Forbidden, approve.StatusCode);
    }

    /// <summary>სხვისი კონკურსი მოდერატორს არც უნდა ჩანდეს — ეს per-project იზოლაციის საზღვარია.</summary>
    [Fact]
    public async Task Moderator_cannot_reach_someone_elses_contest()
    {
        var response = await _client.GetAsync($"/api/forms/{Guid.NewGuid()}");

        // 404-ის ნაცვლად 403: არარსებობასა და „სხვისს" შორის განსხვავება
        // კონკურსის არსებობას ამხელდა
        Assert.Equal(HttpStatusCode.Forbidden, response.StatusCode);
    }
}
