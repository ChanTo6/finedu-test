using FinEdu.Application.Common.Exceptions;
using FinEdu.Application.Common.Models;
using FinEdu.Application.Submissions.Validators;
using FinEdu.Domain.Entities;
using FinEdu.Domain.Enums;
using FinEdu.Domain.ValueObjects;
using Xunit;

namespace FinEdu.UnitTests;

/// <summary>
/// ატვირთვის უსაფრთხოების regression ტესტები — ეს წესები სერვერზეა და
/// ფორმის კონფიგით ვერ შესუსტდება.
/// </summary>
public class FileUploadSecurityTests
{
    private readonly SubmissionValidator _validator = new();

    private static readonly byte[] PdfHeader = [0x25, 0x50, 0x44, 0x46, 0x2D, 0x31, 0x2E, 0x37];
    private static readonly byte[] PngHeader = [0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A];
    private static readonly byte[] MzHeader = [0x4D, 0x5A, 0x90, 0x00, 0x03, 0x00, 0x00, 0x00];  // Windows .exe

    private static FormField FileField(Guid id, FieldConfig? config = null) => new()
    {
        Id = id,
        Type = FieldType.FileUpload,
        Label = "დოკუმენტი",
        IsRequired = false,
        Config = config ?? new FieldConfig()
    };

    private static Form FormWith(params FormField[] fields) => new() { Title = "T", Fields = fields };

    private static CreateSubmissionRequest ConsentGiven() =>
        new([], ConsentDataProcessing: true, null);

    private static SubmissionFileInput File(Guid fieldId, string name, byte[] header, long size = 1024) =>
        new()
        {
            FieldId = fieldId,
            FileName = name,
            ContentType = "application/octet-stream",
            SizeBytes = size,
            Content = new MemoryStream(header)
        };

    [Fact]
    public void Executable_is_rejected_even_when_form_sets_no_allowlist()
    {
        var id = Guid.NewGuid();
        var files = new[] { File(id, "payload.exe", MzHeader) };

        Assert.Throws<ValidationException>(() =>
            _validator.Validate(FormWith(FileField(id)), ConsentGiven(), files));
    }

    [Fact]
    public void Archive_is_rejected_since_zip_rar_were_removed_from_requirements()
    {
        var id = Guid.NewGuid();
        var files = new[] { File(id, "bomb.zip", [0x50, 0x4B, 0x03, 0x04]) };

        Assert.Throws<ValidationException>(() =>
            _validator.Validate(FormWith(FileField(id)), ConsentGiven(), files));
    }

    [Fact]
    public void Renamed_executable_is_rejected_by_signature_check()
    {
        // გაფართოება ნებადართულია, შიგთავსი კი .exe-ა
        var id = Guid.NewGuid();
        var files = new[] { File(id, "invoice.pdf", MzHeader) };

        Assert.Throws<ValidationException>(() =>
            _validator.Validate(FormWith(FileField(id)), ConsentGiven(), files));
    }

    [Fact]
    public void Oversized_file_is_rejected_by_server_policy()
    {
        var id = Guid.NewGuid();
        var files = new[] { File(id, "big.pdf", PdfHeader, FileUploadPolicy.DocumentMaxBytes + 1) };

        Assert.Throws<ValidationException>(() =>
            _validator.Validate(FormWith(FileField(id)), ConsentGiven(), files));
    }

    [Fact]
    public void Form_config_cannot_raise_the_server_size_limit()
    {
        // ადმინი 500 MB-ს ითხოვს, სერვერის მაქსიმუმი დოკუმენტზე 25 MB-ია — მაქსიმუმი იმარჯვებს
        var id = Guid.NewGuid();
        var field = FileField(id, new FieldConfig { MaxFileSizeBytes = 500L * 1024 * 1024 });
        var files = new[] { File(id, "big.pdf", PdfHeader, FileUploadPolicy.DocumentMaxBytes + 1) };

        Assert.Throws<ValidationException>(() =>
            _validator.Validate(FormWith(field), ConsentGiven(), files));
    }

    [Fact]
    public void Too_many_files_are_rejected()
    {
        var id = Guid.NewGuid();
        var files = Enumerable.Range(0, FileUploadPolicy.MaxFilesPerSubmission + 1)
            .Select(i => File(id, $"doc{i}.pdf", PdfHeader))
            .ToArray();

        Assert.Throws<ValidationException>(() =>
            _validator.Validate(FormWith(FileField(id)), ConsentGiven(), files));
    }

    /// <summary>doc §3.2: „მაქს. 3 ფაილი ერთ საბმიშენზე" — ორ ველში 2+2 ზღვარს სცდება.</summary>
    [Fact]
    public void Limit_counts_files_across_all_fields_of_the_submission()
    {
        var a = Guid.NewGuid();
        var b = Guid.NewGuid();
        var files = new[]
        {
            File(a, "a1.pdf", PdfHeader), File(a, "a2.pdf", PdfHeader),
            File(b, "b1.pdf", PdfHeader), File(b, "b2.pdf", PdfHeader)
        };

        var ex = Assert.Throws<ValidationException>(() =>
            _validator.Validate(FormWith(FileField(a), FileField(b)), ConsentGiven(), files));
        Assert.True(ex.Errors.ContainsKey("files"));
    }

    [Fact]
    public void Three_files_split_across_fields_pass()
    {
        var a = Guid.NewGuid();
        var b = Guid.NewGuid();
        var files = new[] { File(a, "a1.pdf", PdfHeader), File(a, "a2.pdf", PdfHeader), File(b, "b1.pdf", PdfHeader) };

        Assert.Null(Record.Exception(() =>
            _validator.Validate(FormWith(FileField(a), FileField(b)), ConsentGiven(), files)));
    }

    [Fact]
    public void Valid_document_passes()
    {
        var id = Guid.NewGuid();
        var files = new[] { File(id, "cv.pdf", PdfHeader) };

        var ex = Record.Exception(() =>
            _validator.Validate(FormWith(FileField(id)), ConsentGiven(), files));

        Assert.Null(ex);
    }

    [Fact]
    public void Valid_image_passes()
    {
        var id = Guid.NewGuid();
        var files = new[] { File(id, "photo.png", PngHeader) };

        var ex = Record.Exception(() =>
            _validator.Validate(FormWith(FileField(id)), ConsentGiven(), files));

        Assert.Null(ex);
    }

    [Fact]
    public void Content_type_comes_from_extension_not_from_client()
    {
        // კლიენტი text/html-ს რომც აცხადებდეს, ჩამოტვირთვისას application/pdf გაიცემა
        Assert.Equal("application/pdf", FileUploadPolicy.ResolveContentType("pdf"));
        Assert.Equal("application/octet-stream", FileUploadPolicy.ResolveContentType("html"));
    }
}
