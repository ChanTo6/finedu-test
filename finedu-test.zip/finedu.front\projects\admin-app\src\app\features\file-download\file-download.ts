import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit, inject, input, signal } from '@angular/core';
import { RouterLink } from '@angular/router';
import { fileNameFromResponse, saveBlob } from 'shared-lib';
import { FormsService } from '../../core/services/forms.service';

/**
 * ატვირთული ფაილის ჩამოტვირთვა პირდაპირი მისამართით: /files/:id
 *
 * <p>Excel-ის ექსპორტში ფაილები სწორედ ამ მისამართზე მიუთითებს. ბმული განზრახ
 * ადმინ-პანელზე მიდის და არა API-ზე: ბრაუზერის ჩვეულებრივი ნავიგაცია Authorization
 * header-ს არ ატარებს, ანუ პირდაპირ API-ზე მიმართვა 401-ს დააბრუნებდა. ასე კი
 * ბმულის შემთხვევით გაზიარება წვდომას არავის აძლევს — გახსნისას შესვლა მოითხოვება.</p>
 */
@Component({
  selector: 'app-file-download',
  imports: [RouterLink],
  template: `
    <div class="file-download">
      <a routerLink="/forms" class="back">← ფორმებზე დაბრუნება</a>

      @if (state() === 'loading') {
        <p class="loading">ფაილი იტვირთება…</p>
      } @else if (state() === 'done') {
        <div class="done">
          <p>
            ჩამოიტვირთა: <strong>{{ fileName() }}</strong>
          </p>
          <button type="button" class="btn-ghost" (click)="download()">ხელახლა ჩამოტვირთვა</button>
        </div>
      } @else {
        <p class="err" role="alert">{{ error() }}</p>
        <button type="button" class="btn-ghost" (click)="download()">ხელახლა ცდა</button>
      }
    </div>
  `,
  styles: `
    :host {
      display: block;
      max-width: 640px;
      margin: 0 auto;
      padding: 2rem 1.5rem;
    }

    .back {
      display: inline-block;
      margin-bottom: 1.5rem;
      color: var(--color-text-secondary);
      font-size: 0.875rem;
    }

    .loading,
    .done {
      padding: 2rem;
      text-align: center;
      background: var(--color-surface);
      border: 1px solid var(--color-border);
      border-radius: var(--radius-lg);
    }

    .err {
      margin-bottom: 1rem;
    }
  `,
})
export class FileDownload implements OnInit {
  private readonly service = inject(FormsService);

  /** route-იდან: /files/:id */
  readonly id = input.required<string>();

  readonly state = signal<'loading' | 'done' | 'failed'>('loading');
  readonly fileName = signal('');
  readonly error = signal('');

  ngOnInit(): void {
    this.download();
  }

  download(): void {
    this.state.set('loading');

    this.service.downloadFile(this.id()).subscribe({
      next: (response) => {
        const name = fileNameFromResponse(response, 'file');
        saveBlob(response.body!, name);
        this.fileName.set(name);
        this.state.set('done');
      },
      error: (e: HttpErrorResponse) => {
        // პასუხი blob-ია, ამიტომ სერვერის ტექსტი აქ არ იკითხება — სტატუსი გვრჩება
        this.error.set(FileDownload.Messages[e.status] ?? 'ფაილი ვერ ჩამოიტვირთა.');
        this.state.set('failed');
      },
    });
  }

  private static readonly Messages: Record<number, string> = {
    403: 'ამ ფაილზე წვდომა არ გაქვთ — კონკურსი სხვას ეკუთვნის.',
    404: 'ფაილი ვეღარ მოიძებნა. შესაძლოა შენახვის ვადა ამოიწურა და წაიშალა.',
  };
}
