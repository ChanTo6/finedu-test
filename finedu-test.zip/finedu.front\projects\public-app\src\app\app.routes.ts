import { Routes } from '@angular/router';
import { Confirmation } from './features/confirmation/confirmation';
import { FormView } from './features/form-view/form-view';

export const routes: Routes = [
  { path: 'f/:token', component: FormView },
  { path: 'f/:token/done', component: Confirmation },
  {
    path: '',
    loadComponent: () => import('./features/landing/landing').then((m) => m.Landing),
  },
  { path: '**', redirectTo: '' },
];
