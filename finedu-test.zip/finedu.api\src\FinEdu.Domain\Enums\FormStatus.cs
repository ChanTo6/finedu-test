namespace FinEdu.Domain.Enums;

/// <summary>ფორმის სასიცოცხლო ციკლი (state machine). 2-დონიანი დადასტურება: Draft→PendingApproval→Live.</summary>
public enum FormStatus
{
    Draft = 1,
    PendingApproval = 2,
    Live = 3,
    Closed = 4
}
