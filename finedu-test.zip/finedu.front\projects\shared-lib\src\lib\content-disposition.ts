import { HttpResponse } from '@angular/common/http';

// RFC 5987: `filename*=UTF-8''%E1%83%A4...` — არალათინური სახელი მხოლოდ აქ ჩანს სრულად.
const Rfc5987 = /filename\*=UTF-8''([^;]+)/i;

// ჩვეულებრივი `filename="..."` — ASCII-ზე დაყვანილი სათადარიგო ვარიანტი.
const Plain = /filename="?([^";]+)"?/i;

/**
 * ჩამოტვირთული ფაილის სახელი პასუხის header-იდან.
 *
 * <p>საჭიროა მაშინ, როცა სახელი წინასწარ ცნობილი არ არის — მაგალითად Excel-ის
 * ბმულით პირდაპირ ფაილის იდენტიფიკატორზე შესვლისას.</p>
 */
export function fileNameFromResponse(response: HttpResponse<unknown>, fallback: string): string {
  const header = response.headers.get('Content-Disposition');
  if (!header) return fallback;

  const encoded = Rfc5987.exec(header)?.[1];
  if (encoded) {
    try {
      return decodeURIComponent(encoded);
    } catch {
      // გაუმართავი კოდირება სახელს არ უნდა შეეცვალოს ჩამოტვირთვა
    }
  }

  return Plain.exec(header)?.[1] ?? fallback;
}
