import { Component, EventEmitter, Input, OnChanges, Output, inject } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { FILE_CATEGORIES } from '../file-categories';
import { FieldType } from '../models/field-type.enum';
import { FormField, UploadLimits } from '../models/form.model';
import { UI_TEXT } from '../ui-text';

/** ერთი სტრიქონი ფაილის ველის ქვეშ: „სურათები: JPG, PNG — მაქს. 10 MB". */
export interface FileRule {
  label: string;
  formats: string;
  maxMb: string;
}

/**
 * ბირთვი: იღებ ველების schema-ს → აგებ Reactive FormGroup-ს → რენდერავ კონტროლებს.
 * იყენებ public-app (შევსება) და admin-app (preview). ერთი კოდი, ორი მიმართულება.
 */
@Component({
  selector: 'lib-dynamic-form',
  imports: [ReactiveFormsModule],
  templateUrl: './dynamic-form.html',
  styleUrl: './dynamic-form.scss',
})
export class DynamicForm implements OnChanges {
  @Input() fields: FormField[] = [];

  /**
   * ატვირთვის სერვერული ლიმიტები. თუ არ მოვიდა, ფაილებს წინასწარ არ ვამოწმებთ —
   * ადმინის preview-ს ლიმიტები არ სჭირდება.
   */
  @Input() uploadLimits?: UploadLimits;

  @Output() formReady = new EventEmitter<FormGroup>();

  readonly FieldType = FieldType;
  protected readonly text = inject(UI_TEXT);
  form: FormGroup = new FormGroup({});
  files: Record<string, File[]> = {};

  /** ფაილის არჩევისთანავე აღმოჩენილი პრობლემა (ზომა/ტიპი/რაოდენობა) — ველის ქვეშ ჩანს. */
  fileErrors: Record<string, string> = {};

  private readonly touchedFiles = new Set<string>();

  constructor(private readonly fb: FormBuilder) {}

  ngOnChanges(): void {
    const group: Record<string, unknown> = {};
    for (const field of this.fields) {
      if (field.type === FieldType.FileUpload) continue; // ფაილები ცალკე ინახება
      const initial = field.type === FieldType.Checkboxes ? [] : '';
      group[field.id] = [initial, field.isRequired ? Validators.required : []];
    }
    this.form = this.fb.group(group);
    this.files = {};
    this.fileErrors = {};
    this.touchedFiles.clear();
    this.formReady.emit(this.form);
  }

  /**
   * ატვირთული ფაილები fieldId → File[] (submit-ისას multipart-ში იგზავნება).
   *
   * აქვე მოწმდება ზომა, ტიპი და რაოდენობა — რომ 200 MB-იანი ვიდეო ტყუილად არ აიტვირთოს
   * და შემდეგ სერვერმა უარი არ თქვას. ეს **მხოლოდ მოხერხებულობაა**: იგივე წესებს
   * სერვერი დამოუკიდებლად ამოწმებს (SubmissionValidator).
   */
  onFileChange(fieldId: string, event: Event): void {
    const input = event.target as HTMLInputElement;
    const field = this.fields.find((f) => f.id === fieldId);
    const selected = input.files ? Array.from(input.files) : [];

    const problem = field ? this.checkFiles(field, selected) : null;
    if (problem) {
      // არჩევანს ვაუქმებთ, რომ მომხმარებელს ეგონოს ატვირთული და გაგზავნისას არ გაუკვირდეს
      input.value = '';
      this.files[fieldId] = [];
      this.fileErrors[fieldId] = problem;
    } else {
      this.files[fieldId] = selected;
      delete this.fileErrors[fieldId];
    }

    this.touchedFiles.add(fieldId);
  }

  /** პირველი აღმოჩენილი პრობლემა ან <c>null</c>, თუ ფაილები წესებს აკმაყოფილებს. */
  private checkFiles(field: FormField, selected: File[]): string | null {
    const limits = this.uploadLimits;
    if (!limits || selected.length === 0) return null;

    // ფორმის კონფიგს მხოლოდ შევიწროება შეუძლია — სერვერზეც ზუსტად ასეა
    const maxFiles = this.maxFilesFor(field);
    if (selected.length > maxFiles) {
      return this.text('form.errFieldMaxFiles', { n: maxFiles });
    }

    // doc §3.2: ზღვარი მთელ განაცხადზეა — სხვა ველებში უკვე არჩეულიც ითვლება
    const total = this.maxFilesTotal;
    const elsewhere = Object.entries(this.files)
      .filter(([id]) => id !== field.id)
      .reduce((sum, [, list]) => sum + list.length, 0);
    if (elsewhere + selected.length > total) {
      return this.text('form.errTotalFiles', { total, elsewhere });
    }

    for (const file of selected) {
      const ext = file.name.split('.').pop()?.toLowerCase() ?? '';
      const policyMax = limits.maxBytesByExtension[ext];

      if (policyMax === undefined) {
        return this.text('form.errTypeNotAllowed', { ext });
      }

      if (field.config.allowedExtensions?.length && !field.config.allowedExtensions.includes(ext)) {
        return this.text('form.errTypeNotForField', { ext });
      }

      const maxBytes = Math.min(field.config.maxFileSizeBytes ?? policyMax, policyMax);
      if (file.size > maxBytes) {
        return this.text('form.errTooLarge', {
          name: file.name,
          size: this.megabytes(file.size),
          max: this.megabytes(maxBytes),
        });
      }
    }

    return null;
  }

  private megabytes(bytes: number): string {
    return (bytes / (1024 * 1024)).toFixed(1).replace(/\.0$/, '');
  }

  /** მთელ განაცხადზე დასაშვები ფაილები (doc §3.2). */
  get maxFilesTotal(): number {
    return this.uploadLimits?.maxFilesPerSubmission ?? 3;
  }

  /** ველის საკუთარი ზღვარი — მხოლოდ მაშინ განსხვავდება, როცა ადმინმა შეავიწროვა. */
  maxFilesFor(field: FormField): number {
    return Math.min(field.config.maxFiles ?? this.maxFilesTotal, this.maxFilesTotal);
  }

  /** ველისთვის დასაშვები გაფართოებები — ცარიელი კონფიგი ძველ ფორმებზე ნიშნავს „პოლიტიკის ყველა". */
  private allowedExtensions(field: FormField): string[] {
    return field.config.allowedExtensions?.length
      ? field.config.allowedExtensions
      : Object.keys(this.uploadLimits?.maxBytesByExtension ?? {});
  }

  /** ფაილის ამრჩევი მხოლოდ დასაშვებ ტიპებს აჩვენებს — სურათების კონკურსზე ვიდეო არც ჩანს. */
  acceptFor(field: FormField): string | null {
    const allowed = this.allowedExtensions(field);
    return allowed.length ? allowed.map((e) => `.${e}`).join(',') : null;
  }

  /**
   * ზომა ტიპზეა დამოკიდებული (სურათი 10 MB, ვიდეო 200 MB), ამიტომ თითო კატეგორია
   * ცალკე სტრიქონით — ერთი საერთო მაქსიმუმი სურათისთვისაც 200 MB-ს აჩვენებდა.
   * ციფრები სერვერის ლიმიტებიდან მოდის, კატეგორიები კი doc §3.2-ის დაჯგუფებიდან.
   */
  fileRules(field: FormField): FileRule[] {
    const limits = this.uploadLimits;
    const allowed = new Set(this.allowedExtensions(field));

    return FILE_CATEGORIES.map((category) => {
      const formats = category.formats.filter((f) => f.extensions.some((e) => allowed.has(e)));
      const exts = formats.flatMap((f) => f.extensions).filter((e) => allowed.has(e));
      const policyMax = Math.max(0, ...exts.map((e) => limits?.maxBytesByExtension[e] ?? 0));
      const bytes = policyMax
        ? Math.min(field.config.maxFileSizeBytes ?? policyMax, policyMax)
        : category.maxMb * 1024 * 1024;

      return {
        label: this.text(`fileCategory.${category.key}`),
        formats: formats.map((f) => f.label).join(', '),
        maxMb: this.megabytes(bytes),
      };
    }).filter((r) => r.formats.length > 0);
  }

  /** კონტროლის id — GUID ციფრით იწყება, ამიტომ პრეფიქსით (CSS-სელექტორისთვისაც ვარგისი). */
  controlId(field: FormField): string {
    return `f-${field.id}`;
  }

  /** წარწერის id — ჯგუფური ველები მასზე მიუთითებენ `aria-labelledby`-ით. */
  labelId(field: FormField): string {
    return `label-${field.id}`;
  }

  /**
   * რომელ კონტროლს ეკუთვნის წარწერა. ჯგუფურ ველებს (არჩევანი, შკალა) ერთი კონტროლი
   * არ აქვთ — იქ წარწერა ჯგუფის სათაურია და `for`-ს არ იღებს: არასწორი `for`
   * უარესია, ვიდრე მისი არარსებობა (წამკითხველი არარსებულ ელემენტს დაეძებდა).
   */
  labelFor(field: FormField): string | null {
    return this.isGroup(field) ? null : this.controlId(field);
  }

  private isGroup(field: FormField): boolean {
    return (
      field.type === FieldType.MultipleChoice ||
      field.type === FieldType.Checkboxes ||
      field.type === FieldType.LinearScale
    );
  }

  /**
   * შკალის მნიშვნელობები. საზღვრები ფორმის კონფიგიდან მოდის, ამიტომ დამცავი
   * შემოწმებაც აქვს: არასწორი ან უსაზღვროდ დიდი დიაპაზონი ათასობით ღილაკს დახატავდა.
   */
  scaleValues(field: FormField): number[] {
    const min = field.config.scaleMin ?? 1;
    const max = field.config.scaleMax ?? 5;
    if (!Number.isInteger(min) || !Number.isInteger(max) || max <= min || max - min > 20) {
      return [1, 2, 3, 4, 5];
    }
    return Array.from({ length: max - min + 1 }, (_, i) => min + i);
  }

  /** არჩევანი ცხადია — სისტემა მომხმარებლის ნაცვლად არაფერს ირჩევს. */
  setScale(field: FormField, value: number): void {
    const control = this.form.get(field.id);
    control?.setValue(value);
    control?.markAsTouched();
  }

  toggleCheckbox(fieldId: string, option: string, checked: boolean): void {
    const control = this.form.get(fieldId);
    const current = (control?.value as string[]) ?? [];
    control?.setValue(checked ? [...current, option] : current.filter((o) => o !== option));
    control?.markAsTouched();
  }

  /** ველის ქვეშ შეცდომის ტექსტის საჩვენებლად საჭირო თუ არა (required, არჩეული/შევსებული არაფერია). */
  isFieldInvalid(field: FormField): boolean {
    if (field.type === FieldType.FileUpload) {
      return field.isRequired && this.touchedFiles.has(field.id) && !this.files[field.id]?.length;
    }
    const control = this.form.get(field.id);
    return !!control && control.invalid && control.touched;
  }

  /** submit-ის მცდელობისას ყველა ველი (მათ შორის ფაილები) "touched"-ად აღნიშნავს, რომ შეცდომები გამოჩნდეს. */
  markAllTouched(): void {
    this.form.markAllAsTouched();
    for (const field of this.fields) {
      if (field.type === FieldType.FileUpload) this.touchedFiles.add(field.id);
    }
  }

  /** true, თუ სავალდებულო ფაილის ველს ფაილი არ აქვს ატვირთული. */
  hasMissingRequiredFiles(): boolean {
    return this.fields.some(
      (f) => f.type === FieldType.FileUpload && f.isRequired && !this.files[f.id]?.length,
    );
  }
}
