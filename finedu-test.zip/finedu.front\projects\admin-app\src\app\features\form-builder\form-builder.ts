import {
  Component,
  DestroyRef,
  Injector,
  OnDestroy,
  OnInit,
  afterNextRender,
  inject,
  input,
  signal,
} from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import {
  FormArray,
  FormBuilder,
  FormControl,
  FormGroup,
  ReactiveFormsModule,
  Validators,
} from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { Observable } from 'rxjs';
import {
  FILE_CATEGORIES,
  FieldConfig,
  FieldType,
  FileCategory,
  FileFormat,
  FormDetail,
  apiErrorMessage,
} from 'shared-lib';
import { CreateFieldRequest, CreateFormRequest } from '../../core/models/form-requests';
import { FormsService } from '../../core/services/forms.service';
import { RichTextEditor } from '../../shared/rich-text-editor/rich-text-editor';

/** დინამიური კონსტრუქტორი — ველების დამატება/წაშლა, ტიპი, options. ქმნის და არედაქტირებს. */
@Component({
  selector: 'app-form-builder',
  imports: [ReactiveFormsModule, RouterLink, RichTextEditor],
  templateUrl: './form-builder.html',
  styleUrl: './form-builder.scss',
})
export class FormBuilderPage implements OnInit, OnDestroy {
  private readonly fb = inject(FormBuilder);
  private readonly service = inject(FormsService);
  private readonly router = inject(Router);
  private readonly destroyRef = inject(DestroyRef);
  private readonly injector = inject(Injector);

  /** route-იდან: /forms/:id/edit — ცარიელია ახალი ფორმის შექმნისას. */
  readonly id = input<string>();

  readonly isEdit = signal(false);
  readonly loading = signal(false);

  readonly FieldType = FieldType;
  readonly fieldTypes = [
    { value: FieldType.ShortAnswer, label: 'მოკლე პასუხი' },
    { value: FieldType.LongAnswer, label: 'გრძელი პასუხი' },
    { value: FieldType.MultipleChoice, label: 'ერთი არჩევანი' },
    { value: FieldType.Checkboxes, label: 'მრავალი არჩევანი' },
    { value: FieldType.LinearScale, label: 'შკალა' },
    { value: FieldType.FileUpload, label: 'ფაილი' },
  ];

  readonly saving = signal(false);
  readonly error = signal<string | null>(null);

  // ქავერ ფოტო: ატვირთვა ხდება მაშინვე, preview კი ლოკალურად ჩანს (სერვერზე მიმართვის გარეშე)
  readonly coverPreview = signal<string | null>(null);
  readonly coverUploading = signal(false);

  /**
   * <c>null</c> — ქავერი არ იცვლება; <c>''</c> — ცხადი წაშლა; სახელი — ჩანაცვლება.
   * სამივე შემთხვევას სერვერი განსხვავებულად კითხულობს (იხ. UpdateFormRequest).
   */
  private coverName: string | null = null;

  /**
   * ფორმის ვერსია — რედაქტირებისას უცვლელად ბრუნდება. თუ ამ დროში სხვამ შეცვალა,
   * სერვერი ცვლილებას არ გაატარებს და კონფლიქტს დააბრუნებს (409).
   */
  private rowVersion: string | null = null;

  /** გვერდიდან გასვლისას ბოლო გადახედვა უნდა გათავისუფლდეს. */
  ngOnDestroy(): void {
    this.showPreview(null);
  }

  onCoverSelected(event: Event): void {
    const input = event.target as HTMLInputElement;
    const file = input.files?.[0];
    if (!file) return;

    this.error.set(null);
    this.showPreview(URL.createObjectURL(file));
    this.coverUploading.set(true);

    this.service.uploadCover(file).subscribe({
      next: (r) => {
        this.coverName = r.coverName;
        this.coverUploading.set(false);
      },
      error: (e) => {
        this.coverName = null;
        this.showPreview(null);
        this.coverUploading.set(false);
        this.error.set(e?.error?.message ?? 'ქავერის ატვირთვა ვერ მოხერხდა.');
      },
    });
  }

  /** ცარიელი სტრიქონი და არა null: სერვერისთვის ეს „წაშალე" და არა „არ შემიცვლია". */
  removeCover(): void {
    this.coverName = '';
    this.showPreview(null);
  }

  /**
   * გადახედვის ჩანაცვლება ძველი ობიექტის URL-ის გათავისუფლებით. createObjectURL
   * ფაილს მეხსიერებაში აჩერებს, სანამ ცხადად არ გაათავისუფლებ — რამდენიმე ცდის
   * შემდეგ ტაბში ათეულობით მეგაბაიტი რჩებოდა.
   */
  private showPreview(url: string | null): void {
    const previous = this.coverPreview();
    if (previous) URL.revokeObjectURL(previous);
    this.coverPreview.set(url);
  }

  readonly form = this.fb.group({
    title: ['', Validators.required],
    description: [''],
    closeDate: [''],
    maxParticipants: [null as number | null],
    retentionDays: [365, Validators.required],
    // PDP §4.1: თანხმობა მხოლოდ პირობების გაცნობის შემდეგ — ცარიელ პირობებზე მოსანიშნი
    // წასაკითხის გარეშე აქტიურდებოდა. რედაქტორი ცარიელ ველზე '' აბრუნებს.
    privacyNoticeHtml: ['', Validators.required],
    confirmationEmailSubject: [''],
    confirmationEmailBody: [''],
    fields: this.fb.array<FormGroup>([]),
  });

  get fields(): FormArray {
    return this.form.get('fields') as FormArray;
  }

  ngOnInit(): void {
    const id = this.id();
    if (!id) return;

    this.isEdit.set(true);
    this.loading.set(true);
    this.service.get(id).subscribe({
      next: (f) => {
        this.populate(f);
        this.loading.set(false);
      },
      error: () => {
        this.error.set('ფორმა ვერ ჩაიტვირთა.');
        this.loading.set(false);
      },
    });
  }

  private populate(f: FormDetail): void {
    this.form.patchValue({
      // გაფორმებული ვერსია, თუ არსებობს — ძველ კონკურსებს ის ჯერ არ აქვთ
      title: f.titleHtml || f.title,
      description: f.description ?? '',
      // <input type="datetime-local"> yyyy-MM-ddTHH:mm-ს ელოდება; სერვერი სრულ ISO-ს აბრუნებს
      closeDate: f.closeDate ? f.closeDate.substring(0, 16) : '',
      maxParticipants: f.maxParticipants ?? null,
      retentionDays: f.retentionDays,
      privacyNoticeHtml: f.privacyNoticeHtml ?? '',
      confirmationEmailSubject: f.confirmationEmailSubject ?? '',
      confirmationEmailBody: f.confirmationEmailBody ?? '',
    });

    this.coverName = f.coverImagePath ?? null;
    this.rowVersion = f.rowVersion ?? null;

    // არსებული ქავერი ავტორიზებული endpoint-იდან — `<img src>`-ით ვერ ჩაიტვირთებოდა.
    // ჩავარდნა კრიტიკული არაა: ფორმა რედაქტირებადი რჩება, უბრალოდ გადახედვის გარეშე.
    if (f.coverImagePath) {
      // takeUntilDestroyed აუცილებელია: გვერდიდან გასვლის შემდეგ მოსული პასუხი
      // ახალ ობიექტის URL-ს შექმნიდა, რომელსაც ngOnDestroy ვეღარ გაათავისუფლებდა.
      this.service
        .cover(f.id)
        .pipe(takeUntilDestroyed(this.destroyRef))
        .subscribe({
          next: (blob) => this.showPreview(URL.createObjectURL(blob)),
          // ჩავარდნა კრიტიკული არაა (მაგ. ფაილი დისკზე აღარ არის) — ფორმა რედაქტირებადი
          // რჩება, უბრალოდ გადახედვის გარეშე. დამმუშავებლის გარეშე ეს კონსოლში
          // დაუჭერელ შეცდომად ჩავარდებოდა.
          error: () => this.showPreview(null),
        });
    }

    this.fields.clear();
    for (const field of f.fields) {
      // ვარიანტები ტიპამდე ივსება: ტიპის ცვლილება ცარიელ ვარიანტს ამატებს, თუ სია ცარიელია
      const group = this.newField(field.config ?? {}, field.config?.options ?? []);
      group.patchValue({
        type: field.type,
        label: field.label,
        isRequired: field.isRequired,
      });
      this.fields.push(group);
    }
  }

  newField(config: FieldConfig = {}, options: string[] = []) {
    const group = this.fb.group({
      type: [FieldType.ShortAnswer, Validators.required],
      label: ['', Validators.required],
      isRequired: [false],

      // ერთი/მრავალი არჩევანის ვარიანტები — თითო ცალკე ველი, როგორც მონაწილე ხედავს
      options: this.fb.array(options.map((o) => this.optionControl(o))),

      // კონსტრუქტორს ამ პარამეტრებისთვის ინტერფეისი არ აქვს (maxWords, შკალის საზღვრები,
      // ფაილის წესები), მაგრამ არსებულ ფორმას ისინი შეიძლება ჰქონდეს. აქ განზრახ
      // ინახება, რომ რედაქტირებამ ისინი არ წაშალოს: აქამდე კონფიგი ცარიელით იცვლებოდა
      // და „მხოლოდ PDF"-ის შეზღუდვა შენახვისთანავე ქრებოდა.
      config: [config],
    });

    // არჩევანის ტიპზე გადასვლისას პირველი ცარიელი ვარიანტი მაშინვე ჩანს —
    // ადმინმა ღილაკის ძებნა არ უნდა დაიწყოს
    group.controls.type.valueChanges
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe((type) => {
        const list = group.controls.options;
        if (this.isChoice(type ?? 0) && list.length === 0) list.push(this.optionControl(''));
      });

    return group;
  }

  addField(): void {
    this.fields.push(this.newField());
  }

  removeField(index: number): void {
    this.fields.removeAt(index);
  }

  isChoice(type: number): boolean {
    return type === FieldType.MultipleChoice || type === FieldType.Checkboxes;
  }

  optionsOf(fieldIndex: number): FormArray<FormControl<string>> {
    return this.fields.at(fieldIndex).get('options') as FormArray<FormControl<string>>;
  }

  optionId(fieldIndex: number, optionIndex: number): string {
    return `opt-${fieldIndex}-${optionIndex}`;
  }

  /** ახალი ვარიანტი `after`-ის შემდეგ (ან ბოლოში) და ფოკუსი მასზე — Google Forms-ის მსგავსად. */
  addOption(fieldIndex: number, after?: number): void {
    const list = this.optionsOf(fieldIndex);
    const at = after === undefined ? list.length : after + 1;
    list.insert(at, this.optionControl(''));
    // setTimeout არა: zoneless რეჟიმში ის ახალი ველის დახატვას უსწრებდა და ფოკუსი ძველში რჩებოდა
    afterNextRender(() => document.getElementById(this.optionId(fieldIndex, at))?.focus(), {
      injector: this.injector,
    });
  }

  removeOption(fieldIndex: number, optionIndex: number): void {
    this.optionsOf(fieldIndex).removeAt(optionIndex);
  }

  /** Enter ვარიანტში ახალ ვარიანტს ამატებს — თორემ მთელ ფორმას გაგზავნიდა. */
  onOptionEnter(event: Event, fieldIndex: number, optionIndex: number): void {
    event.preventDefault();
    this.addOption(fieldIndex, optionIndex);
  }

  /** შკალის გადახედვა — იგივე საზღვრები, რასაც მონაწილის გვერდი იყენებს. */
  scaleValues(fieldIndex: number): number[] {
    const config = (this.fields.at(fieldIndex).get('config')?.value ?? {}) as FieldConfig;
    const min = config.scaleMin ?? 1;
    const max = config.scaleMax ?? 5;
    if (!Number.isInteger(min) || !Number.isInteger(max) || max <= min || max - min > 20) {
      return [1, 2, 3, 4, 5];
    }
    return Array.from({ length: max - min + 1 }, (_, k) => min + k);
  }

  configOf(fieldIndex: number): FieldConfig {
    return (this.fields.at(fieldIndex).get('config')?.value ?? {}) as FieldConfig;
  }

  // ── ფაილის ველის ფორმატები (doc §3.2) ─────────────────────────────

  readonly fileCategories = FILE_CATEGORIES;

  private extensionsOf(fieldIndex: number): string[] {
    return this.configOf(fieldIndex).allowedExtensions ?? [];
  }

  isFormatOn(fieldIndex: number, format: FileFormat): boolean {
    const on = this.extensionsOf(fieldIndex);
    return format.extensions.every((e) => on.includes(e));
  }

  isCategoryOn(fieldIndex: number, category: FileCategory): boolean {
    return category.formats.every((f) => this.isFormatOn(fieldIndex, f));
  }

  isCategoryPartial(fieldIndex: number, category: FileCategory): boolean {
    const on = category.formats.filter((f) => this.isFormatOn(fieldIndex, f)).length;
    return on > 0 && on < category.formats.length;
  }

  hasNoFormats(fieldIndex: number): boolean {
    return this.extensionsOf(fieldIndex).length === 0;
  }

  toggleFormat(fieldIndex: number, format: FileFormat): void {
    const on = !this.isFormatOn(fieldIndex, format);
    this.setFormats(fieldIndex, [format], on);
  }

  /** ჯგუფის მონიშვნა ყველა ფორმატს რთავს; თუ უკვე ყველა ჩართულია — თიშავს. */
  toggleCategory(fieldIndex: number, category: FileCategory): void {
    this.setFormats(fieldIndex, category.formats, !this.isCategoryOn(fieldIndex, category));
  }

  private setFormats(fieldIndex: number, formats: FileFormat[], on: boolean): void {
    const current = new Set(this.extensionsOf(fieldIndex));
    for (const e of formats.flatMap((f) => f.extensions)) {
      if (on) current.add(e);
      else current.delete(e);
    }

    // სიის რიგი ყოველთვის კატეგორიების რიგით — შენახული კონფიგი არჩევის თანმიმდევრობაზე არ იცვლება
    const ordered = FILE_CATEGORIES.flatMap((c) => c.formats)
      .flatMap((f) => f.extensions)
      .filter((e) => current.has(e));

    const control = this.fields.at(fieldIndex).get('config')!;
    control.setValue({ ...this.configOf(fieldIndex), allowedExtensions: ordered });
    control.markAsDirty();
  }

  private optionControl(value: string): FormControl<string> {
    return this.fb.nonNullable.control(value);
  }

  save(): void {
    this.error.set(null);

    if (this.form.invalid) {
      this.form.markAllAsTouched();
      this.error.set('გთხოვთ შეავსოთ ყველა სავალდებულო ველი (მონიშნულია * ნიშნით).');
      return;
    }

    if (this.fields.length === 0) {
      this.error.set('ფორმას მინიმუმ ერთი ველი უნდა ჰქონდეს დამატებული.');
      return;
    }

    if (this.coverUploading()) {
      this.error.set('ქავერი ჯერ იტვირთება — დაელოდეთ დასრულებას.');
      return;
    }

    const optionsByField = this.fields.controls.map((control) =>
      ((control.value.options ?? []) as string[]).map((s) => s.trim()).filter(Boolean),
    );

    // ვარიანტების გარეშე არჩევანის კითხვა მონაწილეს ცარიელი გამოუჩნდებოდა
    const emptyChoice = this.fields.controls.findIndex(
      (control, i) => this.isChoice(control.value.type) && optionsByField[i].length === 0,
    );
    if (emptyChoice >= 0) {
      const label = this.fields.at(emptyChoice).value.label || `№${emptyChoice + 1}`;
      this.error.set(`ველს „${label}" მინიმუმ ერთი ვარიანტი უნდა ჰქონდეს.`);
      return;
    }

    // doc §3.2: ფაილის ველზე ფორმატი ცხადად უნდა იყოს არჩეული (სერვერიც ამოწმებს)
    const noFormats = this.fields.controls.findIndex(
      (control, i) => control.value.type === FieldType.FileUpload && this.hasNoFormats(i),
    );
    if (noFormats >= 0) {
      const label = this.fields.at(noFormats).value.label || `№${noFormats + 1}`;
      this.error.set(`ველს „${label}" მინიმუმ ერთი დასაშვები ფორმატი უნდა ჰქონდეს.`);
      return;
    }

    const v = this.form.getRawValue();
    const fields: CreateFieldRequest[] = this.fields.controls.map((control, i) => {
      const g = control.value;
      const options = optionsByField[i];

      // ვარიანტები ცალკე ველებიდან მოდის, დანარჩენი კონფიგი კი უცვლელად გადადის.
      // ტიპის შეცვლისას ძველი ვარიანტები ცხადად ცვივა — თორემ „მოკლე პასუხს"
      // უხილავი options დარჩებოდა.
      // ფორმატებიც ტიპზეა მიბმული: ფაილიდან სხვა ტიპზე გადასვლისას ცვივა
      const {
        options: _replaced,
        allowedExtensions,
        ...kept
      } = (g.config ?? {}) as FieldConfig;

      return {
        order: i,
        type: g.type,
        label: g.label,
        isRequired: g.isRequired,
        visibleToJury: false,
        config: {
          ...kept,
          ...(this.isChoice(g.type) ? { options } : {}),
          ...(g.type === FieldType.FileUpload ? { allowedExtensions } : {}),
        },
      };
    });

    const request: CreateFormRequest = {
      title: v.title ?? '',
      description: v.description,
      closeDate: v.closeDate || null,
      maxParticipants: v.maxParticipants,
      retentionDays: v.retentionDays ?? 365,
      privacyNoticeHtml: v.privacyNoticeHtml,
      confirmationEmailSubject: v.confirmationEmailSubject,
      confirmationEmailBody: v.confirmationEmailBody,
      coverImagePath: this.coverName,
      fields,
      rowVersion: this.rowVersion,
    };

    const id = this.id();
    const save$: Observable<unknown> = id
      ? this.service.update(id, request)
      : this.service.create(request);

    this.saving.set(true);
    save$.subscribe({
      next: () => this.router.navigate(['/forms']),
      error: (e) => {
        // 409 = ფორმა ამასობაში სხვამ შეცვალა; 400 = ველების შეცდომები.
        // ორივე შემთხვევაში სერვერის ტექსტი ჯობია ზოგადს — მასში წერია, რა ქნას.
        this.error.set(apiErrorMessage(e, 'შენახვა ვერ მოხერხდა.'));
        this.saving.set(false);
      },
    });
  }
}
