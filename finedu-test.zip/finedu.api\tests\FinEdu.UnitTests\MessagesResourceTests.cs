using System.Collections;
using System.Globalization;
using System.Reflection;
using System.Text.RegularExpressions;
using FinEdu.Application.Resources;

namespace FinEdu.UnitTests;

/// <summary>
/// ორენოვანი შეტყობინებები: ინგლისურ ფაილში გამოტოვებული გასაღები ინგლისურ გვერდზე ქართულად
/// გამოჩნდებოდა, განსხვავებული {0}/{1} კი string.Format-ს ჩააგდებდა ან მნიშვნელობას დაკარგავდა.
/// </summary>
public class MessagesResourceTests
{
    private static Dictionary<string, string> Read(CultureInfo culture) =>
        Messages.Resources.GetResourceSet(culture, createIfNotExists: true, tryParents: false)!
            .Cast<DictionaryEntry>()
            .ToDictionary(e => (string)e.Key, e => (string)e.Value!);

    private static readonly Dictionary<string, string> Georgian = Read(CultureInfo.InvariantCulture);
    private static readonly Dictionary<string, string> English = Read(CultureInfo.GetCultureInfo("en"));

    [Fact]
    public void Both_languages_have_the_same_keys()
    {
        Assert.NotEmpty(Georgian);
        Assert.Equal(Georgian.Keys.Order(), English.Keys.Order());
    }

    [Fact]
    public void Every_key_has_an_accessor_and_every_accessor_a_key()
    {
        var members = typeof(Messages)
            .GetMembers(BindingFlags.Public | BindingFlags.Static)
            .Where(m => m is PropertyInfo || (m is MethodInfo mi && !mi.IsSpecialName))
            .Select(m => m.Name)
            .Order();

        Assert.Equal(Georgian.Keys.Order(), members);
    }

    [Fact]
    public void Placeholders_match_between_languages()
    {
        foreach (var (key, ka) in Georgian)
            Assert.True(Placeholders(ka).SetEquals(Placeholders(English[key])), key);
    }

    [Fact]
    public void English_texts_contain_no_georgian_letters()
    {
        foreach (var (key, en) in English)
            Assert.False(Regex.IsMatch(en, "[ა-ჿ]"), key);
    }

    [Fact]
    public void Culture_selects_the_language()
    {
        var original = CultureInfo.CurrentUICulture;
        try
        {
            CultureInfo.CurrentUICulture = CultureInfo.GetCultureInfo("en");
            Assert.Equal("The field \"Name\" is required.", Messages.FieldRequired("Name"));

            CultureInfo.CurrentUICulture = CultureInfo.GetCultureInfo("ka");
            Assert.Equal("ველი „სახელი\" სავალდებულოა.", Messages.FieldRequired("სახელი"));
        }
        finally
        {
            CultureInfo.CurrentUICulture = original;
        }
    }

    private static HashSet<string> Placeholders(string text) =>
        Regex.Matches(text, @"\{\d+\}").Select(m => m.Value).ToHashSet();
}
