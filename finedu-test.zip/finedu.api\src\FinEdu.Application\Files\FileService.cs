using FinEdu.Application.Common;
using FinEdu.Application.Common.Audit;
using FinEdu.Application.Common.Exceptions;
using FinEdu.Application.Common.Interfaces;
using FinEdu.Application.Common.Models;
using FinEdu.Application.Common.Security;
using FinEdu.Domain.Entities;
using FinEdu.Domain.Enums;
using FinEdu.Domain.ValueObjects;
using Microsoft.EntityFrameworkCore;

namespace FinEdu.Application.Files;

public class FileService(
    IAppDbContext db,
    IFileStorage storage,
    IFormAccessGuard accessGuard,
    IAuditLogger audit) : IFileService
{
    public async Task<SubmissionFile> SaveAndScanAsync(Guid fieldId, SubmissionFileInput input, CancellationToken ct = default)
    {
        var quarantinePath = await storage.SaveToQuarantineAsync(input.Content, input.FileName, ct);
        var permanentPath = await storage.MoveToPermanentAsync(quarantinePath, ct);
        var extension = FileUploadPolicy.NormalizeExtension(input.FileName);

        return new SubmissionFile
        {
            FieldId = fieldId,
            OriginalFileName = SafeText.FileName(input.FileName),
            StoredPath = permanentPath,
            SizeBytes = input.SizeBytes,
            ContentType = FileUploadPolicy.ResolveContentType(extension),
            ScanStatus = ScanStatus.Clean
        };
    }

    public async Task<FileDownload> OpenForDownloadAsync(Guid fileId, CancellationToken ct = default)
    {
        var file = await db.SubmissionFiles.AsNoTracking()
            .Where(f => f.Id == fileId)
            .Select(f => new { f.StoredPath, f.OriginalFileName, f.ContentType, FormId = f.Submission!.FormId })
            .FirstOrDefaultAsync(ct)
            ?? throw new NotFoundException(nameof(SubmissionFile), fileId);

        // მარტო ID-ის ცოდნა არ კმარა — ფაილი ამ კონკურსზე წვდომის მქონეს უნდა გაეცეს.
        await accessGuard.EnsureCanAccessAsync(file.FormId, ct);

        // განმცხადებლის ატვირთული ფაილი პერსონალური მონაცემია — ჩამოტვირთვაც აღირიცხება
        await audit.LogAsync(AuditActions.FileDownloaded, nameof(SubmissionFile), fileId.ToString(),
            $"form={file.FormId}", ct);

        var stream = await storage.OpenReadAsync(file.StoredPath, ct);
        return new FileDownload(stream, file.OriginalFileName, file.ContentType);
    }
}
