﻿using FinEdu.Application.Common.Models;
using FinEdu.Application.Submissions;
using FinEdu.Application.Common.Security;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace FinEdu.AdminApi.Controllers;

[ApiController]
[Route("api/forms/{formId:guid}/submissions")]
[Authorize(Policy = Roles.Moderator)]
public class SubmissionsController(ISubmissionService submissions) : ControllerBase
{
    // per-project წვდომა სერვისის ფენაზე მოწმდება (SubmissionService.ListByFormAsync → IFormAccessGuard)
    [HttpGet]
    public async Task<IActionResult> List(Guid formId, [FromQuery] PageQuery query, CancellationToken ct)
        => Ok(await submissions.ListByFormAsync(formId, query, ct));
}
