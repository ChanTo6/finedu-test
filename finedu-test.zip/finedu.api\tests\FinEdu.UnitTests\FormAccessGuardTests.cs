﻿using FinEdu.Application.Common.Exceptions;
using FinEdu.Application.Common.Interfaces;
using FinEdu.Application.Common.Security;
using FinEdu.Domain.Entities;
using FinEdu.Domain.Enums;
using FinEdu.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;
using Xunit;

namespace FinEdu.UnitTests;

/// <summary>
/// per-project წვდომის regression ტესტები (doc §4.1) — ეს ის საზღვარია,
/// რომლის დარღვევაც სხვისი კონკურსანტების პერსონალურ მონაცემებს გაამჟღავნებდა.
/// </summary>
public class FormAccessGuardTests : IDisposable
{
    private readonly AppDbContext _db;

    public FormAccessGuardTests()
    {
        var options = new DbContextOptionsBuilder<AppDbContext>()
            .UseInMemoryDatabase($"access-{Guid.NewGuid()}")
            .Options;
        _db = new AppDbContext(options);
    }

    public void Dispose() => _db.Dispose();

    private Guid SeedForm(string ownerAccount)
    {
        var form = new Form { Title = "კონკურსი", CreatedBy = ownerAccount };
        form.AccessList.Add(new FormAccess { AdAccount = ownerAccount, AccessLevel = AccessLevel.Manager });
        _db.Forms.Add(form);
        _db.SaveChanges();
        return form.Id;
    }

    private FormAccessGuard GuardFor(string? account, bool isAdmin = false) =>
        new(_db, new TestUser(account, isAdmin));

    /// <summary>დამატებითი წვდომა არსებულ კონკურსზე — მითითებული დონით.</summary>
    private void GrantAccess(Guid formId, string account, AccessLevel level)
    {
        _db.FormAccessList.Add(new FormAccess { FormId = formId, AdAccount = account, AccessLevel = level });
        _db.SaveChanges();
    }

    // ── ცვლილების უფლება ────────────────────────────────────────────
    // ორი დონე ბაზაში ეწერა, მაგრამ არსად არ მოწმდებოდა: დამკვირვებელს ფორმის
    // რედაქტირება, ჟიურის მართვა და სხვისთვის წვდომის მინიჭებაც შეეძლო.

    [Fact]
    public async Task Manager_can_change_the_form()
    {
        var formId = SeedForm("nino");

        var ex = await Record.ExceptionAsync(() => GuardFor("nino").EnsureCanManageAsync(formId));
        Assert.Null(ex);
    }

    [Fact]
    public async Task Viewer_can_read_but_cannot_change()
    {
        var formId = SeedForm("nino");
        GrantAccess(formId, "giorgi", AccessLevel.Viewer);

        // კითხვა — შეიძლება
        Assert.Null(await Record.ExceptionAsync(() => GuardFor("giorgi").EnsureCanAccessAsync(formId)));

        // ცვლილება — არა
        await Assert.ThrowsAsync<ForbiddenException>(
            () => GuardFor("giorgi").EnsureCanManageAsync(formId));
    }

    [Fact]
    public async Task Stranger_cannot_change_the_form()
    {
        var formId = SeedForm("nino");

        await Assert.ThrowsAsync<ForbiddenException>(
            () => GuardFor("giorgi").EnsureCanManageAsync(formId));
    }

    [Fact]
    public async Task Administrator_can_change_any_form()
    {
        var formId = SeedForm("nino");

        var ex = await Record.ExceptionAsync(
            () => GuardFor("admin", isAdmin: true).EnsureCanManageAsync(formId));
        Assert.Null(ex);
    }

    [Fact]
    public async Task Owner_can_access_own_form()
    {
        var formId = SeedForm("nino");
        var ex = await Record.ExceptionAsync(() => GuardFor("nino").EnsureCanAccessAsync(formId));
        Assert.Null(ex);
    }

    [Fact]
    public async Task Other_employee_cannot_access_someone_elses_form()
    {
        var formId = SeedForm("nino");

        await Assert.ThrowsAsync<ForbiddenException>(
            () => GuardFor("giorgi").EnsureCanAccessAsync(formId));
    }

    [Fact]
    public async Task Administrator_can_access_any_form()
    {
        var formId = SeedForm("nino");

        var ex = await Record.ExceptionAsync(
            () => GuardFor("admin", isAdmin: true).EnsureCanAccessAsync(formId));
        Assert.Null(ex);
    }

    [Fact]
    public async Task Anonymous_user_cannot_access_admin_data()
    {
        var formId = SeedForm("nino");

        await Assert.ThrowsAsync<ForbiddenException>(
            () => GuardFor(null).EnsureCanAccessAsync(formId));
    }

    [Fact]
    public void Listing_shows_only_accessible_forms()
    {
        SeedForm("nino");
        SeedForm("giorgi");
        SeedForm("giorgi");

        var visible = GuardFor("giorgi").Accessible(_db.Forms).ToList();

        Assert.Equal(2, visible.Count);
        Assert.All(visible, f => Assert.Equal("giorgi", f.CreatedBy));
    }

    [Fact]
    public void Administrator_listing_shows_everything()
    {
        SeedForm("nino");
        SeedForm("giorgi");

        Assert.Equal(2, GuardFor("admin", isAdmin: true).Accessible(_db.Forms).Count());
    }
}
