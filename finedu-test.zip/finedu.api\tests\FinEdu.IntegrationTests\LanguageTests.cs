extern alias publicapi;

using System.Net;
using System.Net.Http.Json;
using System.Text.RegularExpressions;
using UiTextCatalog = publicapi::FinEdu.PublicApi.Common.UiTextCatalog;

namespace FinEdu.IntegrationTests;

/// <summary>
/// საჯარო საიტის ენა: წარწერები /api/ui-texts-იდან, სერვერის შეცდომები — Accept-Language-ის
/// მიხედვით. ნაგულისხმევი ქართულია: ჰედერის გარეშე მოსული მოთხოვნა ინგლისურად არ უნდა ჩანდეს.
/// </summary>
public class LanguageTests(PublicApiFactory factory) : IClassFixture<PublicApiFactory>
{
    private static readonly Regex GeorgianLetters = new("[ა-ჿ]");

    private async Task<Dictionary<string, string>> TextsAsync(string lang)
    {
        var response = await factory.CreateClient().GetAsync($"/api/ui-texts/{lang}");
        response.EnsureSuccessStatusCode();
        return (await response.Content.ReadFromJsonAsync<Dictionary<string, string>>())!;
    }

    [Fact]
    public async Task Both_languages_have_the_same_keys()
    {
        var ka = await TextsAsync("ka");
        var en = await TextsAsync("en");

        Assert.NotEmpty(ka);
        Assert.Equal(ka.Keys.Order(), en.Keys.Order());
        Assert.Equal(UiTextCatalog.Keys(), ka.Keys.Order(StringComparer.Ordinal));
    }

    [Fact]
    public async Task English_texts_contain_no_georgian_letters()
    {
        foreach (var (key, text) in await TextsAsync("en"))
            Assert.False(GeorgianLetters.IsMatch(text), key);
    }

    /// <summary>{label}, {n} და მსგავსი ჩასასმელები ორივე ენაზე ერთნაირი უნდა იყოს.</summary>
    [Fact]
    public async Task Placeholders_match_between_languages()
    {
        var ka = await TextsAsync("ka");
        var en = await TextsAsync("en");

        foreach (var (key, text) in ka)
            Assert.True(Placeholders(text).SetEquals(Placeholders(en[key])), key);
    }

    [Fact]
    public async Task Unknown_language_is_not_found()
    {
        var response = await factory.CreateClient().GetAsync("/api/ui-texts/fr");
        Assert.Equal(HttpStatusCode.NotFound, response.StatusCode);
    }

    /// <summary>ხელახლა გახსნისას ბრაუზერი უცვლელ ტექსტს აღარ იწერს — მხოლოდ 304-ს იღებს.</summary>
    [Fact]
    public async Task Unchanged_texts_answer_not_modified()
    {
        var client = factory.CreateClient();
        var first = await client.GetAsync("/api/ui-texts/ka");
        var etag = first.Headers.ETag!;

        using var request = new HttpRequestMessage(HttpMethod.Get, "/api/ui-texts/ka");
        request.Headers.IfNoneMatch.Add(etag);
        var second = await client.SendAsync(request);

        Assert.Equal(HttpStatusCode.NotModified, second.StatusCode);
    }

    private static HashSet<string> Placeholders(string text) =>
        Regex.Matches(text, @"\{\w+\}").Select(m => m.Value).ToHashSet();
}
