export const environment = {
  production: false,
  // ფარდობითი, როგორც პროდში — dev-სერვერი /api-ს PublicApi-ზე (https://localhost:7001)
  // აგზავნის proxy.conf.json-ით. პირდაპირი მისამართი http://localhost:4200-დან https://localhost:7001-ზე
  // სხვა „საიტად" ითვლებოდა და API-ის Cross-Origin-Resource-Policy: same-site ქავერ ფოტოს ბლოკავდა.
  apiUrl: '/api',
};
