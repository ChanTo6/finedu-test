using FinEdu.Application.Common.Security;
using FinEdu.Infrastructure.Identity;
using FinEdu.Infrastructure.Options;
using Xunit;

namespace FinEdu.UnitTests;

/// <summary>
/// AD ჯგუფი → აპლიკაციის როლი. ეს ერთადერთი ადგილია, სადაც წყდება, ვინ არის
/// ადმინისტრატორი და ვინ მოდერატორი — და ეს გადაწყვეტილება <b>მთლიანად AD-ის
/// ჯგუფებს ეყრდნობა</b>: ჩვენს ბაზაში არც მომხმარებელი ინახება, არც როლი.
///
/// <para>ჯგუფების სახელები (<c>FinEdu-Admins</c>, <c>FinEdu-Users</c>) AD-ის მხარეს
/// ეკუთვნის და კონფიგურაციიდან მოდის — ტესტი მათ არ ცვლის, მხოლოდ თარგმანს ამოწმებს.</para>
/// </summary>
public class AdRoleMappingTests
{
    private static readonly LdapOptions Options = new()
    {
        AdminGroup = "FinEdu-Admins",
        StandardGroup = "FinEdu-Users"
    };

    private const string AdminDn = "CN=FinEdu-Admins,OU=Groups,DC=finedu,DC=local";
    private const string UsersDn = "CN=FinEdu-Users,OU=Groups,DC=finedu,DC=local";
    private const string OtherDn = "CN=Buhgalteria,OU=Groups,DC=finedu,DC=local";

    private static List<string> Map(params string[] memberOf) =>
        LdapAuthenticator.MapRoles(memberOf, Options);

    /// <summary>1) ადმინის ჯგუფი → Administrator (და მოდერატორის უფლებებიც).</summary>
    [Fact]
    public void Admin_group_gives_administrator()
    {
        var roles = Map(AdminDn);

        Assert.Contains(Roles.Administrator, roles);
        Assert.Contains(Roles.Moderator, roles);   // ადმინისტრატორი მოდერატორსაც მოიცავს
    }

    /// <summary>2) FinEdu-Users → Moderator.</summary>
    [Fact]
    public void Users_group_gives_moderator()
    {
        var roles = Map(UsersDn);

        Assert.Equal([Roles.Moderator], roles);
    }

    /// <summary>4) მოდერატორი ადმინისტრატორის უფლებებს ვერ იღებს.</summary>
    [Fact]
    public void Moderator_never_gets_administrator()
    {
        Assert.DoesNotContain(Roles.Administrator, Map(UsersDn));
        Assert.DoesNotContain(Roles.Administrator, Map(UsersDn, OtherDn));
    }

    /// <summary>
    /// 3) ჩვეულებრივი AD მომხმარებელი, რომელიც ვერცერთ დაშვებულ ჯგუფშია — როლის გარეშე.
    /// ბანკის ყველა თანამშრომელი AD-ში წარმატებით bind-დება, ამიტომ სწორედ ეს
    /// შემოწმება წყვეტს, ვინ შემოვა ადმინ-პანელში.
    /// </summary>
    [Fact]
    public void Unrelated_ad_user_gets_no_role()
    {
        Assert.Empty(Map(OtherDn));
        Assert.Empty(Map());
    }

    /// <summary>ორივე ჯგუფის წევრს ორივე როლი აქვს, დუბლიკატების გარეშე.</summary>
    [Fact]
    public void Both_groups_give_both_roles_once()
    {
        var roles = Map(AdminDn, UsersDn);

        Assert.Equal(2, roles.Count);
        Assert.Contains(Roles.Administrator, roles);
        Assert.Contains(Roles.Moderator, roles);
    }

    /// <summary>ჯგუფის მსგავსი, მაგრამ სხვა სახელი უფლებას არ იძლევა.</summary>
    [Fact]
    public void Similar_group_name_is_not_enough()
    {
        Assert.Empty(Map("CN=FinEdu-Admins-Readonly,OU=Groups,DC=finedu,DC=local"));
        Assert.Empty(Map("CN=FinEdu-Users-Archive,OU=Groups,DC=finedu,DC=local"));
    }

    /// <summary>ძველი სახელი <c>StandardUser</c> როლად აღარსად ჩნდება.</summary>
    [Fact]
    public void Legacy_role_name_is_gone()
    {
        Assert.DoesNotContain("StandardUser", Map(AdminDn, UsersDn));
        Assert.Equal("Moderator", Roles.Moderator);
    }
}
