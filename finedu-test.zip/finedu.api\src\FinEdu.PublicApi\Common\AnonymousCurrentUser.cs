using FinEdu.Application.Common.Interfaces;
using FinEdu.Infrastructure.Http;

namespace FinEdu.PublicApi.Common;

/// <summary>
/// საჯარო მხარეს ჩვეულებრივ user არ არის — ვიზიტორს IP-ითა და ანონიმური cookie-ნიშნით
/// ვიცნობთ. ერთადერთი გამონაკლისი ჟიურის სესიაა: მისი მეილი აუდიტში actor-ად უნდა
/// ჩაიწეროს, თორემ ყველა შეფასება „anonymous"-ის სახელით დარჩებოდა.
/// </summary>
public class AnonymousCurrentUser(IHttpContextAccessor http) : ICurrentUser
{
    public string? Account =>
        http.HttpContext?.User.Identity is { IsAuthenticated: true } identity ? identity.Name : null;

    public string? IpAddress => http.HttpContext?.Connection.RemoteIpAddress?.ToString();

    public string? VisitorId => VisitorCookie.Current(http.HttpContext);

    public string? UserAgent => http.HttpContext?.Request.Headers.UserAgent.ToString();

    /// <summary>საჯარო ზონაში ადმინი არასდროსაა — ჟიურიც გარე მომხმარებელია.</summary>
    public bool IsAdministrator => false;
}
