﻿using FinEdu.Domain.Common;

namespace FinEdu.Domain.Entities;

/// <summary>ჟიურის ერთი წევრის შეფასება ერთ განაცხადზე. (JurorId, SubmissionId) უნიკალურია.</summary>
public class Evaluation : BaseEntity
{
    public Guid JurorId { get; set; }
    public Juror? Juror { get; set; }

    public Guid SubmissionId { get; set; }
    public Submission? Submission { get; set; }

    /// <summary>ქულა შკალაზე <see cref="ScoreMin"/>–<see cref="ScoreMax"/>.</summary>
    public int Score { get; set; }

    public string? Comment { get; set; }

    /// <summary>კომენტარის ჭერი — იგივე რიცხვი დგას სვეტზეც (EvaluationConfiguration).</summary>
    public const int CommentMaxLength = 2000;

    public DateTimeOffset UpdatedAt { get; set; } = DateTimeOffset.UtcNow;

    public const int ScoreMin = 1;
    public const int ScoreMax = 10;
}
