/** კონკურსზე წვდომის მოდელები — backend-ის `FormAccessModels.cs`-ის სარკე. */

/** backend-ის AccessLevel enum-ის იდენტური (ერთი და იგივე რიცხვები). */
export enum AccessLevel {
  /** ნახვა, ფაილები, ექსპორტი — ცვლილების გარეშე. */
  Viewer = 1,

  /** ყველაფერი ზემოთ + ფორმის რედაქტირება, დახურვა, ჟიურისა და წვდომების მართვა. */
  Manager = 2,
}

/**
 * ვის რა უფლება აქვს ამ კონკურსზე.
 *
 * აქ მხოლოდ AD ანგარიშია — სახელი, განყოფილება და პაროლი AD-შია და იქვე რჩება.
 * ეს სია არსებულ მომხმარებელთა სისტემას არ ცვლის და არ იმეორებს.
 */
export interface FormAccess {
  id: string;
  adAccount: string;
  accessLevel: AccessLevel;
  grantedAt: string;
  grantedBy?: string | null;
}

export interface GrantFormAccessRequest {
  adAccount: string;
  accessLevel: AccessLevel;
}
