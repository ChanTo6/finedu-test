/**
 * ბაიტები საკითხავ ზომად. ორივე აპლიკაცია აჩვენებს ატვირთული ფაილის ზომას —
 * ადმინი განაცხადებში, ჟიური შესაფასებელ სიაში — და ფუნქცია ორივეგან სიტყვასიტყვით
 * ერთნაირად იყო გადაწერილი.
 */
export function formatFileSize(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${Math.round(bytes / 1024)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}
