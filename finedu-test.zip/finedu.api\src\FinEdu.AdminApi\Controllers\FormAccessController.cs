﻿using FinEdu.Application.Common.Models;
using FinEdu.Application.Common.Validation;
using FinEdu.Application.Common.Security;
using FinEdu.Application.Forms;
using FluentValidation;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace FinEdu.AdminApi.Controllers;

/// <summary>
/// კონკურსზე წვდომის მართვა — ვის შეუძლია ამ კონკურსის ნახვა და მართვა.
/// per-project წვდომა სერვისის ფენაზე მოწმდება (FormAccessService → IFormAccessGuard).
///
/// <para>მომხმარებლების სია, პაროლები და ჯგუფები AD-შია — აქ მხოლოდ ანგარიშსა და
/// კონკურსს შორის კავშირი ინახება.</para>
/// </summary>
[ApiController]
[Route("api/forms/{formId:guid}/access")]
[Authorize(Policy = Roles.Moderator)]
public class FormAccessController(
    IFormAccessService access,
    IValidator<GrantFormAccessRequest> grantValidator) : ControllerBase
{
    [HttpGet]
    public async Task<ActionResult<IReadOnlyList<FormAccessDto>>> List(Guid formId, CancellationToken ct)
        => Ok(await access.ListAsync(formId, ct));

    /// <summary>წვდომის მინიჭება ან არსებული დონის შეცვლა.</summary>
    [HttpPost]
    public async Task<IActionResult> Grant(Guid formId, [FromBody] GrantFormAccessRequest request,
        CancellationToken ct)
    {
        (await grantValidator.ValidateAsync(request, ct)).ThrowIfInvalid();

        await access.GrantAsync(formId, request, ct);
        return NoContent();
    }

    /// <summary>
    /// წვდომის მოხსნა ჩანაწერის id-ით და არა ანგარიშის სახელით: AD-ის სახელი
    /// შეიძლება შეიცავდეს <c>\</c>-ს ან <c>@</c>-ს, რაც მისამართში კოდირებას მოითხოვდა.
    /// </summary>
    [HttpDelete("{accessId:guid}")]
    public async Task<IActionResult> Revoke(Guid formId, Guid accessId, CancellationToken ct)
    {
        await access.RevokeAsync(formId, accessId, ct);
        return NoContent();
    }
}
