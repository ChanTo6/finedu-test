using FinEdu.Application.Common.Interfaces;
using FinEdu.Domain.Entities;
using Microsoft.EntityFrameworkCore;

namespace FinEdu.Infrastructure.Identity;

/// <summary>
/// გაუქმებული ტოკენები ბაზაში — მეხსიერებაში შენახვა რესტარტზე დაიკარგებოდა და
/// უკვე „გამოსული" მომხმარებლის ტოკენი ისევ იმუშავებდა.
/// ვადაგასულ ჩანაწერებს Worker-ის დამლაგებელი job შლის.
/// </summary>
public class TokenRevocationStore(IAppDbContext db) : ITokenRevocationStore
{
    public async Task RevokeAsync(string jti, DateTimeOffset expiresAt, CancellationToken ct = default)
    {
        if (await db.RevokedTokens.AnyAsync(t => t.Jti == jti, ct)) return;

        db.RevokedTokens.Add(new RevokedToken { Jti = jti, ExpiresAt = expiresAt });
        await db.SaveChangesAsync(ct);
    }

    public Task<bool> IsRevokedAsync(string jti, CancellationToken ct = default) =>
        db.RevokedTokens.AsNoTracking().AnyAsync(t => t.Jti == jti, ct);
}
