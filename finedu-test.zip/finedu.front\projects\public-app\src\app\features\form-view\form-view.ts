import { HttpEvent, HttpEventType } from '@angular/common/http';
import {
  Component,
  ElementRef,
  OnInit,
  ViewChild,
  computed,
  inject,
  signal,
  viewChild,
} from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import {
  CreateSubmission,
  DynamicForm,
  PublicForm,
  SubmissionValueInput,
  TrustedHtmlPipe,
  apiErrorMessage,
} from 'shared-lib';
import { TPipe } from '../../core/pipes/t.pipe';
import { I18nService } from '../../core/services/i18n.service';
import { PublicFormsService } from '../../core/services/public-forms.service';

@Component({
  selector: 'app-form-view',
  imports: [DynamicForm, FormsModule, RouterLink, TrustedHtmlPipe, TPipe],
  templateUrl: './form-view.html',
  styleUrl: './form-view.scss',
})
export class FormView implements OnInit {
  private readonly route = inject(ActivatedRoute);
  private readonly router = inject(Router);
  private readonly service = inject(PublicFormsService);
  private readonly i18n = inject(I18nService);

  @ViewChild(DynamicForm) dynamicForm?: DynamicForm;

  readonly form = signal<PublicForm | null>(null);
  readonly loading = signal(true);
  readonly error = signal<string | null>(null);
  readonly submitting = signal(false);

  readonly uploadPercent = signal<number | null>(null);

  readonly stage = signal('common.sending');

  token = '';

  // GDPR consent
  consentDataProcessing = false;
  notificationEmail = '';

  private readonly noticeDialog = viewChild<ElementRef<HTMLDialogElement>>('noticeDialog');

  readonly noticeOpened = signal(false);

  readonly canConsent = computed(() => !this.form()?.privacyNoticeHtml || this.noticeOpened());

  ngOnInit(): void {
    this.token = this.route.snapshot.paramMap.get('token') ?? '';
    this.service.getByToken(this.token).subscribe({
      next: (f) => {
        this.form.set(f);
        this.loading.set(false);
      },
      error: () => {
        this.error.set(this.i18n.t('form.notFound'));
        this.loading.set(false);
      },
    });
  }

  openNotice(): void {
    this.noticeOpened.set(true);
    this.noticeDialog()?.nativeElement.showModal();
  }

  closeNotice(agreed: boolean): void {
    if (agreed) this.consentDataProcessing = true;
    this.noticeDialog()?.nativeElement.close();
  }

  submit(): void {
    const df = this.dynamicForm;
    const f = this.form();
    if (!df || !f) return;

    this.error.set(null);

    if (df.form.invalid || df.hasMissingRequiredFiles()) {
      df.markAllTouched();
      this.error.set(this.i18n.t('form.fillRequired'));
      return;
    }

    if (!this.consentDataProcessing) {
      this.error.set(
        this.i18n.t(this.canConsent() ? 'form.consentRequired' : 'form.readNoticeFirst'),
      );
      return;
    }

    const values: SubmissionValueInput[] = f.fields
      .filter((x) => df.form.get(x.id) !== null)
      .map((x) => ({ fieldId: x.id, value: this.asString(df.form.get(x.id)?.value) }));

    const payload: CreateSubmission = {
      values,
      consentDataProcessing: this.consentDataProcessing,
      notificationEmail: this.notificationEmail || null,
    };

    this.uploadPercent.set(null);
    this.submitting.set(true);
    this.stage.set('common.sending');

    this.service.submit(this.token, payload, df.files).subscribe({
      next: (event) => this.trackProgress(event),
      error: (e) => {
        this.error.set(apiErrorMessage(e, this.i18n.t('form.submitFailed')));
        this.uploadPercent.set(null);
        this.submitting.set(false);
      },
    });
  }

  private trackProgress(event: HttpEvent<{ id: string }>): void {
    if (event.type === HttpEventType.UploadProgress && event.total) {
      const percent = Math.round((event.loaded / event.total) * 100);
      this.uploadPercent.set(percent);
      if (percent >= 100) this.stage.set('form.stageProcessing');
      return;
    }

    if (event.type === HttpEventType.Response) {
      void this.router.navigate(['/f', this.token, 'done']);
    }
  }

  coverUrl(): string {
    return this.service.coverUrl(this.token);
  }

  private asString(value: unknown): string | null {
    if (value === null || value === undefined) return null;
    if (Array.isArray(value)) return value.join(', ');
    return String(value);
  }
}
