# FinEdu Front (Angular 21)

ერთი workspace, 2 აპლიკაცია + საერთო ბიბლიოთეკა.

```
projects/
  shared-lib/    models + dynamic-form (ბირთვი — schema → Reactive Form)
  public-app/    საჯარო ფორმის შევსება (token-ით, anonymous)
  admin-app/     ადმინი (AD login/JWT, form-builder, forms list, export)
```

## გაშვება (dev)

ორი ცალკე აპლიკაციაა — რომელიც გინდა, ის უნდა გაუშვა:

```bash
npm install
npm run start:public    # http://localhost:4200 — კონკურსების კატალოგი, შესვლის გარეშე
npm run start:admin     # http://localhost:4300 — ადმინის პანელი, AD ავტორიზაციით
```

| მისამართი | ვისთვის | ავტორიზაცია |
|---|---|---|
| `localhost:4200` | მოქალაქე — კონკურსების დათვალიერება და განაცხადის შევსება | არ სჭირდება |
| `localhost:4300` | თანამშრომელი — ფორმების მართვა, განაცხადების ნახვა | AD login |

პორტები `angular.json`-შია მიბმული, ამიტომ `ng serve public-app` და `ng serve admin-app`
პირდაპირაც სწორ პორტზე გაეშვება.

## build
```bash
ng build shared-lib   # (არასავალდებ. — აპები source-იდან იღებენ)
ng build public-app
ng build admin-app
```

## არქიტექტურა (მოკლედ)
- **shared-lib/dynamic-form** — იღებ `FormField[]` schema-ს, აგებ `FormGroup`-ს დინამიურად, რენდერავ 6 ველის ტიპს. `public` ავსებს, `admin` preview-ს უკეთებს.
- **admin-app/form-builder** — `FormArray`-ით ველების დამატება/წაშლა → აწარმოებ schema-ს → backend `FormField`-ებად ინახება.
- **FieldType enum** ორივე მხარეს იდენტურია (`shared-lib` ↔ backend `FieldType`).
- **admin**: `authInterceptor` (JWT), `errorInterceptor` (401→login), `authGuard`/`adminGuard`.
- **API base URL**: `projects/*/src/environments/environment.ts` (public → 7001, admin → 7002).

## რაც ჯერ არ არის
- **FormAccess-ის მართვა** — კოლეგისთვის კონკურსზე წვდომის მიცემა; backend-შიც endpoint არ არსებობს
- ველების **drag & drop** გადაწყობა (Angular CDK) — ახლა თანმიმდევრობა `order`-ით განისაზღვრება
- form-builder-ში **preview** `lib-dynamic-form`-ით
- **ავტოტესტები** — 2 spec ფაილი; backend 71 ტესტით იფარება
