namespace FinEdu.IntegrationTests;

/// <summary>
/// უსაფრთხოების header-ები რეალურ პასუხზე. middleware რომ მილსადენიდან ამოვარდეს,
/// აპლიკაცია ისევ იმუშავებდა — ეს ტესტი სწორედ ასეთ ჩუმ რეგრესს იჭერს.
/// </summary>
public class SecurityHeaderTests(AdminApiFactory factory) : IClassFixture<AdminApiFactory>
{
    private readonly HttpClient _client = factory.CreateClient();

    [Theory]
    [InlineData("X-Content-Type-Options", "nosniff")]
    [InlineData("X-Frame-Options", "DENY")]
    [InlineData("Referrer-Policy", "no-referrer")]
    [InlineData("Content-Security-Policy", "default-src 'none'; frame-ancestors 'none'")]
    public async Task Response_carries_security_header(string header, string expected)
    {
        var response = await _client.GetAsync("/api/forms");

        Assert.True(response.Headers.TryGetValues(header, out var values), $"{header} აკლია");
        Assert.Equal(expected, values!.Single());
    }

    /// <summary>ადმინის პასუხები პერსონალურ მონაცემებს შეიცავს — proxy-მ არ უნდა დაქეშოს.</summary>
    [Fact]
    public async Task Admin_responses_are_not_cacheable()
    {
        var response = await _client.GetAsync("/api/forms");

        Assert.NotNull(response.Headers.CacheControl);
        Assert.True(response.Headers.CacheControl!.NoStore);
    }

    [Fact]
    public async Task Server_does_not_advertise_its_stack()
    {
        var response = await _client.GetAsync("/api/forms");

        Assert.False(response.Headers.Contains("X-Powered-By"));
    }
}

/// <summary>
/// შეცდომის პასუხებსაც სჭირდება იგივე header-ები. შეცდომების დამმუშავებელი პასუხს
/// ასუფთავებს (Response.Clear()) — ადრე სწორედ ამის გამო 400/404/409 პასუხები
/// header-ების გარეშე გადიოდა და ეს არსად ჩანდა.
/// </summary>
public class ErrorResponseSecurityHeaderTests(PublicApiFactory factory) : IClassFixture<PublicApiFactory>
{
    [Theory]
    [InlineData("X-Content-Type-Options")]
    [InlineData("X-Frame-Options")]
    [InlineData("Content-Security-Policy")]
    public async Task Handled_error_response_still_carries_security_headers(string header)
    {
        var client = factory.CreateClient();

        // უცნობი ბმული → NotFoundException → პასუხს შეცდომების დამმუშავებელი წერს
        var response = await client.GetAsync($"/api/forms/{Guid.NewGuid():N}");

        Assert.Equal(System.Net.HttpStatusCode.NotFound, response.StatusCode);
        Assert.True(response.Headers.Contains(header), $"{header} აკლია შეცდომის პასუხს");
    }
}
