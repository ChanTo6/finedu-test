using FinEdu.Application.Common.Audit;
using FinEdu.Application.Common.Exceptions;
using FinEdu.Application.Common.Interfaces;
using FinEdu.Application.Common.Options;
using FinEdu.Application.Common.Security;
using FinEdu.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;

namespace FinEdu.Application.Export;

public class ExportService(
    IAppDbContext db,
    IExcelExporter exporter,
    IFormAccessGuard accessGuard,
    IAuditLogger audit,
    IOptions<AdminAppOptions> adminApp) : IExportService
{
    private readonly AdminAppOptions _adminApp = adminApp.Value;

    public async Task<byte[]> ExportFormAsync(Guid formId, CancellationToken ct = default)
    {
        // ექსპორტი მთელ პერსონალურ მონაცემს იღებს — წვდომა აუცილებლად უნდა შემოწმდეს.
        await accessGuard.EnsureCanAccessAsync(formId, ct);

        var form = await db.Forms.AsNoTracking()
            .Include(f => f.Fields.OrderBy(x => x.Order))
            .FirstOrDefaultAsync(f => f.Id == formId, ct)
            ?? throw new NotFoundException(nameof(Form), formId);

        // values × files დეკარტული ნამრავლის გარეშე — ექსპორტი მთელ კონკურსს იღებს,
        // ანუ სწორედ აქ ჯდებოდა ყველაზე ძვირად (იხ. SubmissionService.ListByFormAsync).
        var submissions = await db.Submissions.AsNoTracking()
            .Include(s => s.Values)
            .Include(s => s.Files)
            .Where(s => s.FormId == formId)
            .OrderBy(s => s.SubmittedAt)
            .AsSplitQuery()
            .ToListAsync(ct);

        var fields = form.Fields.OrderBy(f => f.Order).ToList();

        // თითო ფაილი ცალკე სვეტში: Excel-ის უჯრას მხოლოდ ერთი ბმული შეიძლება ჰქონდეს,
        // ერთ უჯრაში ჩამოთვლილი სახელები კი დაწკაპუნებადი ვერ იქნებოდა.
        var maxFiles = submissions.Count == 0 ? 0 : submissions.Max(s => s.Files.Count);

        var sheet = new ExcelSheet { Name = "Submissions" };

        // ID — განაცხადის უცვლელი იდენტიფიკატორი; სწორედ ის ჩანს ფაილის ბმულშიც
        sheet.Headers.Add("ID");
        sheet.Headers.Add("რეგისტრაციის თარიღი/დრო");
        sheet.Headers.AddRange(fields.Select(f => f.Label));   // თითო ველი → სვეტი
        for (var i = 1; i <= maxFiles; i++)
            sheet.Headers.Add($"ფაილი {i}");

        foreach (var s in submissions)
        {
            var valueByField = s.Values.ToDictionary(v => v.FieldId, v => v.Value);
            var row = new List<string>
            {
                s.Id.ToString(),
                // წამებით: ერთსა და იმავე წუთში შემოსული განაცხადები რიგითობით უნდა დალაგდეს
                s.SubmittedAt.ToString("yyyy-MM-dd HH:mm:ss")
            };
            row.AddRange(fields.Select(f => valueByField.GetValueOrDefault(f.Id) ?? ""));

            var firstFileColumn = row.Count;
            var files = s.Files.OrderBy(f => f.OriginalFileName).ToList();

            for (var i = 0; i < files.Count; i++)
            {
                row.Add(files[i].OriginalFileName);

                var link = FileLink(files[i].Id);
                if (link is not null)
                    sheet.Links[(sheet.Rows.Count, firstFileColumn + i)] = link;
            }

            // სვეტების რაოდენობა ყველა სტრიქონზე ერთნაირი უნდა იყოს
            while (row.Count < sheet.Headers.Count) row.Add("");

            sheet.Rows.Add(row);
        }

        // ექსპორტი მთელ პერსონალურ მონაცემს ფაილად გაიტანს სისტემიდან — ეს ყველაზე
        // მნიშვნელოვანი ჩანაწერია ჟურნალში: ვინ, როდის და რამდენი განაცხადი გადმოწერა.
        await audit.LogAsync(AuditActions.ExportDownloaded, nameof(Form), formId.ToString(),
            $"submissions={submissions.Count}", ct);

        return exporter.Export(sheet);
    }

    /// <summary>
    /// ფაილის ბმული ადმინ-პანელზე. მისამართის გარეშე ბმული საერთოდ არ ჩაისმება —
    /// გაუმართავი ბმული უარესია, ვიდრე მისი არარსებობა (იხ. AdminAppOptions).
    /// </summary>
    private string? FileLink(Guid fileId) =>
        string.IsNullOrWhiteSpace(_adminApp.BaseUrl)
            ? null
            : $"{_adminApp.BaseUrl.TrimEnd('/')}/files/{fileId}";
}
