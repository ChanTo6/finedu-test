using System.Net;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text.Json;

namespace FinEdu.IntegrationTests;

/// <summary>
/// წვდომის მართვა HTTP დონეზე — მარშრუტები, პოლიტიკა და ვალიდაცია.
/// უფლებების სემანტიკა (ვის რა შეუძლია მინიჭების შემდეგ) unit ტესტებით იფარება,
/// სადაც ორი სხვადასხვა მომხმარებელი შეიძლება ერთსა და იმავე ბაზაზე იმუშაოს.
///
/// <para>მოდერატორად ვმუშაობთ განზრახ: სწორედ მას სჭირდება სხვისი კონკურსის მართვა,
/// და აქვე ჩანს, რომ ეს უფლება ადმინისტრატორობას არ ნიშნავს.</para>
/// </summary>
public class FormAccessApiTests : IAsyncLifetime
{
    private readonly ModeratorApiFactory _factory = new();
    private HttpClient _client = null!;

    public async Task InitializeAsync()
    {
        _client = _factory.CreateClient();

        var login = await _client.PostAsJsonAsync("/api/auth/login",
            new { username = "tester", password = "test-password" });
        login.EnsureSuccessStatusCode();

        var body = await login.Content.ReadFromJsonAsync<JsonElement>();
        _client.DefaultRequestHeaders.Authorization =
            new AuthenticationHeaderValue("Bearer", body.GetProperty("token").GetString());
    }

    public Task DisposeAsync()
    {
        _factory.Dispose();
        return Task.CompletedTask;
    }

    private async Task<string> CreateFormAsync()
    {
        var response = await _client.PostAsJsonAsync("/api/forms", new
        {
            title = "წვდომის კონკურსი",
            retentionDays = 30,
            privacyNoticeHtml = "<p>პირობები</p>",
            fields = new[] { new { order = 0, type = 1, label = "სახელი", isRequired = false, config = new { } } }
        });
        response.EnsureSuccessStatusCode();

        return (await response.Content.ReadFromJsonAsync<JsonElement>()).GetProperty("id").GetString()!;
    }

    private async Task<JsonElement> ListAsync(string formId) =>
        await _client.GetFromJsonAsync<JsonElement>($"/api/forms/{formId}/access");

    /// <summary>შემქმნელი ავტომატურად მმართველია — სია ცარიელი არასდროსაა.</summary>
    [Fact]
    public async Task Creator_is_listed_as_manager()
    {
        var formId = await CreateFormAsync();

        var entry = (await ListAsync(formId)).EnumerateArray().Single();

        Assert.Equal("tester", entry.GetProperty("adAccount").GetString());
        Assert.Equal(2, entry.GetProperty("accessLevel").GetInt32());   // Manager
    }

    [Fact]
    public async Task Manager_can_grant_and_revoke()
    {
        var formId = await CreateFormAsync();

        var grant = await _client.PostAsJsonAsync($"/api/forms/{formId}/access",
            new { adAccount = "giorgi", accessLevel = 2 });
        Assert.Equal(HttpStatusCode.NoContent, grant.StatusCode);

        var added = (await ListAsync(formId)).EnumerateArray()
            .Single(e => e.GetProperty("adAccount").GetString() == "giorgi");
        Assert.Equal("tester", added.GetProperty("grantedBy").GetString());

        var revoke = await _client.DeleteAsync(
            $"/api/forms/{formId}/access/{added.GetProperty("id").GetString()}");
        Assert.Equal(HttpStatusCode.NoContent, revoke.StatusCode);

        Assert.Single((await ListAsync(formId)).EnumerateArray());
    }

    /// <summary>ხელახალი მინიჭება დონეს ცვლის და დუბლიკატს არ ქმნის.</summary>
    [Fact]
    public async Task Granting_twice_updates_the_level()
    {
        var formId = await CreateFormAsync();

        await _client.PostAsJsonAsync($"/api/forms/{formId}/access",
            new { adAccount = "giorgi", accessLevel = 1 });
        await _client.PostAsJsonAsync($"/api/forms/{formId}/access",
            new { adAccount = "giorgi", accessLevel = 2 });

        var rows = (await ListAsync(formId)).EnumerateArray()
            .Where(e => e.GetProperty("adAccount").GetString() == "giorgi")
            .ToList();

        Assert.Single(rows);
        Assert.Equal(2, rows[0].GetProperty("accessLevel").GetInt32());
    }

    [Theory]
    [InlineData("", 2)]
    [InlineData("   ", 2)]
    [InlineData("giorgi", 7)]   // არარსებული დონე
    public async Task Invalid_grant_is_rejected(string account, int level)
    {
        var formId = await CreateFormAsync();

        var response = await _client.PostAsJsonAsync($"/api/forms/{formId}/access",
            new { adAccount = account, accessLevel = level });

        Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);
    }

    /// <summary>საკუთარი წვდომის მოხსნა კონკურსზე დაბრუნებას შეუძლებელს გახდიდა.</summary>
    [Fact]
    public async Task Own_access_cannot_be_revoked()
    {
        var formId = await CreateFormAsync();
        var own = (await ListAsync(formId)).EnumerateArray().Single();

        var response = await _client.DeleteAsync(
            $"/api/forms/{formId}/access/{own.GetProperty("id").GetString()}");

        Assert.Equal(HttpStatusCode.Conflict, response.StatusCode);
    }

    /// <summary>სხვისი კონკურსის წვდომების ნახვა არ უნდა გამოვიდეს.</summary>
    [Fact]
    public async Task Access_list_of_another_contest_is_forbidden()
    {
        var response = await _client.GetAsync($"/api/forms/{Guid.NewGuid()}/access");

        Assert.Equal(HttpStatusCode.Forbidden, response.StatusCode);
    }
}
