﻿using System.Diagnostics;
using System.Text.Json;
using FinEdu.Application.Common.Exceptions;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using FinEdu.Application.Resources;

namespace FinEdu.Infrastructure.Http;

/// <summary>
/// გლობალური შეცდომების დამუშავება ორივე API-სთვის (ადრე თითოში ცალკე ეწერა).
/// მთავარი წესი: შიდა დეტალები (stack trace, SQL, გზები) კლიენტამდე არასდროს მიდის —
/// მხოლოდ ლოგში, პასუხში კი traceId, რომლითაც ლოგში მოიძებნება.
/// </summary>
public static class ExceptionHandlingMiddleware
{
    public static IApplicationBuilder UseFinEduExceptionHandling(this IApplicationBuilder app) =>
        app.Use(async (ctx, next) =>
        {
            var logger = ctx.RequestServices
                .GetRequiredService<ILoggerFactory>()
                .CreateLogger("FinEdu.ExceptionHandling");
            try
            {
                await next();
            }
            catch (ValidationException ex)
            {
                await Write(ctx, StatusCodes.Status400BadRequest, new { message = ex.Message, errors = ex.Errors });
            }
            catch (UnauthenticatedException ex)
            {
                // ლოგში მხოლოდ ფაქტი და გზა — არც ტოკენი, არც PIN
                // მისამართი ნიღბით — ჟიურის ბმულის token ჟურნალში არ უნდა მოხვდეს
                // (იხ. LogSafePath). სწორედ ეს ჩანაწერი ჩნდება ყოველ არასწორ PIN-ზე.
                logger.LogWarning("ვინაობა ვერ დადასტურდა: {Path}", LogSafePath.Of(ctx.Request.Path));
                await Write(ctx, StatusCodes.Status401Unauthorized, new { message = ex.Message });
            }
            catch (ForbiddenException ex)
            {
                logger.LogWarning("წვდომა უარყოფილია: {Path} · {Actor}",
                    LogSafePath.Of(ctx.Request.Path), ctx.User.Identity?.Name);
                await Write(ctx, StatusCodes.Status403Forbidden, new { message = ex.Message });
            }
            catch (NotFoundException ex)
            {
                await Write(ctx, StatusCodes.Status404NotFound, new { message = ex.Message });
            }
            catch (DomainException ex)
            {
                await Write(ctx, StatusCodes.Status409Conflict, new { message = ex.Message });
            }
            catch (ServiceUnavailableException ex)
            {
                // ინფრასტრუქტურის პრობლემაა და არა მომხმარებლის — ოპერაციებმა ლოგში უნდა დაინახოს
                logger.LogError(ex, "გარე სერვისი მიუწვდომელია: {Path}", LogSafePath.Of(ctx.Request.Path));
                await Write(ctx, StatusCodes.Status503ServiceUnavailable, new { message = ex.Message });
            }
            catch (OperationCanceledException) when (ctx.RequestAborted.IsCancellationRequested)
            {
                // კლიენტმა გათიშა — არც შეცდომაა, არც სალოგავი (499 = client closed request)
                if (!ctx.Response.HasStarted) ctx.Response.StatusCode = 499;
            }
            catch (Exception ex)
            {
                var traceId = Activity.Current?.Id ?? ctx.TraceIdentifier;
                logger.LogError(ex, "დაუმუშავებელი შეცდომა · traceId={TraceId}", traceId);
                await Write(ctx, StatusCodes.Status500InternalServerError,
                    new { message = Messages.ServerError, traceId });
            }
        });

    private static async Task Write(HttpContext ctx, int code, object body)
    {
        if (ctx.Response.HasStarted) return;   // პასუხი უკვე დაიწყო — ვეღარაფერს ვცვლით

        ctx.Response.Clear();
        ctx.Response.StatusCode = code;
        ctx.Response.ContentType = "application/json; charset=utf-8";
        await ctx.Response.WriteAsync(JsonSerializer.Serialize(body));
    }
}
