import { Component, OnInit, inject, signal } from '@angular/core';
import { DatePipe } from '@angular/common';
import { RouterLink } from '@angular/router';
import { PublicFormListItem } from 'shared-lib';
import { TPipe } from '../../core/pipes/t.pipe';
import { I18nService } from '../../core/services/i18n.service';
import { PublicFormsService } from '../../core/services/public-forms.service';

/** გამოცხადებული კონკურსების საჯარო კატალოგი — ავტორიზაციის გარეშე. */
@Component({
  selector: 'app-landing',
  imports: [RouterLink, DatePipe, TPipe],
  templateUrl: './landing.html',
  styleUrl: './landing.scss',
})
export class Landing implements OnInit {
  private readonly service = inject(PublicFormsService);
  private readonly i18n = inject(I18nService);

  readonly forms = signal<PublicFormListItem[]>([]);
  readonly loading = signal(true);
  readonly error = signal<string | null>(null);

  ngOnInit(): void {
    this.service.list().subscribe({
      next: (f) => {
        this.forms.set(f);
        this.loading.set(false);
      },
      error: () => {
        this.error.set(this.i18n.t('landing.loadError'));
        this.loading.set(false);
      },
    });
  }

  coverUrl(token: string): string {
    return this.service.coverUrl(token);
  }
}
