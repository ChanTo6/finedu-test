using System.Globalization;
using System.Resources;

namespace FinEdu.Application.Resources;

/// <summary>
/// მომხმარებლისთვის განკუთვნილი შეტყობინებები — ქართული <c>Messages.resx</c>-ში, ინგლისური
/// <c>Messages.en.resx</c>-ში. ენას მოთხოვნის კულტურა (<see cref="CultureInfo.CurrentUICulture"/>) ირჩევს.
/// თითო გასაღებს აქ თავისი წევრი აქვს, რომ სახელში შეცდომა კომპილაციამ დაიჭიროს;
/// ორივე ფაილის სისრულეს ტესტი ამოწმებს (MessagesResourceTests).
/// </summary>
public static class Messages
{
    internal static readonly ResourceManager Resources = new(typeof(Messages));

    private static string Get(string key) =>
        Resources.GetString(key, CultureInfo.CurrentUICulture) ?? key;

    private static string Format(string key, params object[] args) =>
        string.Format(CultureInfo.CurrentCulture, Get(key), args);

    public static string ValidationFailed => Get(nameof(ValidationFailed));
    public static string NotFound(string name, object key) => Format(nameof(NotFound), name, key);
    public static string ServerError => Get(nameof(ServerError));
    public static string InvalidPayload => Get(nameof(InvalidPayload));

    public static string ConsentRequired => Get(nameof(ConsentRequired));
    public static string TooManyFilesTotal(int max) => Format(nameof(TooManyFilesTotal), max);
    public static string InvalidEmail => Get(nameof(InvalidEmail));
    public static string UnknownField => Get(nameof(UnknownField));
    public static string FileOnNonFileField => Get(nameof(FileOnNonFileField));
    public static string FieldRequired(string label) => Format(nameof(FieldRequired), label);
    public static string AnswerTooLong(string label) => Format(nameof(AnswerTooLong), label);
    public static string MaxWords(string label, int max) => Format(nameof(MaxWords), label, max);
    public static string InvalidOption(string label) => Format(nameof(InvalidOption), label);
    public static string ScaleOutOfRange(string label) => Format(nameof(ScaleOutOfRange), label);
    public static string FileRequired(string label) => Format(nameof(FileRequired), label);
    public static string MaxFilesInField(string label, int max) => Format(nameof(MaxFilesInField), label, max);
    public static string FileTypeNotAllowed(string label) => Format(nameof(FileTypeNotAllowed), label);
    public static string FileExtensionNotAllowed(string label, string ext) =>
        Format(nameof(FileExtensionNotAllowed), label, ext);
    public static string FileTooLarge(string label, long maxMb) => Format(nameof(FileTooLarge), label, maxMb);
    public static string FileContentMismatch(string label) => Format(nameof(FileContentMismatch), label);
    public static string FileThreatDetected => Get(nameof(FileThreatDetected));
    public static string FileScanUnavailable => Get(nameof(FileScanUnavailable));

    public static string CaptchaFailed => Get(nameof(CaptchaFailed));
    public static string FormClosedDeadline => Get(nameof(FormClosedDeadline));
    public static string FormClosedLimit => Get(nameof(FormClosedLimit));
    public static string AlreadySubmittedFromDevice => Get(nameof(AlreadySubmittedFromDevice));
    public static string AlreadySubmittedWithEmail => Get(nameof(AlreadySubmittedWithEmail));
    public static string TooManyFromNetwork => Get(nameof(TooManyFromNetwork));

    public static string JuryAccessDenied => Get(nameof(JuryAccessDenied));
    public static string JuryLockedOut(int minutes) => Format(nameof(JuryLockedOut), minutes);
    public static string JuryPinExpired => Get(nameof(JuryPinExpired));
    public static string JuryPinFormat => Get(nameof(JuryPinFormat));
    public static string JuryScoreRange(int min, int max) => Format(nameof(JuryScoreRange), min, max);
    public static string JuryCommentTooLong(int max) => Format(nameof(JuryCommentTooLong), max);
    public static string JurySuspended => Get(nameof(JurySuspended));
    public static string JurySessionIncomplete => Get(nameof(JurySessionIncomplete));
}
