import { FieldType } from './field-type.enum';

/**
 * backend-ის FormStatus-ის იდენტური (ერთი და იგივე რიცხვები).
 *
 * აქამდე სტატუსი უბრალოდ `number` იყო და შაბლონებში მაგიური რიცხვებით მოწმდებოდა
 * (`f.status === 3`) — backend-ის enum-ის ცვლილება frontend-ს ჩუმად აცდებოდა.
 */
export enum FormStatus {
  Draft = 1,
  PendingApproval = 2,
  Live = 3,
  Closed = 4,
}

export interface FieldConfig {
  maxWords?: number;
  options?: string[];
  scaleMin?: number;
  scaleMax?: number;
  scaleMinLabel?: string;
  scaleMaxLabel?: string;
  maxFiles?: number;
  allowedExtensions?: string[];
  maxFileSizeBytes?: number;
}

export interface FormField {
  id: string;
  order: number;
  type: FieldType;
  label: string;
  isRequired: boolean;
  config: FieldConfig;

  /** ხედავს თუ არა ჟიური ამ ველის პასუხს. ნაგულისხმევად — არა. */
  visibleToJury?: boolean;
}

/** გამოცხადებული კონკურსი საჯარო კატალოგში (ავტორიზაციის გარეშე). */
export interface PublicFormListItem {
  title: string;
  description?: string;
  /** აქვს თუ არა ქავერი — თვითონ ფოტო ცალკე endpoint-იდან იტვირთება token-ით. */
  hasCover: boolean;
  closeDate?: string;
  publicToken: string;
}

/**
 * ატვირთვის სერვერული ლიმიტები — ფორმასთან ერთად მოდის, რომ ბრაუზერმა ატვირთვამდე
 * გააფრთხილოს. სერვერი იმავეს დამოუკიდებლად ამოწმებს: ეს მხოლოდ მოხერხებულობაა,
 * დაცვის ბარიერი — არა.
 */
export interface UploadLimits {
  /** doc §3.2: ყველა ფაილის ველში ერთად, მთელ განაცხადზე. */
  maxFilesPerSubmission: number;

  /** გაფართოება (წერტილის გარეშე, lowercase) → მაქსიმალური ბაიტები. */
  maxBytesByExtension: Record<string, number>;
}

/** საჯარო ფორმა (token-ით). */
export interface PublicForm {
  /** ტექსტური სათაური — ჩანართისთვის და გაფორმების არარსებობისას. */
  title: string;

  /** გაფორმებული სათაური გვერდის თავზე. სერვერზე გაწმენდილი (იხ. `trustedHtml`). */
  titleHtml?: string;

  description?: string;
  hasCover: boolean;
  privacyNoticeHtml?: string;
  fields: FormField[];
  uploadLimits: UploadLimits;
}

/** ადმინის სია. */
export interface FormSummary {
  id: string;
  title: string;
  status: FormStatus;
  closeDate?: string;
  submissionCount: number;
}

/** ადმინის სრული ფორმა (რედაქტირება). */
export interface FormDetail {
  id: string;

  /** ტექსტური სათაური — Excel-ის ფაილის სახელისა და სიების მისაღებად. */
  title: string;

  /** გაფორმებული სათაური — რედაქტორი სწორედ ამას ტვირთავს. */
  titleHtml?: string;
  description?: string;
  closeDate?: string;
  maxParticipants?: number;
  retentionDays: number;
  privacyNoticeHtml?: string;
  coverImagePath?: string;
  status: FormStatus;
  publicToken: string;
  fields: FormField[];

  /** დასტურის წერილი — თითო კონკურსს თავისი ტექსტი. ცარიელი = ნაგულისხმევი. */
  confirmationEmailSubject?: string;
  confirmationEmailBody?: string;

  /**
   * ფორმის ვერსია. რედაქტირებისას უცვლელად უნდა დაბრუნდეს — თუ ამ დროში სხვამ
   * შეცვალა, სერვერი ცვლილებას არ გაატარებს და კონფლიქტს დააბრუნებს.
   */
  rowVersion?: string | null;
}
