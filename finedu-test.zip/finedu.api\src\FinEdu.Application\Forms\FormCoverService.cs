using FinEdu.Application.Common.Audit;
using FinEdu.Application.Common.Exceptions;
using FinEdu.Application.Common.Interfaces;
using FinEdu.Application.Common.Models;
using FinEdu.Application.Common.Security;
using FinEdu.Domain.Entities;
using FinEdu.Domain.ValueObjects;
using Microsoft.EntityFrameworkCore;

namespace FinEdu.Application.Forms;

/// <summary>
/// კონკურსის ქავერ ფოტოს სიცოცხლის ციკლი: ატვირთვა, გაცემა და მიტოვებულების გასუფთავება.
///
/// <para>ფორმის სასიცოცხლო ციკლისგან ცალკეა განზრახ: ეს ფაილების მართვაა (დისკი,
/// ფორმატები, გასუფთავება), ფორმის სერვისი კი კონკურსის მდგომარეობას უვლის. ერთად
/// ისინი ერთ კლასს ორ სხვადასხვა მიზეზით აცვლევინებდნენ.</para>
///
/// <para>ფაილის სახელს <see cref="CoverName"/> ამოწმებს — იგივე წესები, რაც ფორმის
/// შენახვისას მოქმედებს.</para>
/// </summary>
public interface IFormCoverService
{
    /// <summary>ატვირთვა. აბრუნებს მხოლოდ ფაილის სახელს — სერვერის გზა კლიენტამდე არასდროს მიდის.</summary>
    Task<string> UploadAsync(Stream content, string fileName, long sizeBytes, CancellationToken ct = default);

    /// <summary>
    /// ქავერი ადმინის მხრიდან — სტატუსის მიუხედავად, რომ რედაქტირებისას ჩანდეს,
    /// რა არის უკვე ატვირთული. წვდომა ფორმის წესებით მოწმდება.
    /// </summary>
    Task<CoverImage> GetForFormAsync(Guid formId, CancellationToken ct = default);

    /// <summary>საჯარო გაცემა token-ით — მხოლოდ გამოცხადებული (Live) კონკურსისთვის.</summary>
    Task<CoverImage> GetPublicAsync(string publicToken, CancellationToken ct = default);

    /// <summary>
    /// ობოლი ქავერების წაშლა — ატვირთულია, მაგრამ ვერცერთი ფორმა მასზე აღარ მიუთითებს
    /// (Worker-ი იძახებს).
    /// </summary>
    Task<int> PurgeOrphansAsync(CancellationToken ct = default);
}

public class FormCoverService(
    IAppDbContext db,
    IFileStorage storage,
    IFormAccessGuard accessGuard,
    IAuditLogger audit) : IFormCoverService
{
    /// <summary>
    /// რამდენ ხანს არ ვეხებით ახლად ატვირთულ ქავერს. ატვირთვა და ფორმის შენახვა ორი
    /// ცალკე მოქმედებაა — ადმინს შეიძლება ფორმა ღია ჰქონდეს და ჯერ არ შეენახა.
    /// კონსტანტაა და არა კონფიგი: შემთხვევით დაყენებული პატარა მნიშვნელობა
    /// მოქმედ ფაილს წაშლიდა.
    /// </summary>
    private static readonly TimeSpan OrphanGrace = TimeSpan.FromHours(24);

    public async Task<string> UploadAsync(Stream content, string fileName, long sizeBytes,
        CancellationToken ct = default)
    {
        var ext = FileUploadPolicy.NormalizeExtension(fileName);
        if (!FileUploadPolicy.IsAllowedImage(ext))
            throw new ValidationException("cover", "ქავერი უნდა იყოს სურათი (JPG, PNG ან GIF).");

        if (sizeBytes > FileUploadPolicy.ImageMaxBytes)
            throw new ValidationException("cover", "ქავერის ზომა არ უნდა აღემატებოდეს 10 MB-ს.");

        // შიგთავსიც უნდა იყოს ნამდვილი სურათი, არა გადარქმეული ფაილი
        if (!FileSignature.MatchesStream(ext, content))
            throw new ValidationException("cover", "ფაილის შიგთავსი არ შეესაბამება სურათის ფორმატს.");

        var coverName = await storage.SaveCoverAsync(content, fileName, ct);
        await audit.LogAsync(AuditActions.CoverUploaded, nameof(Form), null, coverName, ct);
        return coverName;
    }

    public async Task<CoverImage> GetForFormAsync(Guid formId, CancellationToken ct = default)
    {
        // ქავერი კონკურსის მონაცემია — ნახვის უფლება იმავე წესით მოწმდება, რაც ფორმისა.
        // საჯარო endpoint-ისგან განსხვავებით სტატუსს არ ვამოწმებთ: მონახაზის ქავერიც
        // უნდა ჩანდეს, თორემ რედაქტირებისას ადმინი ვერ ხედავდა, რა ატვირთა.
        await accessGuard.EnsureCanAccessAsync(formId, ct);

        var coverName = await db.Forms.AsNoTracking()
            .Where(f => f.Id == formId)
            .Select(f => f.CoverImagePath)
            .FirstOrDefaultAsync(ct);

        return await OpenAsync(coverName, formId, ct);
    }

    public async Task<CoverImage> GetPublicAsync(string publicToken, CancellationToken ct = default)
    {
        var coverName = await db.Forms.AsNoTracking()
            .Where(f => f.PublicToken == publicToken && f.Status == Domain.Enums.FormStatus.Live)
            .Select(f => f.CoverImagePath)
            .FirstOrDefaultAsync(ct);

        return await OpenAsync(coverName, publicToken, ct);
    }

    public async Task<int> PurgeOrphansAsync(CancellationToken ct = default)
    {
        var stored = await storage.ListCoversAsync(ct);
        if (stored.Count == 0) return 0;

        // პირველი ორი ბარიერი: მხოლოდ ჩვენ მიერ გაცემული ფორმატის სახელები (უცხო ფაილს
        // საერთოდ არ ვეხებით) და მხოლოდ დაცდის ვადაზე ძველი — ახლახან ატვირთული ქავერი
        // შეიძლება ჯერ კიდევ ღია ფორმაში იყოს და შენახვას ელოდებოდეს.
        var cutoff = DateTimeOffset.UtcNow - OrphanGrace;
        var candidates = stored
            .Where(c => CoverName.IsStored(c.FileName) && c.CreatedAt <= cutoff)
            .Select(c => c.FileName)
            .ToList();

        if (candidates.Count == 0) return 0;

        // მესამე ბარიერი: ბაზაში მითითებული ყველა სახელი — სტატუსის მიუხედავად.
        // მთელ სიას ვიღებთ და არა candidates-ით ფილტრს: ფორმები ცოტაა, ხოლო
        // ასეულობით სახელიანი IN-სია მოთხოვნას გაამძიმებდა.
        var referenced = await db.Forms.AsNoTracking()
            .Where(f => f.CoverImagePath != null)
            .Select(f => f.CoverImagePath!)
            .ToListAsync(ct);

        var orphans = candidates.Except(referenced, StringComparer.OrdinalIgnoreCase).ToList();
        if (orphans.Count == 0) return 0;

        foreach (var orphan in orphans)
            await storage.DeleteCoverAsync(orphan, ct);

        // ფაილების წაშლა — თუნდაც უსარგებლოების — ჟურნალში უნდა ჩანდეს
        await audit.LogAsync(AuditActions.CoversPurged, nameof(Form), null, $"covers={orphans.Count}", ct);
        return orphans.Count;
    }

    /// <summary>
    /// სახელის შემოწმება და ნაკადის გახსნა. საჯარო და ადმინის გზას ერთი და იგივე წესები
    /// აქვს (ფორმატის შემოწმება ბაზაშიც — რომ ძველმა ან გაფუჭებულმა ჩანაწერმა ვერაფერი
    /// გახსნას; content type მხოლოდ გაფართოებიდან). განსხვავებული მხოლოდ ისაა, ვის რა
    /// შემთხვევაში ეძლევა.
    /// </summary>
    private async Task<CoverImage> OpenAsync(string? coverName, object key, CancellationToken ct)
    {
        if (!CoverName.IsStored(coverName))
            throw new NotFoundException("Cover", key);

        var contentType = FileUploadPolicy.ResolveContentType(FileUploadPolicy.NormalizeExtension(coverName!));
        return new CoverImage(await storage.OpenCoverAsync(coverName!, ct), contentType);
    }
}
