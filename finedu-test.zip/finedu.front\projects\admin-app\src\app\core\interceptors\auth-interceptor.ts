import { HttpInterceptorFn } from '@angular/common/http';
import { inject } from '@angular/core';
import { environment } from '../../../environments/environment';
import { AuthService } from '../services/auth.service';

/**
 * JWT-ს ამატებს *მხოლოდ ჩვენი* API-ს მოთხოვნებს.
 *
 * ადრე ტოკენი ყველა გამავალ მოთხოვნას ემატებოდა — თუ გვერდი ოდესმე გარე მისამართს
 * მიმართავს (შრიფტი, რუკა, ანალიტიკა), ადმინის ტოკენი იმ სერვერს გაჰყვებოდა.
 */
export const authInterceptor: HttpInterceptorFn = (req, next) => {
  const token = inject(AuthService).token;
  const isOwnApi = req.url.startsWith(environment.apiUrl) || req.url.startsWith('/api');

  if (token && isOwnApi) {
    req = req.clone({ setHeaders: { Authorization: `Bearer ${token}` } });
  }
  return next(req);
};
