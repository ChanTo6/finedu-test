﻿using System.Text.Json;
using FinEdu.Domain.Entities;
using FinEdu.Domain.ValueObjects;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.ChangeTracking;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace FinEdu.Infrastructure.Persistence.Configurations;

public class FormConfiguration : IEntityTypeConfiguration<Form>
{
    public void Configure(EntityTypeBuilder<Form> b)
    {
        b.Property(f => f.Title).HasMaxLength(300).IsRequired();
        // TitleHtml სიგრძით არ იზღუდება: გაფორმების ტეგები თვითონ იკავებს ადგილს და
        // 300-სიმბოლოიანი სათაურიც კი ადვილად სცდება ამ ზღვარს მარკირებასთან ერთად.
        b.Property(f => f.PublicToken).HasMaxLength(64).IsRequired();
        b.Property(f => f.ConfirmationEmailSubject).HasMaxLength(300);

        // კონკურენტული რედაქტირება: SQL Server თავად ზრდის ამ სვეტს ყოველ UPDATE-ზე
        // და EF მას WHERE-ში სვამს — ორი პარალელური რედაქტირებიდან მეორე ვერაფერს
        // იპოვის და კონფლიქტად დაბრუნდება (იხ. Form.RowVersion).
        b.Property(f => f.RowVersion).IsRowVersion();
        b.HasIndex(f => f.PublicToken).IsUnique();
        b.HasIndex(f => f.Status);
        b.HasMany(f => f.Fields).WithOne(x => x.Form!).HasForeignKey(x => x.FormId).OnDelete(DeleteBehavior.Cascade);
        b.HasMany(f => f.Submissions).WithOne(x => x.Form!).HasForeignKey(x => x.FormId).OnDelete(DeleteBehavior.Cascade);
        b.HasMany(f => f.AccessList).WithOne(x => x.Form!).HasForeignKey(x => x.FormId).OnDelete(DeleteBehavior.Cascade);
    }
}

public class FormFieldConfiguration : IEntityTypeConfiguration<FormField>
{
    private static readonly JsonSerializerOptions Json = new();

    public void Configure(EntityTypeBuilder<FormField> b)
    {
        b.Property(f => f.Label).HasMaxLength(500).IsRequired();

        // FieldConfig → JSON სვეტი (nvarchar(max))
        b.Property(f => f.Config)
            .HasConversion(
                v => JsonSerializer.Serialize(v, Json),
                v => JsonSerializer.Deserialize<FieldConfig>(v, Json) ?? new FieldConfig())
            .HasColumnType("nvarchar(max)")
            .Metadata.SetValueComparer(new ValueComparer<FieldConfig>(
                (a, c) => JsonSerializer.Serialize(a, Json) == JsonSerializer.Serialize(c, Json),
                v => JsonSerializer.Serialize(v, Json).GetHashCode(),
                v => JsonSerializer.Deserialize<FieldConfig>(JsonSerializer.Serialize(v, Json), Json)!));
    }
}

public class SubmissionValueConfiguration : IEntityTypeConfiguration<SubmissionValue>
{
    public void Configure(EntityTypeBuilder<SubmissionValue> b)
    {
        // FormField-ზეც cascade რომ არ დაჯდეს — Form->FormField->SubmissionValue
        // და Form->Submission->SubmissionValue ორმაგ cascade გზას ქმნიდა (SQL Server-ს ეს ეკრძალება).
        b.HasOne(v => v.Field).WithMany()
            .HasForeignKey(v => v.FieldId)
            .OnDelete(DeleteBehavior.Restrict);
    }
}

public class FormAccessConfiguration : IEntityTypeConfiguration<FormAccess>
{
    public void Configure(EntityTypeBuilder<FormAccess> b)
    {
        // სიგრძის გარეშე სვეტი nvarchar(max) იყო და ინდექსს ვერ იღებდა — ეს ცხრილი კი
        // *ყოველ* ავტორიზებულ მოთხოვნაზე იკითხება (IFormAccessGuard).
        b.Property(a => a.AdAccount).HasMaxLength(256).IsRequired();

        // ერთი ანგარიში ერთ კონკურსზე ერთხელ: დუბლიკატი ორ ჩანაწერს შექმნიდა და
        // წვდომის მოხსნა მხოლოდ ერთს მოხსნიდა — მეორე ჩუმად დარჩებოდა ძალაში.
        b.HasIndex(a => new { a.FormId, a.AdAccount }).IsUnique();
    }
}

public class SubmissionConfiguration : IEntityTypeConfiguration<Submission>
{
    public void Configure(EntityTypeBuilder<Submission> b)
    {
        b.HasIndex(s => s.FormId);
        b.Property(s => s.NotificationEmail).HasMaxLength(320);
        b.Property(s => s.VisitorId).HasMaxLength(64);
        b.Property(s => s.SubmitterIp).HasMaxLength(64);
        b.Property(s => s.UserAgent).HasMaxLength(512);

        // გაორმაგებული განაცხადის შემოწმება ყოველ გაგზავნაზე ხდება — ინდექსის გარეშე
        // ეს მთელი ცხრილის სკანირება იყო. სამივე ნიშანი ერთსა და იმავე მოთხოვნაში
        // მოწმდება (SubmissionService.EnsureNotDuplicateAsync), ამიტომ სამივეს სჭირდება.
        b.HasIndex(s => new { s.FormId, s.VisitorId });
        b.HasIndex(s => new { s.FormId, s.SubmitterIp });
        b.HasIndex(s => new { s.FormId, s.NotificationEmail });

        b.HasMany(s => s.Values).WithOne(x => x.Submission!).HasForeignKey(x => x.SubmissionId).OnDelete(DeleteBehavior.Cascade);
        b.HasMany(s => s.Files).WithOne(x => x.Submission!).HasForeignKey(x => x.SubmissionId).OnDelete(DeleteBehavior.Cascade);
    }
}

public class SubmissionFileConfiguration : IEntityTypeConfiguration<SubmissionFile>
{
    public void Configure(EntityTypeBuilder<SubmissionFile> b)
    {
        b.Property(f => f.OriginalFileName).HasMaxLength(500);
        b.Property(f => f.StoredPath).HasMaxLength(1000);
        b.Property(f => f.ContentType).HasMaxLength(255);
    }
}

public class AuditLogConfiguration : IEntityTypeConfiguration<AuditLog>
{
    public void Configure(EntityTypeBuilder<AuditLog> b)
    {
        b.Property(a => a.Actor).HasMaxLength(256).IsRequired();
        b.Property(a => a.Action).HasMaxLength(128).IsRequired();
        b.Property(a => a.EntityType).HasMaxLength(128);
        b.Property(a => a.EntityId).HasMaxLength(64);
        b.Property(a => a.Details).HasMaxLength(2000);
        b.Property(a => a.IpAddress).HasMaxLength(64);
        b.Property(a => a.VisitorId).HasMaxLength(64);
        b.Property(a => a.UserAgent).HasMaxLength(512);
        b.HasIndex(a => a.CreatedAt);
        b.HasIndex(a => a.Actor);
        // „ამ IP-მ/მოწყობილობამ რა გააკეთა" — ინციდენტის გამოძიების ძირითადი კითხვა
        b.HasIndex(a => a.IpAddress);
        b.HasIndex(a => a.VisitorId);
    }
}

public class JurorConfiguration : IEntityTypeConfiguration<Juror>
{
    public void Configure(EntityTypeBuilder<Juror> b)
    {
        b.Property(j => j.Email).HasMaxLength(320).IsRequired();
        b.Property(j => j.DisplayName).HasMaxLength(200).IsRequired();
        b.Property(j => j.AccessToken).HasMaxLength(64).IsRequired();
        // PIN დადასტურებამდე არ არსებობს — სვეტები nullable-ია (იხ. Juror.PinHash)
        b.Property(j => j.PinHash).HasMaxLength(128);
        b.Property(j => j.PinSalt).HasMaxLength(64);

        // ბმულით შესვლა ყოველ ჯერზე ამ ინდექსით ხდება; უნიკალურიც, რომ ორმა ჟიურიმ
        // ერთი და იგივე token ვერასდროს მიიღოს (თუნდაც გენერაცია გაიმეოროს).
        b.HasIndex(j => j.AccessToken).IsUnique();

        // ერთი მეილი ერთ კონკურსზე მხოლოდ ერთხელ — ორმაგი მოწვევა და ორმაგი ხმა გამორიცხულია
        b.HasIndex(j => new { j.FormId, j.Email }).IsUnique();

        b.Property(j => j.ApprovedBy).HasMaxLength(256);

        // ადმინი დასადასტურებელ მოთხოვნებს კონკურსის ჟიურის გვერდზე ხედავს — სია სტატუსით ილაგება
        b.HasIndex(j => new { j.FormId, j.Status });

        b.HasOne(j => j.Form).WithMany(f => f.Jurors)
            .HasForeignKey(j => j.FormId)
            .OnDelete(DeleteBehavior.Cascade);
    }
}

public class EvaluationConfiguration : IEntityTypeConfiguration<Evaluation>
{
    public void Configure(EntityTypeBuilder<Evaluation> b)
    {
        b.Property(e => e.Comment).HasMaxLength(Evaluation.CommentMaxLength);

        // თითო ჟიური თითო განაცხადს ერთხელ აფასებს — ხელახალი გაგზავნა ცვლის, არ ამატებს
        b.HasIndex(e => new { e.JurorId, e.SubmissionId }).IsUnique();

        // retention-ის წაშლა განაცხადს შვილებთან ერთად შლის
        b.HasOne(e => e.Submission).WithMany(s => s.Evaluations)
            .HasForeignKey(e => e.SubmissionId)
            .OnDelete(DeleteBehavior.Cascade);

        // ჟიურის მხრიდან Restrict: Form->Juror->Evaluation და Form->Submission->Evaluation
        // ორმაგ cascade გზას ქმნიდა (SQL Server-ს ეს ეკრძალება — იხ. SubmissionValue).
        // ჟიურის წევრს ისედაც არ ვშლით — მხოლოდ IsActive=false-ს ვუყენებთ.
        b.HasOne(e => e.Juror).WithMany(j => j.Evaluations)
            .HasForeignKey(e => e.JurorId)
            .OnDelete(DeleteBehavior.Restrict);
    }
}

public class HttpRequestLogConfiguration : IEntityTypeConfiguration<HttpRequestLog>
{
    public void Configure(EntityTypeBuilder<HttpRequestLog> b)
    {
        b.Property(r => r.Method).HasMaxLength(10).IsRequired();
        b.Property(r => r.Path).HasMaxLength(2000).IsRequired();
        b.Property(r => r.IpAddress).HasMaxLength(64);
        b.Property(r => r.VisitorId).HasMaxLength(64);
        b.Property(r => r.UserAgent).HasMaxLength(512);
        b.Property(r => r.Exception).HasMaxLength(4000);
        b.HasIndex(r => r.Timestamp);
        b.HasIndex(r => r.IpAddress);
        b.HasIndex(r => r.StatusCode);
    }
}

public class RevokedTokenConfiguration : IEntityTypeConfiguration<RevokedToken>
{
    public void Configure(EntityTypeBuilder<RevokedToken> b)
    {
        b.Property(t => t.Jti).HasMaxLength(64).IsRequired();
        // ყოველ ავტორიზებულ მოთხოვნაზე ამ ინდექსით მოწმდება — უნიკალურიც, რომ ორჯერ არ ჩაიწეროს
        b.HasIndex(t => t.Jti).IsUnique();
        b.HasIndex(t => t.ExpiresAt);
    }
}
