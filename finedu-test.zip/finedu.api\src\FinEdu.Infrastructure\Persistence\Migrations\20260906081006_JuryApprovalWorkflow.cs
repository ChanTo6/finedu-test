﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace FinEdu.Infrastructure.Persistence.Migrations
{
    /// <inheritdoc />
    public partial class JuryApprovalWorkflow : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropIndex(
                name: "IX_FormAccessList_FormId",
                table: "FormAccessList");

            migrationBuilder.AlterColumn<string>(
                name: "PinSalt",
                table: "Jurors",
                type: "nvarchar(64)",
                maxLength: 64,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(64)",
                oldMaxLength: 64);

            migrationBuilder.AlterColumn<string>(
                name: "PinHash",
                table: "Jurors",
                type: "nvarchar(128)",
                maxLength: 128,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(128)",
                oldMaxLength: 128);

            migrationBuilder.AlterColumn<DateTimeOffset>(
                name: "PinExpiresAt",
                table: "Jurors",
                type: "datetimeoffset",
                nullable: true,
                oldClrType: typeof(DateTimeOffset),
                oldType: "datetimeoffset");

            migrationBuilder.AddColumn<DateTimeOffset>(
                name: "ApprovedAt",
                table: "Jurors",
                type: "datetimeoffset",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "ApprovedBy",
                table: "Jurors",
                type: "nvarchar(256)",
                maxLength: 256,
                nullable: true);

            // ნაგულისხმევი = PendingApproval (1), ისევე როგორც entity-ში.
            // გენერატორი 0-ს წერდა — ეს არცერთი ვალიდური მნიშვნელობა არ არის.
            migrationBuilder.AddColumn<int>(
                name: "Status",
                table: "Jurors",
                type: "int",
                nullable: false,
                defaultValue: 1);

            // უკვე არსებული ჟიური დადასტურებულად ითვლება: ბმული და PIN დადასტურების
            // წესის შემოღებამდე მიიღეს და უკვე აფასებენ. 1-ზე დატოვება მათ წვდომას წაართმევდა.
            // ApprovedBy/ApprovedAt განზრახ ცარიელი რჩება — ვინ და როდის დაადასტურა,
            // არავინ იცის და გამოგონილი მონაცემი აუდიტს გააფუჭებდა.
            migrationBuilder.Sql("UPDATE dbo.Jurors SET Status = 2;");

            migrationBuilder.AlterColumn<string>(
                name: "AdAccount",
                table: "FormAccessList",
                type: "nvarchar(256)",
                maxLength: 256,
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)");

            migrationBuilder.CreateIndex(
                name: "IX_Jurors_FormId_Status",
                table: "Jurors",
                columns: new[] { "FormId", "Status" });

            migrationBuilder.CreateIndex(
                name: "IX_FormAccessList_FormId_AdAccount",
                table: "FormAccessList",
                columns: new[] { "FormId", "AdAccount" },
                unique: true);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropIndex(
                name: "IX_Jurors_FormId_Status",
                table: "Jurors");

            migrationBuilder.DropIndex(
                name: "IX_FormAccessList_FormId_AdAccount",
                table: "FormAccessList");

            migrationBuilder.DropColumn(
                name: "ApprovedAt",
                table: "Jurors");

            migrationBuilder.DropColumn(
                name: "ApprovedBy",
                table: "Jurors");

            migrationBuilder.DropColumn(
                name: "Status",
                table: "Jurors");

            migrationBuilder.AlterColumn<string>(
                name: "PinSalt",
                table: "Jurors",
                type: "nvarchar(64)",
                maxLength: 64,
                nullable: false,
                defaultValue: "",
                oldClrType: typeof(string),
                oldType: "nvarchar(64)",
                oldMaxLength: 64,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "PinHash",
                table: "Jurors",
                type: "nvarchar(128)",
                maxLength: 128,
                nullable: false,
                defaultValue: "",
                oldClrType: typeof(string),
                oldType: "nvarchar(128)",
                oldMaxLength: 128,
                oldNullable: true);

            migrationBuilder.AlterColumn<DateTimeOffset>(
                name: "PinExpiresAt",
                table: "Jurors",
                type: "datetimeoffset",
                nullable: false,
                defaultValue: new DateTimeOffset(new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), new TimeSpan(0, 0, 0, 0, 0)),
                oldClrType: typeof(DateTimeOffset),
                oldType: "datetimeoffset",
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "AdAccount",
                table: "FormAccessList",
                type: "nvarchar(max)",
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(256)",
                oldMaxLength: 256);

            migrationBuilder.CreateIndex(
                name: "IX_FormAccessList_FormId",
                table: "FormAccessList",
                column: "FormId");
        }
    }
}
