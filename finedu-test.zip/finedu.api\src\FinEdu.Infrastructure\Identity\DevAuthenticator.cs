using FinEdu.Application.Common.Interfaces;
using FinEdu.Application.Common.Security;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Hosting;

namespace FinEdu.Infrastructure.Identity;

/// <summary>
/// ლოკალური დეველოპმენტისთვის, სადაც AD ხელმისაწვდომი არ არის.
/// კოდში პაროლი არ წერია — მომხმარებელი და პაროლი user-secrets-იდან მოდის და
/// რეგისტრირდება მხოლოდ Development-ში, DevAuth:Enabled=true-ს დროს (იხ. Program.cs).
/// კონსტრუქტორი დამატებით ბარიერია, თუ რეგისტრაცია შემთხვევით სხვაგან მოხვდა.
/// </summary>
public class DevAuthenticator : IAdAuthenticator
{
    private readonly List<DevAccount> _accounts = [];

    public DevAuthenticator(IConfiguration config, IHostEnvironment env)
    {
        if (!env.IsDevelopment())
            throw new InvalidOperationException("DevAuthenticator მხოლოდ Development გარემოშია დასაშვები.");

        var section = config.GetSection("DevAuth");
        var username = section["Username"] ?? throw new InvalidOperationException("DevAuth:Username არ არის მითითებული.");
        var password = section["Password"] ?? throw new InvalidOperationException(
            "DevAuth:Password არ არის მითითებული. დააყენეთ: dotnet user-secrets set \"DevAuth:Password\" \"<თქვენი პაროლი>\"");
        // Distinct — ისევე, როგორც LdapAuthenticator-ში: კონფიგურაციის მასივები
        // ინდექსით გადაიფარება, ანუ გადაფარვისას ერთი და იგივე როლი ორჯერ ჩნდებოდა
        // და ტოკენში დუბლირებული claim ხვდებოდა.
        var roles = (section.GetSection("Roles").Get<string[]>() ?? [Roles.Administrator, Roles.Moderator])
            .Distinct()
            .ToArray();
        _accounts.Add(new DevAccount(username, password, roles));

        // სატესტო მოდერატორი (AD-ში FinEdu-Users-ის შესატყვისი) — მხოლოდ Moderator როლით.
        // არასავალდებულოა: სადაც პაროლი user-secrets-ში არ დგას, ანგარიში უბრალოდ
        // არ არსებობს და ძირითადი შესვლა ამით არ ფუჭდება. ცარიელი პაროლიც „არ დგას"-ად
        // ითვლება — თორემ ცარიელი ველით შესვლა გაიხსნებოდა.
        var moderator = section.GetSection("Moderator");
        var moderatorName = moderator["Username"];
        var moderatorPassword = moderator["Password"];
        if (!string.IsNullOrWhiteSpace(moderatorName) && !string.IsNullOrWhiteSpace(moderatorPassword))
            _accounts.Add(new DevAccount(moderatorName, moderatorPassword, [Roles.Moderator]));
    }

    public Task<AdUser?> AuthenticateAsync(string username, string password, CancellationToken ct = default)
    {
        var account = _accounts.FirstOrDefault(a => a.Username == username && a.Password == password);

        return Task.FromResult<AdUser?>(account is null ? null : new AdUser(username, username, account.Roles));
    }

    private sealed record DevAccount(string Username, string Password, string[] Roles);
}
