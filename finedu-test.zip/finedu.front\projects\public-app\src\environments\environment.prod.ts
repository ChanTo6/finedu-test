export const environment = {
  production: true,
  // ფარდობითი — nginx/IIS ამავე origin-ზე პროქსირებს /api-ს PublicApi-სკენ (CORS საერთოდ არ სჭირდება).
  apiUrl: '/api',
};
