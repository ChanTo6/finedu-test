import { HttpClient, HttpParams, HttpResponse } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { Observable } from 'rxjs';
import { FormDetail, FormSummary } from 'shared-lib';
import { environment } from '../../../environments/environment';
import { CreateFormRequest, PagedResult, Submission } from '../models/form-requests';

@Injectable({ providedIn: 'root' })
export class FormsService {
  private readonly http = inject(HttpClient);
  private readonly base = environment.apiUrl;

  list(): Observable<FormSummary[]> {
    return this.http.get<FormSummary[]>(`${this.base}/forms`);
  }

  get(id: string): Observable<FormDetail> {
    return this.http.get<FormDetail>(`${this.base}/forms/${id}`);
  }

  create(request: CreateFormRequest): Observable<{ id: string }> {
    return this.http.post<{ id: string }>(`${this.base}/forms`, request);
  }

  /**
   * უკვე ატვირთული ქავერი. `<img src>`-ით პირდაპირ ვერ ჩაიტვირთება: endpoint
   * ავტორიზებულია და ბრაუზერის ნავიგაციას interceptor ვერ წვდება — ამიტომ blob-ით.
   */
  cover(formId: string): Observable<Blob> {
    return this.http.get(`${this.base}/forms/${formId}/cover`, { responseType: 'blob' });
  }

  /** ქავერ ფოტოს ატვირთვა — აბრუნებს ფაილის სახელს, რომელიც ფორმის შენახვისას იგზავნება. */
  uploadCover(file: File): Observable<{ coverName: string }> {
    const data = new FormData();
    data.append('file', file, file.name);
    return this.http.post<{ coverName: string }>(`${this.base}/forms/cover`, data);
  }

  /** რედაქტირება — სერვერი მხოლოდ Draft/PendingApproval სტატუსზე უშვებს. */
  update(id: string, request: CreateFormRequest): Observable<void> {
    return this.http.put<void>(`${this.base}/forms/${id}`, request);
  }

  submitForApproval(id: string): Observable<void> {
    return this.http.post<void>(`${this.base}/forms/${id}/submit`, {});
  }

  approve(id: string): Observable<void> {
    return this.http.post<void>(`${this.base}/forms/${id}/approve`, {});
  }

  close(id: string): Observable<void> {
    return this.http.post<void>(`${this.base}/forms/${id}/close`, {});
  }

  /**
   * Excel-ის ჩამოტვირთვა HttpClient-ით და არა `<a href>`-ით: პირდაპირ ნავიგაციას
   * interceptor ვერ წვდება, ამიტომ Authorization header არ იგზავნებოდა და endpoint 401-ს აბრუნებდა.
   */
  downloadExport(id: string): Observable<Blob> {
    return this.http.get(`${this.base}/forms/${id}/export`, { responseType: 'blob' });
  }

  /**
   * განაცხადები გვერდებად. მთელი სია განზრახ არ ბრუნდება: ეს პერსონალური
   * მონაცემებია და ერთბაშად ჩვენება ზედმეტია (doc §4.1), 500-მონაწილიან
   * კონკურსზე კი პასუხი რამდენიმე მეგაბაიტი გამოვიდოდა.
   */
  submissions(formId: string, page: number, search?: string): Observable<PagedResult<Submission>> {
    let params = new HttpParams().set('page', page);
    if (search) params = params.set('search', search);

    return this.http.get<PagedResult<Submission>>(`${this.base}/forms/${formId}/submissions`, {
      params,
    });
  }

  /**
   * ატვირთული ფაილი — export-ის მსგავსად ავტორიზებული blob-ით, არა პირდაპირი ბმულით.
   *
   * პასუხი მთლიანად ბრუნდება და არა მხოლოდ blob: Excel-ის ბმულით შესვლისას სახელი
   * წინასწარ ცნობილი არ არის და მხოლოდ Content-Disposition-იდან იკითხება.
   */
  downloadFile(fileId: string): Observable<HttpResponse<Blob>> {
    return this.http.get(`${this.base}/files/${fileId}`, {
      responseType: 'blob',
      observe: 'response',
    });
  }
}
