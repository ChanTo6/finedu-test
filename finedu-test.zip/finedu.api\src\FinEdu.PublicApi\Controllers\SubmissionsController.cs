using System.Text.Json;
using FinEdu.Application.Common.Exceptions;
using FinEdu.Application.Common.Models;
using FinEdu.Application.Submissions;
using FinEdu.Domain.ValueObjects;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.RateLimiting;
using FinEdu.Application.Resources;

namespace FinEdu.PublicApi.Controllers;

[ApiController]
[Route("api/forms/{token}/submissions")]
[EnableRateLimiting("public")]
public class SubmissionsController(ISubmissionService submissions) : ControllerBase
{
    /// <summary>
    /// უდიდესი დასაშვები განაცხადი doc §3.2-ით: 3 ფაილი × 200 MB ვიდეო + multipart-ის overhead.
    /// პოლიტიკიდან ითვლება — ხელით ჩაწერილი 250 MB ორ 150 MB-იან ვიდეოს უკვე ბლოკავდა,
    /// თუმცა თითოეული ფაილი წესს აკმაყოფილებდა. იგივე რიცხვი დგას web.config-შიც (IIS).
    /// </summary>
    private const long MaxUploadBytes =
        FileUploadPolicy.MaxFilesPerSubmission * FileUploadPolicy.VideoMaxBytes + 20L * 1024 * 1024;

    private static readonly JsonSerializerOptions JsonOpts = new() { PropertyNameCaseInsensitive = true };

    /// <summary>
    /// ფორმის შევსება (multipart). ველი "payload" = CreateSubmissionRequest JSON,
    /// "captchaToken" = Altcha, ფაილები = form-file-ები, სადაც name = fieldId (GUID).
    /// </summary>
    [HttpPost]
    [RequestSizeLimit(MaxUploadBytes)]
    // multipart-ს *თავისი* ლიმიტი აქვს და ნაგულისხმევად 128 MB-ია — RequestSizeLimit მას არ ცვლის.
    // მის გარეშე პოლიტიკით დაშვებული 200 MB-იანი ვიდეო ფორმის დამუშავებისას იჭრებოდა
    // და მომხმარებელი 500-ს იღებდა (dev-ში პატარა ფაილებით ეს არასდროს ჩანდა).
    [RequestFormLimits(MultipartBodyLengthLimit = MaxUploadBytes)]
    public async Task<IActionResult> Submit(
        string token,
        [FromForm] string payload,
        CancellationToken ct)
    {
        CreateSubmissionRequest? request;
        try
        {
            request = JsonSerializer.Deserialize<CreateSubmissionRequest>(payload, JsonOpts);
        }
        catch (JsonException)
        {
            // გაფუჭებული JSON მომხმარებლის შეცდომაა და არა სერვერის — 500 ლოგსაც ტყუილად ავსებდა
            throw new ValidationException("payload", Messages.InvalidPayload);
        }

        if (request is null)
            throw new ValidationException("payload", Messages.InvalidPayload);

        var files = new List<SubmissionFileInput>();
        foreach (var file in Request.Form.Files)
        {
            if (!Guid.TryParse(file.Name, out var fieldId)) continue;
            files.Add(new SubmissionFileInput
            {
                FieldId = fieldId,
                Content = file.OpenReadStream(),
                FileName = file.FileName,
                ContentType = file.ContentType,
                SizeBytes = file.Length
            });
        }

        var id = await submissions.CreateAsync(token, request, files, ct);
        return Ok(new { id });
    }
}
