import { DatePipe } from '@angular/common';
import { Component, OnInit, computed, inject, input, signal } from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { RouterLink } from '@angular/router';
import {
  EMPTY,
  Subject,
  catchError,
  debounceTime,
  distinctUntilChanged,
  switchMap,
  tap,
} from 'rxjs';
import { formatFileSize, saveBlob } from 'shared-lib';
import { Submission } from '../../core/models/form-requests';
import { FormsService } from '../../core/services/forms.service';

@Component({
  selector: 'app-submissions',
  imports: [RouterLink, DatePipe],
  templateUrl: './submissions.html',
  styleUrl: './submissions.scss',
})
export class Submissions implements OnInit {
  private readonly service = inject(FormsService);

  /** route-იდან: /forms/:id/submissions */
  readonly id = input.required<string>();

  readonly formTitle = signal('');
  readonly submissions = signal<Submission[]>([]);
  readonly loading = signal(true);
  readonly error = signal('');

  readonly page = signal(1);
  readonly pageSize = signal(0);
  readonly totalPages = signal(0);
  readonly total = signal(0);
  readonly search = signal('');

  /** მიმდინარე გვერდის პირველი განაცხადის რიგითი ნომერი მთელ სიაში. */
  private readonly offset = computed(() => (this.page() - 1) * this.pageSize());

  /** ძებნის ველი: თითოეულ აკრეფილ ასოზე სერვერის მოთხოვნა ზედმეტია. */
  private readonly typed$ = new Subject<string>();

  private readonly load$ = new Subject<void>();

  constructor() {
    this.typed$
      .pipe(debounceTime(300), distinctUntilChanged(), takeUntilDestroyed())
      .subscribe((text) => {
        this.search.set(text);
        // ახალი ძებნა ყოველთვის პირველი გვერდიდან: მე-3 გვერდზე დარჩენა ცარიელ სიას მოგვცემდა
        this.page.set(1);
        this.load$.next();
      });

    // switchMap — სწრაფად აკრეფისას მხოლოდ ბოლო პასუხი ჩაიწერება; სხვაგვარად ნელა
    // დაბრუნებულ ძველ პასუხს ახლის გადაფარვა შეეძლო.
    this.load$
      .pipe(
        tap(() => {
          this.loading.set(true);
          this.error.set('');
        }),
        switchMap(() =>
          this.service.submissions(this.id(), this.page(), this.search()).pipe(
            catchError(() => {
              this.error.set('განაცხადების ჩატვირთვა ვერ მოხერხდა.');
              this.loading.set(false);
              return EMPTY;
            }),
          ),
        ),
        takeUntilDestroyed(),
      )
      .subscribe((result) => {
        this.submissions.set(result.items);
        this.page.set(result.page);
        this.pageSize.set(result.pageSize);
        this.totalPages.set(result.totalPages);
        this.total.set(result.total);
        this.loading.set(false);
      });
  }

  ngOnInit(): void {
    this.service.get(this.id()).subscribe({
      next: (f) => this.formTitle.set(f.title),
    });

    this.load$.next();
  }

  /** სიაში რიგითი ნომერი — გვერდის შეცვლისას თავიდან არ უნდა დაიწყოს. */
  rowNumber(indexOnPage: number): number {
    return this.offset() + indexOnPage + 1;
  }

  onSearch(value: string): void {
    this.typed$.next(value.trim());
  }

  goToPage(page: number): void {
    if (page < 1 || page > this.totalPages() || page === this.page()) return;

    this.page.set(page);
    this.load$.next();
  }

  downloadFile(fileId: string, fileName: string): void {
    this.service.downloadFile(fileId).subscribe({
      next: (response) => saveBlob(response.body!, fileName),
      error: () => this.error.set(`ფაილი „${fileName}" ვერ ჩამოიტვირთა.`),
    });
  }

  exportExcel(): void {
    this.service.downloadExport(this.id()).subscribe({
      next: (blob) => saveBlob(blob, `${this.formTitle() || 'form'}.xlsx`),
      error: () => this.error.set('Excel-ის ჩამოტვირთვა ვერ მოხერხდა.'),
    });
  }

  protected readonly formatSize = formatFileSize;
}
