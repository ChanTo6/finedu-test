using System.Net;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text.Json;

namespace FinEdu.IntegrationTests;

/// <summary>
/// განაცხადების სია: გვერდები და ძებნა.
///
/// <para>ორივე პერს. მონაცემთა დაცვის მოთხოვნაა — ადმინს ყველა მონაცემი ერთბაშად
/// არ უნდა ეჩვენებოდეს (doc §4.1), და ტექნიკურიც: 500-მონაწილიან კონკურსზე მთელი
/// სიის ერთი პასუხით დაბრუნება რამდენიმე მეგაბაიტს ნიშნავდა.</para>
/// </summary>
public class SubmissionListingTests : IAsyncLifetime
{
    private readonly ModeratorApiFactory _factory = new();
    private HttpClient _client = null!;
    private string _formId = "";

    public async Task InitializeAsync()
    {
        _client = _factory.CreateClient();

        var login = await _client.PostAsJsonAsync("/api/auth/login",
            new { username = "tester", password = "test-password" });
        login.EnsureSuccessStatusCode();

        var body = await login.Content.ReadFromJsonAsync<JsonElement>();
        _client.DefaultRequestHeaders.Authorization =
            new AuthenticationHeaderValue("Bearer", body.GetProperty("token").GetString());

        var created = await _client.PostAsJsonAsync("/api/forms", new
        {
            title = "სიის კონკურსი",
            retentionDays = 30,
            privacyNoticeHtml = "<p>პირობები</p>",
            fields = new[] { new { order = 0, type = 1, label = "სახელი", isRequired = false, config = new { } } }
        });
        created.EnsureSuccessStatusCode();
        _formId = (await created.Content.ReadFromJsonAsync<JsonElement>()).GetProperty("id").GetString()!;

        await _factory.SeedSubmissionsAsync(Guid.Parse(_formId), "ნიკა", "მარიამ", "გიორგი");
    }

    public Task DisposeAsync()
    {
        _factory.Dispose();
        return Task.CompletedTask;
    }

    private async Task<JsonElement> ListAsync(string query = "") =>
        await _client.GetFromJsonAsync<JsonElement>($"/api/forms/{_formId}/submissions{query}");

    [Fact]
    public async Task Result_is_paged()
    {
        var page = await ListAsync("?page=1&pageSize=2");

        Assert.Equal(2, page.GetProperty("items").GetArrayLength());
        Assert.Equal(3, page.GetProperty("total").GetInt32());
        Assert.Equal(2, page.GetProperty("totalPages").GetInt32());
    }

    [Fact]
    public async Task Second_page_returns_the_rest()
    {
        var page = await ListAsync("?page=2&pageSize=2");

        Assert.Equal(1, page.GetProperty("items").GetArrayLength());
        Assert.Equal(2, page.GetProperty("page").GetInt32());
    }

    /// <summary>კლიენტს გვერდის ზომით მთელი ცხრილის გამოთხოვა არ უნდა შეეძლოს.</summary>
    [Fact]
    public async Task Page_size_is_capped_by_the_server()
    {
        var page = await ListAsync("?pageSize=100000");

        Assert.Equal(100, page.GetProperty("pageSize").GetInt32());
    }

    [Fact]
    public async Task Search_matches_answer_text()
    {
        var page = await ListAsync("?search=მარიამ");

        Assert.Equal(1, page.GetProperty("total").GetInt32());

        var values = page.GetProperty("items")[0].GetProperty("values");
        Assert.Equal("მარიამ", values[0].GetProperty("value").GetString());
    }

    /// <summary>Excel-ში ID ჩანს — მისით უკან დაბრუნება ბუნებრივი გზაა.</summary>
    [Fact]
    public async Task Search_matches_submission_id()
    {
        var all = await ListAsync();
        var id = all.GetProperty("items")[0].GetProperty("id").GetString();

        var found = await ListAsync($"?search={id}");

        Assert.Equal(1, found.GetProperty("total").GetInt32());
        Assert.Equal(id, found.GetProperty("items")[0].GetProperty("id").GetString());
    }

    [Fact]
    public async Task Search_with_no_match_returns_empty_page()
    {
        var page = await ListAsync("?search=არარსებული");

        Assert.Equal(0, page.GetProperty("total").GetInt32());
        Assert.Equal(0, page.GetProperty("items").GetArrayLength());
    }

    /// <summary>სხვისი კონკურსის სია ისევ დახურულია — გვერდებმა ეს არ უნდა შეცვალოს.</summary>
    [Fact]
    public async Task Someone_elses_submissions_are_still_forbidden()
    {
        var foreign = await _factory.SeedForeignFormAsync();

        var response = await _client.GetAsync($"/api/forms/{foreign.FormId}/submissions?page=1");

        Assert.Equal(HttpStatusCode.Forbidden, response.StatusCode);
    }
}
