﻿using System.Net;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text.Json;

namespace FinEdu.IntegrationTests;

/// <summary>
/// ავტორიზაციის საზღვარი მთელ HTTP მილსადენზე — controller-ის ატრიბუტები, JWT-ის
/// ვალიდაცია და გაუქმება ერთად მუშაობს თუ არა. ამას unit ტესტი ვერ დაიჭერს.
/// </summary>
public class AuthorizationTests(AdminApiFactory factory) : IClassFixture<AdminApiFactory>
{
    private readonly HttpClient _client = factory.CreateClient();

    private async Task<string> LoginAsync()
    {
        var response = await _client.PostAsJsonAsync("/api/auth/login",
            new { username = "tester", password = "test-password" });
        response.EnsureSuccessStatusCode();

        var body = await response.Content.ReadFromJsonAsync<JsonElement>();
        return body.GetProperty("token").GetString()!;
    }

    private void Authorize(string token) =>
        _client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);

    /// <summary>
    /// ადმინის ზონაში ავტორიზაცია ნაგულისხმევად სავალდებულოა (FallbackPolicy) — ატრიბუტის
    /// გარეშე დარჩენილი endpoint ჩუმად ანონიმური ვეღარ გახდება.
    ///
    /// <para>ორივე გამონაკლისი ცხადად აღინიშნა და სწორედ ისინი მოწმდება აქ: load balancer-ს
    /// ტოკენი არ აქვს და ვერც ექნება, ხოლო login თვითონ არის ტოკენის ერთადერთი წყარო.
    /// გამონაკლისის შემთხვევით მოხსნა სერვისს „მკვდრად" აჩვენებდა მონიტორინგისთვის.</para>
    /// </summary>
    [Theory]
    [InlineData("/health")]
    [InlineData("/health/ready")]
    public async Task Health_endpoints_stay_open_without_a_token(string path)
    {
        var response = await _client.GetAsync(path);

        Assert.Equal(HttpStatusCode.OK, response.StatusCode);
    }

    [Fact]
    public async Task Forms_without_token_is_unauthorized()
    {
        var response = await _client.GetAsync("/api/forms");
        Assert.Equal(HttpStatusCode.Unauthorized, response.StatusCode);
    }

    [Fact]
    public async Task Login_with_wrong_password_is_unauthorized()
    {
        var response = await _client.PostAsJsonAsync("/api/auth/login",
            new { username = "tester", password = "wrong" });
        Assert.Equal(HttpStatusCode.Unauthorized, response.StatusCode);
    }

    [Fact]
    public async Task Login_with_empty_password_is_unauthorized()
    {
        var response = await _client.PostAsJsonAsync("/api/auth/login",
            new { username = "tester", password = "" });
        Assert.Equal(HttpStatusCode.Unauthorized, response.StatusCode);
    }

    [Fact]
    public async Task Forged_token_is_rejected()
    {
        Authorize("eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJhdHRhY2tlciJ9.not-a-real-signature");

        var response = await _client.GetAsync("/api/forms");
        Assert.Equal(HttpStatusCode.Unauthorized, response.StatusCode);
    }

    [Fact]
    public async Task Valid_token_grants_access()
    {
        Authorize(await LoginAsync());

        var response = await _client.GetAsync("/api/forms");
        Assert.Equal(HttpStatusCode.OK, response.StatusCode);
    }

    /// <summary>JWT ხელმოწერა logout-ის შემდეგაც ვალიდურია — გაუქმებას denylist უზრუნველყოფს.</summary>
    [Fact]
    public async Task Token_stops_working_after_logout()
    {
        Authorize(await LoginAsync());
        Assert.Equal(HttpStatusCode.OK, (await _client.GetAsync("/api/forms")).StatusCode);

        var logout = await _client.PostAsync("/api/auth/logout", null);
        Assert.Equal(HttpStatusCode.NoContent, logout.StatusCode);

        var afterLogout = await _client.GetAsync("/api/forms");
        Assert.Equal(HttpStatusCode.Unauthorized, afterLogout.StatusCode);
    }
}
