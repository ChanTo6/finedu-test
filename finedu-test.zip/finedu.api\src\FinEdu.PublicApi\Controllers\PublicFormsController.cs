﻿using FinEdu.Application.Common.Models;
using FinEdu.Application.Forms;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.RateLimiting;

namespace FinEdu.PublicApi.Controllers;

[ApiController]
[Route("api/forms")]
[EnableRateLimiting("public-read")]
public class PublicFormsController(IFormService forms, IFormCoverService covers) : ControllerBase
{
    /// <summary>გამოცხადებული კონკურსების საჯარო კატალოგი (ავტორიზაციის გარეშე).</summary>
    [HttpGet]
    public async Task<ActionResult<IReadOnlyList<PublicFormListItemDto>>> List(CancellationToken ct)
        => Ok(await forms.ListPublicAsync(ct));

    /// <summary>საჯარო ფორმის სქემა token-ით (მხოლოდ Live).</summary>
    [HttpGet("{token}")]
    public async Task<ActionResult<PublicFormDto>> Get(string token, CancellationToken ct)
        => Ok(await forms.GetPublicByTokenAsync(token, ct));

    /// <summary>ქავერ ფოტოს გაცემა — ფაილი web-root-ის გარეთაა, ამიტომ stream-ით მიეწოდება.</summary>
    [HttpGet("{token}/cover")]
    public async Task<IActionResult> Cover(string token, CancellationToken ct)
    {
        var cover = await covers.GetPublicAsync(token, ct);
        Response.Headers["X-Content-Type-Options"] = "nosniff";   // ბრაუზერმა ტიპი არ „გამოიცნოს"
        return File(cover.Content, cover.ContentType);
    }
}
