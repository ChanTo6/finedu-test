using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;

namespace FinEdu.Infrastructure.Http;

/// <summary>
/// უსაფრთხოების header-ები API-ს პასუხებზე (OWASP Secure Headers).
/// API JSON-ს აბრუნებს, ამიტომ მთავარია sniffing-ის, embedding-ის და referrer-ის გაჟონვის აღკვეთა.
/// </summary>
public static class SecurityHeadersMiddleware
{
    /// <param name="noStore">
    /// ჩართეთ იმ API-სთვის, რომელიც პერსონალურ მონაცემებს აბრუნებს. proxy/CDN-ს
    /// შეიძლება ავტორიზებული პასუხი „სტატიკურად" ჩაეთვალა და დაეკეშა, რის შემდეგაც
    /// იგივე URL სხვას მიეწოდებოდა (web cache deception).
    /// </param>
    public static IApplicationBuilder UseSecurityHeaders(this IApplicationBuilder app, bool noStore = false) =>
        app.Use(async (ctx, next) =>
        {
            // header-ები პასუხის გაგზავნის წინ ეწერება და არა ახლა: შეცდომების დამმუშავებელი
            // პასუხს ასუფთავებს (Response.Clear()) და აქ დაყენებული header-ები ქრებოდა —
            // ანუ სწორედ შეცდომის პასუხები (400/403/500) რჩებოდა nosniff-ისა და
            // no-store-ის გარეშე, მაშინ როცა ისინიც იმავე დაცვას საჭიროებს.
            ctx.Response.OnStarting(() =>
            {
                var h = ctx.Response.Headers;
                h["X-Content-Type-Options"] = "nosniff";              // ბრაუზერმა ტიპი არ „გამოიცნოს"
                h["X-Frame-Options"] = "DENY";                        // clickjacking
                h["Referrer-Policy"] = "no-referrer";                 // token/ბმული referrer-ით არ გაჟონოს
                h["Cross-Origin-Resource-Policy"] = "same-site";
                h["Permissions-Policy"] = "camera=(), microphone=(), geolocation=()";
                // API არ აბრუნებს HTML-ს — ყველაფრის აკრძალვა ბრაუზერში რენდერს გამორიცხავს
                h["Content-Security-Policy"] = ctx.Request.Path.StartsWithSegments("/api")
    ? "default-src 'none'; frame-ancestors 'none'"
    : "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; " +
    "font-src 'self'; connect-src 'self'; frame-ancestors 'none'";
                h.Remove("X-Powered-By");

                if (noStore)
                {
                    h["Cache-Control"] = "no-store, no-cache, must-revalidate, private";
                    h["Pragma"] = "no-cache";
                }

                return Task.CompletedTask;
            });

            await next();
        });
}
