import { HttpInterceptorFn } from '@angular/common/http';
import { inject } from '@angular/core';
import { environment } from '../../../environments/environment';
import { I18nService } from '../services/i18n.service';

/**
 * არჩეული ენა ჩვენს API-ს ცხადად მიდის — ამის გარეშე სერვერი ბრაუზერის ენას აიღებდა და
 * ინგლისურ ბრაუზერში ქართულ გვერდზე შეცდომები ინგლისურად გამოჩნდებოდა.
 */
export const languageInterceptor: HttpInterceptorFn = (req, next) => {
  if (!req.url.startsWith(environment.apiUrl)) return next(req);

  const lang = inject(I18nService).lang();
  return next(req.clone({ setHeaders: { 'Accept-Language': lang } }));
};
