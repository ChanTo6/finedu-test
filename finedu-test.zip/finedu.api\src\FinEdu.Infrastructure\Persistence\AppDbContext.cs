using FinEdu.Application.Common.Interfaces;
using FinEdu.Domain.Entities;
using Microsoft.EntityFrameworkCore;

namespace FinEdu.Infrastructure.Persistence;

public class AppDbContext(DbContextOptions<AppDbContext> options)
    : DbContext(options), IAppDbContext
{
    public DbSet<Form> Forms => Set<Form>();
    public DbSet<FormField> FormFields => Set<FormField>();
    public DbSet<Submission> Submissions => Set<Submission>();
    public DbSet<SubmissionValue> SubmissionValues => Set<SubmissionValue>();
    public DbSet<SubmissionFile> SubmissionFiles => Set<SubmissionFile>();
    public DbSet<FormAccess> FormAccessList => Set<FormAccess>();
    public DbSet<AuditLog> AuditLogs => Set<AuditLog>();
    public DbSet<HttpRequestLog> HttpRequestLogs => Set<HttpRequestLog>();
    public DbSet<RevokedToken> RevokedTokens => Set<RevokedToken>();
    public DbSet<Juror> Jurors => Set<Juror>();
    public DbSet<Evaluation> Evaluations => Set<Evaluation>();

    protected override void OnModelCreating(ModelBuilder builder)
    {
        builder.ApplyConfigurationsFromAssembly(typeof(AppDbContext).Assembly);
        base.OnModelCreating(builder);
    }
}
