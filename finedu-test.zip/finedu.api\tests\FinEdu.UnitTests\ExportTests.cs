﻿using ClosedXML.Excel;
using FinEdu.Application.Common.Options;
using FinEdu.Application.Common.Security;
using FinEdu.Application.Export;
using FinEdu.Domain.Entities;
using FinEdu.Domain.Enums;
using FinEdu.Infrastructure.Export;
using FinEdu.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using Xunit;

namespace FinEdu.UnitTests;

/// <summary>
/// Excel-ის ექსპორტი (doc §3.8). აქ სამი შეთანხმებული დაზუსტება მოწმდება:
/// განაცხადს უნდა ჰქონდეს ID, დროს წამები, ფაილს კი დაწკაპუნებადი ბმული.
///
/// <para>ბმული ადმინ-პანელზე მიდის და არა API-ზე — ბრაუზერის ჩვეულებრივი გადასვლა
/// ტოკენს არ ატარებს, ანუ პირდაპირი ბმული ისედაც არ იმუშავებდა; ამასთან ასეთი
/// ბმულის გაზიარება წვდომას არავის აძლევს.</para>
/// </summary>
public class ExportTests : IDisposable
{
    private readonly AppDbContext _db;
    private readonly RecordingAudit _audit = new();
    private readonly Guid _formId;
    private readonly Guid _submissionId;
    private readonly Guid _fileId;

    public ExportTests()
    {
        var options = new DbContextOptionsBuilder<AppDbContext>()
            .UseInMemoryDatabase($"export-{Guid.NewGuid()}")
            .Options;
        _db = new AppDbContext(options);

        var form = new Form { Title = "კონკურსი", Status = FormStatus.Closed, RetentionDays = 30 };
        form.AccessList.Add(new FormAccess { AdAccount = "nino", AccessLevel = AccessLevel.Manager });

        var field = new FormField
        {
            FormId = form.Id, Order = 1, Type = FieldType.ShortAnswer, Label = "სახელი"
        };

        var submission = new Submission
        {
            FormId = form.Id,
            Status = SubmissionStatus.Completed,
            ConsentDataProcessing = true,
            SubmittedAt = new DateTimeOffset(2026, 9, 8, 14, 30, 45, TimeSpan.Zero)
        };
        submission.Values.Add(new SubmissionValue
        {
            SubmissionId = submission.Id, FieldId = field.Id, Value = "ნიკა"
        });
        submission.Files.Add(new SubmissionFile
        {
            SubmissionId = submission.Id,
            FieldId = field.Id,
            OriginalFileName = "cv.pdf",
            StoredPath = "/files/cv.pdf",
            ContentType = "application/pdf",
            ScanStatus = ScanStatus.Clean
        });

        _db.Forms.Add(form);
        _db.FormFields.Add(field);
        _db.Submissions.Add(submission);
        _db.SaveChanges();

        _formId = form.Id;
        _submissionId = submission.Id;
        _fileId = submission.Files.First().Id;
    }

    public void Dispose() => _db.Dispose();

    private async Task<IXLWorksheet> ExportAsync(string baseUrl = "https://admin.finedu.local")
    {
        var user = new TestUser("nino", IsAdministrator: false);
        var service = new ExportService(
            _db,
            new ClosedXmlExporter(),
            new FormAccessGuard(_db, user),
            _audit,
            Options.Create(new AdminAppOptions { BaseUrl = baseUrl }));

        var bytes = await service.ExportFormAsync(_formId);
        return new XLWorkbook(new MemoryStream(bytes)).Worksheet(1);
    }

    [Fact]
    public async Task Submission_id_is_the_first_column()
    {
        var ws = await ExportAsync();

        Assert.Equal("ID", ws.Cell(1, 1).GetString());
        Assert.Equal(_submissionId.ToString(), ws.Cell(2, 1).GetString());
    }

    /// <summary>წამების გარეშე ერთ წუთში შემოსული განაცხადები ვერ დალაგდებოდა რიგითობით.</summary>
    [Fact]
    public async Task Timestamp_includes_seconds()
    {
        var ws = await ExportAsync();

        Assert.Equal("2026-09-08 14:30:45", ws.Cell(2, 2).GetString());
    }

    [Fact]
    public async Task Each_field_gets_its_own_column()
    {
        var ws = await ExportAsync();

        Assert.Equal("სახელი", ws.Cell(1, 3).GetString());
        Assert.Equal("ნიკა", ws.Cell(2, 3).GetString());
    }

    /// <summary>ფაილი ცალკე სვეტში და დაწკაპუნებადი — უჯრას მხოლოდ ერთი ბმული შეიძლება ჰქონდეს.</summary>
    [Fact]
    public async Task File_cell_is_a_clickable_link_to_the_admin_app()
    {
        var ws = await ExportAsync();
        var cell = ws.Cell(2, 4);

        Assert.Equal("ფაილი 1", ws.Cell(1, 4).GetString());
        Assert.Equal("cv.pdf", cell.GetString());
        Assert.True(cell.HasHyperlink);
        Assert.Equal($"https://admin.finedu.local/files/{_fileId}", cell.GetHyperlink().ExternalAddress.ToString());
    }

    /// <summary>მისამართის გარეშე გაუმართავი ბმულის ჩასმა უარესი იქნებოდა, ვიდრე მისი არარსებობა.</summary>
    [Fact]
    public async Task Without_configured_url_the_name_stays_but_the_link_does_not()
    {
        var ws = await ExportAsync(baseUrl: "");
        var cell = ws.Cell(2, 4);

        Assert.Equal("cv.pdf", cell.GetString());
        Assert.False(cell.HasHyperlink);
    }

    /// <summary>ექსპორტი პერსონალურ მონაცემს სისტემიდან გაიტანს — ჟურნალში აუცილებლად ჩანს.</summary>
    [Fact]
    public async Task Export_is_audited()
    {
        await ExportAsync();

        Assert.Equal(1, _audit.Count(Application.Common.Audit.AuditActions.ExportDownloaded));
    }
}
