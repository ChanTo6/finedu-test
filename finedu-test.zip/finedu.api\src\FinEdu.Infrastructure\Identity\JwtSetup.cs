﻿using System.Text;
using FinEdu.Application.Common.Interfaces;
using FinEdu.Application.Common.Security;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;

namespace FinEdu.Infrastructure.Identity;

/// <summary>
/// JWT ავთენტიფიკაციის სრული კონფიგურაცია — გასაღების შემოწმება, ვალიდაციის პარამეტრები,
/// გაუქმებული ტოკენების შემოწმება და როლების პოლიტიკები. AdminApi ერთი ხაზით იძახებს.
/// </summary>
public static class JwtSetup
{
    public static IServiceCollection AddFinEduJwtAuth(
        this IServiceCollection services, IConfiguration config, IHostEnvironment env)
    {
        services.AddScoped<ITokenService, JwtTokenService>();
        services.AddScoped<ITokenRevocationStore, TokenRevocationStore>();

        // ლოკალურ dev-ზე AD ხელმისაწვდომი არ არის — მაშინ და მხოლოდ მაშინ ვცვლით ავთენტიფიკატორს.
        // ორივე პირობა სავალდებულოა, რომ პროდაქშენში შემთხვევით ვერ ჩაირთოს.
        if (env.IsDevelopment() && config.GetValue<bool>("DevAuth:Enabled"))
            services.AddScoped<IAdAuthenticator, DevAuthenticator>();

        var jwt = config.GetSection("Jwt");
        var key = ValidatedKey(jwt);

        // წესები ორივე ზონაში ერთია — მხოლოდ გასაღები, issuer და audience განსხვავდება
        services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
            .AddJwtBearer(o => JwtBearerDefaultsSetup.Configure(o, key, jwt["Issuer"], jwt["Audience"]));

        services.AddAuthorization(o =>
        {
            // პოლიტიკის სახელი = როლის სახელი; ადმინისტრატორი მოდერატორის endpoint-ებზეც გადის
            o.AddPolicy(Roles.Administrator, p => p.RequireRole(Roles.Administrator));
            o.AddPolicy(Roles.Moderator, p => p.RequireRole(Roles.Moderator, Roles.Administrator));

            // ნაგულისხმევად ყველაფერი დახურულია. ამის გარეშე ატრიბუტის გარეშე დარჩენილი
            // endpoint ჩუმად ანონიმური ხდებოდა — ადმინის ზონაში, სადაც ყველა პასუხი
            // პერსონალურ მონაცემს შეიცავს, დავიწყების ფასი ძალიან მაღალია.
            // გამონაკლისები ცხადად აღინიშნება [AllowAnonymous]-ით (login, health).
            o.FallbackPolicy = new AuthorizationPolicyBuilder()
                .RequireAuthenticatedUser()
                .Build();
        });

        return services;
    }

    /// <summary>
    /// გასაღები appsettings-ში არ ინახება — მოდის env var-იდან (Jwt__Key) ან user-secrets-იდან.
    /// თუ არ არის/სუსტია, აპლიკაცია *არ* უნდა აეშვას: ცნობილი placeholder-ით გაშვება ნიშნავს,
    /// რომ ნებისმიერს შეეძლება ვალიდური ტოკენის გაყალბება.
    /// </summary>
    private static byte[] ValidatedKey(IConfigurationSection jwt)
    {
        var jwtKey = jwt["Key"];

        if (string.IsNullOrWhiteSpace(jwtKey) || Encoding.UTF8.GetByteCount(jwtKey) < 32)
            throw new InvalidOperationException(
                "Jwt:Key არ არის კონფიგურირებული ან 32 ბაიტზე მოკლეა. " +
                "დააყენეთ environment variable `Jwt__Key` (dev-ზე: dotnet user-secrets set \"Jwt:Key\" \"<random>\").");

        if (jwtKey.StartsWith("CHANGE-ME", StringComparison.OrdinalIgnoreCase))
            throw new InvalidOperationException("Jwt:Key ჯერ კიდევ placeholder-ია — გამოიყენეთ რეალური საიდუმლო გასაღები.");

        return Encoding.UTF8.GetBytes(jwtKey);
    }
}
