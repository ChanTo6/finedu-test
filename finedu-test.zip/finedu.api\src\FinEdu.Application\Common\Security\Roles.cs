namespace FinEdu.Application.Common.Security;

/// <summary>
/// აპლიკაციის როლები — ერთ ადგილას.
///
/// <para>ორივე როლი <b>AD-ის ჯგუფიდან</b> მოდის და არა ჩვენი ბაზიდან: მომხმარებელი
/// AD-ში არსებობს, იქვე იმართება და იქვე მოწმდება პაროლი. აპლიკაცია მხოლოდ თარგმნის
/// „რომელ ჯგუფშია" → „რა როლი აქვს". მომხმარებლის ცხრილი, პაროლი და როლის მინიჭების
/// ინტერფეისი აქ განზრახ არ არსებობს.</para>
///
/// <para>ეს სტრიქონები ერთდროულად როლის სახელიცაა (JWT-ის claim) და ავტორიზაციის
/// პოლიტიკის სახელიც — ერთი როლი, ერთი პოლიტიკა. კონსტანტებში იმიტომ, რომ ადრე
/// ისინი ხუთ ფაილში იყო გაფანტული და კოდის სახელი ბიზნესის სახელს ერთხელ უკვე აცდა.</para>
///
/// <para>ჟიური ამ სიაში არ არის: ის AD-ის მომხმარებელი არაა და მისი როლი საჯარო
/// ზონის ცალკე ტოკენში წერია (იხ. <c>JuryTokenService.JuryRole</c>).</para>
/// </summary>
public static class Roles
{
    /// <summary>AD ჯგუფი <c>Ldap:AdminGroup</c> (მაგ. FinEdu-Admins). ხედავს და მართავს ყველა კონკურსს.</summary>
    public const string Administrator = "Administrator";

    /// <summary>
    /// AD ჯგუფი <c>Ldap:StandardGroup</c> (მაგ. FinEdu-Users). მუშაობს მხოლოდ იმ
    /// კონკურსებზე, რომლებზეც წვდომა აქვს (იხ. <see cref="IFormAccessGuard"/>).
    /// </summary>
    public const string Moderator = "Moderator";
}
