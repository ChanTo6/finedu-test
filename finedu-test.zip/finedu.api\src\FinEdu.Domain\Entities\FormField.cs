﻿using FinEdu.Domain.Common;
using FinEdu.Domain.Enums;
using FinEdu.Domain.ValueObjects;

namespace FinEdu.Domain.Entities;

/// <summary>ფორმის დინამიური ველი. Config ინახება JSON-ად.</summary>
public class FormField : BaseEntity
{
    public Guid FormId { get; set; }
    public Form? Form { get; set; }

    public int Order { get; set; }
    public FieldType Type { get; set; }
    public string Label { get; set; } = string.Empty;
    public bool IsRequired { get; set; }

    /// <summary>
    /// ხედავს თუ არა ამ ველის პასუხს ჟიური.
    ///
    /// <para>ნაგულისხმევად <b>არა</b>. შეთანხმებული მოთხოვნაა (დოკუმენტი, „ადმინის/უკანა
    /// მხარე"): ჟიურის დაშვება უნდა ჰქონდეს „მხოლოდ ნამუშევრებზე და არა პერსონალურ
    /// მონაცემებზე". რომელი ველია ნამუშევარი და რომელი პერსონალური მონაცემი, სისტემა
    /// ვერ მიხვდება — ველებს ორგანიზატორი ქმნის, ამიტომ ის უთითებს.</para>
    ///
    /// <para>დახურული ნაგულისხმევი განზრახაა: დავიწყების ფასი ისაა, რომ ჟიური ზედმეტს
    /// ვერ დაინახავს — და არა ის, რომ პერსონალური მონაცემი ჩუმად გაჟონავს.</para>
    /// </summary>
    public bool VisibleToJury { get; set; }

    public FieldConfig Config { get; set; } = new();
}
