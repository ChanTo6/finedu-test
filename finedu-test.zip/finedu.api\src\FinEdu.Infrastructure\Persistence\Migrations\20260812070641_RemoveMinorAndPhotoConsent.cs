﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace FinEdu.Infrastructure.Persistence.Migrations
{
    /// <inheritdoc />
    public partial class RemoveMinorAndPhotoConsent : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "ConfirmationToken",
                table: "Submissions");

            migrationBuilder.DropColumn(
                name: "ConfirmedAt",
                table: "Submissions");

            migrationBuilder.DropColumn(
                name: "ConsentPhotoVideo",
                table: "Submissions");

            migrationBuilder.DropColumn(
                name: "IsMinor",
                table: "Submissions");

            migrationBuilder.DropColumn(
                name: "LegalRepresentativeJson",
                table: "Submissions");

            migrationBuilder.DropColumn(
                name: "RepresentativeEmail",
                table: "Submissions");

            migrationBuilder.DropColumn(
                name: "CollectPhotoVideoConsent",
                table: "Forms");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "ConfirmationToken",
                table: "Submissions",
                type: "nvarchar(64)",
                maxLength: 64,
                nullable: true);

            migrationBuilder.AddColumn<DateTimeOffset>(
                name: "ConfirmedAt",
                table: "Submissions",
                type: "datetimeoffset",
                nullable: true);

            migrationBuilder.AddColumn<bool>(
                name: "ConsentPhotoVideo",
                table: "Submissions",
                type: "bit",
                nullable: true);

            migrationBuilder.AddColumn<bool>(
                name: "IsMinor",
                table: "Submissions",
                type: "bit",
                nullable: false,
                defaultValue: false);

            migrationBuilder.AddColumn<string>(
                name: "LegalRepresentativeJson",
                table: "Submissions",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "RepresentativeEmail",
                table: "Submissions",
                type: "nvarchar(320)",
                maxLength: 320,
                nullable: true);

            migrationBuilder.AddColumn<bool>(
                name: "CollectPhotoVideoConsent",
                table: "Forms",
                type: "bit",
                nullable: false,
                defaultValue: false);
        }
    }
}
