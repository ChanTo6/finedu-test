﻿namespace FinEdu.Application.Common.Models;

/// <summary>
/// გვერდებად დაყოფილი შედეგი.
///
/// <para>განაცხადების სია აქამდე მთლიანად ბრუნდებოდა — 500-მონაწილიან კონკურსზე ეს
/// ერთ პასუხში ყველა პასუხისა და ფაილის სახელს ნიშნავდა. ამასთან, პერს. მონაცემთა
/// დაცვის მოთხოვნაა, რომ ადმინს ყველა მონაცემი ერთბაშად არ ეჩვენებოდეს.</para>
/// </summary>
public record PagedResult<T>(IReadOnlyList<T> Items, int Page, int PageSize, int Total)
{
    public int TotalPages => PageSize <= 0 ? 0 : (int)Math.Ceiling((double)Total / PageSize);
}

/// <summary>
/// სიის მოთხოვნის პარამეტრები. საზღვრები სერვერზეა: კლიენტს გვერდის ზომით
/// მთელი ცხრილის ერთი მოთხოვნით გამოთხოვა არ უნდა შეეძლოს.
/// </summary>
// PageSize = 0 ნიშნავს „არ მითითებულა" — SafePageSize მაშინ ნაგულისხმევს აბრუნებს.
// კონსტანტა პარამეტრის ნაგულისხმევში ვერ ჩაისმება (ჯერ არ არსებობს), რიცხვის
// ორჯერ დაწერა კი ორ სხვადასხვა მნიშვნელობად იქცეოდა პირველივე შესწორებაზე.
public record PageQuery(int Page = 1, int PageSize = 0, string? Search = null)
{
    public const int DefaultPageSize = 25;
    public const int MaxPageSize = 100;

    public int SafePage => Page < 1 ? 1 : Page;

    public int SafePageSize => PageSize switch
    {
        < 1 => DefaultPageSize,
        > MaxPageSize => MaxPageSize,
        _ => PageSize
    };

    /// <summary>გასაწმენდი საძიებო ტექსტი — ცარიელი და გამოტოვებული ერთი და იგივეა.</summary>
    public string? SafeSearch => string.IsNullOrWhiteSpace(Search) ? null : Search.Trim();

    public int Skip => (SafePage - 1) * SafePageSize;
}
