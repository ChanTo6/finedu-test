namespace FinEdu.Domain.ValueObjects;

/// <summary>
/// ატვირთვის სერვერული პოლიტიკა (doc §3.2). ეს არის *მყარი ზღვარი*: ფორმის კონფიგს
/// შეუძლია მხოლოდ შემდგომი შევიწროება, გაფართოება — არასდროს.
/// არქივები (ZIP/RAR) განზრახ არ არის — ამოღებულია მოთხოვნებიდან (docx კომენტარი #1),
/// რაც archive-bomb-ის რისკსაც აქრობს.
/// </summary>
public static class FileUploadPolicy
{
    public const long ImageMaxBytes = 10L * 1024 * 1024;
    public const long DocumentMaxBytes = 25L * 1024 * 1024;
    public const long PresentationMaxBytes = 50L * 1024 * 1024;
    public const long VideoMaxBytes = 200L * 1024 * 1024;

    /// <summary>
    /// doc §3.2: „მაქს. 3 ფაილი ერთ საბმიშენზე" — ყველა ფაილის ველში ერთად და არა თითოეულში.
    /// ველის კონფიგს (MaxFiles) მხოლოდ შევიწროება შეუძლია.
    /// </summary>
    public const int MaxFilesPerSubmission = 3;

    public sealed record FileRule(string ContentType, long MaxBytes);

    private static readonly Dictionary<string, FileRule> Rules = new(StringComparer.OrdinalIgnoreCase)
    {
        // დოკუმენტები
        ["pdf"] = new("application/pdf", DocumentMaxBytes),
        ["doc"] = new("application/msword", DocumentMaxBytes),
        ["docx"] = new("application/vnd.openxmlformats-officedocument.wordprocessingml.document", DocumentMaxBytes),
        ["xls"] = new("application/vnd.ms-excel", DocumentMaxBytes),
        ["xlsx"] = new("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", DocumentMaxBytes),

        // პრეზენტაციები
        ["ppt"] = new("application/vnd.ms-powerpoint", PresentationMaxBytes),
        ["pptx"] = new("application/vnd.openxmlformats-officedocument.presentationml.presentation", PresentationMaxBytes),

        // სურათები
        ["jpg"] = new("image/jpeg", ImageMaxBytes),
        ["jpeg"] = new("image/jpeg", ImageMaxBytes),
        ["png"] = new("image/png", ImageMaxBytes),
        ["gif"] = new("image/gif", ImageMaxBytes),

        // ვიდეოები
        ["mp4"] = new("video/mp4", VideoMaxBytes),
        ["mov"] = new("video/quicktime", VideoMaxBytes),
        ["avi"] = new("video/x-msvideo", VideoMaxBytes)
    };

    /// <summary>ქავერისთვის მხოლოდ სურათები.</summary>
    private static readonly string[] ImageExtensions = ["jpg", "jpeg", "png", "gif"];

    /// <summary>
    /// გაფართოება → მაქსიმალური ზომა. საჯარო ფორმასთან ერთად კლიენტსაც მიეწოდება, რომ
    /// ბრაუზერმა ატვირთვამდე გააფრთხილოს მომხმარებელი (200 MB-ის ტყუილად ატვირთვა და
    /// შემდეგ უარყოფა ცუდი გამოცდილებაა).
    ///
    /// <para><b>ეს მხოლოდ მოხერხებულობაა.</b> სერვერი იმავე წესებს დამოუკიდებლად ამოწმებს —
    /// კლიენტის შემოწმება ადვილად გვერდის ასავლელია და დაცვის ბარიერად არასდროს ჩაითვლება.</para>
    /// </summary>
    public static IReadOnlyDictionary<string, long> MaxBytesByExtension { get; } =
        Rules.ToDictionary(r => r.Key, r => r.Value.MaxBytes, StringComparer.OrdinalIgnoreCase);

    /// <summary>გაფართოება ფაილის სახელიდან — წერტილის გარეშე, lowercase.</summary>
    public static string NormalizeExtension(string fileName) =>
        Path.GetExtension(fileName).TrimStart('.').ToLowerInvariant();

    public static bool TryGetRule(string extension, out FileRule rule) =>
        Rules.TryGetValue(extension, out rule!);

    public static bool IsAllowedImage(string extension) =>
        ImageExtensions.Contains(extension, StringComparer.OrdinalIgnoreCase);

    /// <summary>
    /// Content type ყოველთვის *გაფართოებიდან* — კლიენტის გამოცხადებულს არასდროს ვენდობით,
    /// თორემ ატვირთული ფაილი ჩამოტვირთვისას ბრაუზერში დარენდერდებოდა (stored XSS).
    /// </summary>
    public static string ResolveContentType(string extension) =>
        Rules.TryGetValue(extension, out var rule) ? rule.ContentType : "application/octet-stream";
}
