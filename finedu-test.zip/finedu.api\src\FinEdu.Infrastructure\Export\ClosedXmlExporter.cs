﻿using ClosedXML.Excel;
using FinEdu.Application.Common.Interfaces;

namespace FinEdu.Infrastructure.Export;

/// <summary>Excel (.xlsx) გენერაცია ClosedXML-ით (უფასო).</summary>
public class ClosedXmlExporter : IExcelExporter
{
    public byte[] Export(ExcelSheet sheet)
    {
        using var workbook = new XLWorkbook();
        var ws = workbook.Worksheets.Add(sheet.Name);

        for (var c = 0; c < sheet.Headers.Count; c++)
            WriteText(ws.Cell(1, c + 1), sheet.Headers[c]);
        ws.Row(1).Style.Font.Bold = true;

        for (var r = 0; r < sheet.Rows.Count; r++)
        {
            var row = sheet.Rows[r];
            for (var c = 0; c < row.Count; c++)
            {
                var cell = ws.Cell(r + 2, c + 1);
                WriteText(cell, row[c]);

                // ბმული ტექსტს არ ცვლის — უჯრაში სახელი რჩება და დაწკაპუნებადი ხდება
                if (sheet.Links.TryGetValue((r, c), out var url))
                    cell.SetHyperlink(new XLHyperlink(url));
            }
        }

        ws.Columns().AdjustToContents();

        using var ms = new MemoryStream();
        workbook.SaveAs(ms);
        return ms.ToArray();
    }

    /// <summary>
    /// უჯრა ყოველთვის ტექსტად იწერება. მონაწილის შეყვანილი მნიშვნელობა, რომელიც
    /// =, +, - ან @ სიმბოლოთი იწყება, Excel-ს ფორმულად შეიძლება გაეგო (formula injection) —
    /// ამიტომ ასეთს აპოსტროფს ვუმატებთ, რაც Excel-ისთვის „ეს ტექსტია"-ს ნიშნავს.
    /// </summary>
    private static void WriteText(IXLCell cell, string? value)
    {
        var text = value ?? string.Empty;

        if (text.Length > 0 && text[0] is '=' or '+' or '-' or '@')
            text = "'" + text;

        cell.SetValue(text);   // string overload — უჯრა ტექსტად ინახება, არა ფორმულად
    }
}
