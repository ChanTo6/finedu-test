﻿namespace FinEdu.Application.Common.Interfaces;

// ── Storage (ფაილები web-root-ის გარეთ) ─────────────────────────────
public interface IFileStorage
{
    Task<string> SaveToQuarantineAsync(Stream content, string fileName, CancellationToken ct = default);
    Task<string> MoveToPermanentAsync(string quarantinePath, CancellationToken ct = default);
    Task DeleteAsync(string path, CancellationToken ct = default);
    Task<Stream> OpenReadAsync(string path, CancellationToken ct = default);

    // ქავერები ცალკე საქაღალდეშია (საჯაროდ გაიცემა). გარეთ მხოლოდ *ფაილის სახელი* დადის —
    // სრული გზა არასდროს, რომ კლიენტმა თვითნებური ფაილის მისამართი ვერ შემოგვაწოდოს.
    Task<string> SaveCoverAsync(Stream content, string fileName, CancellationToken ct = default);
    Task<Stream> OpenCoverAsync(string coverFileName, CancellationToken ct = default);
    Task DeleteCoverAsync(string coverFileName, CancellationToken ct = default);

    /// <summary>
    /// საცავში არსებული ქავერები. ობოლების გასუფთავებას სჭირდება: შედარება ხდება
    /// ბაზაში მითითებულ სახელებთან, ხოლო ატვირთვის დრო იმისთვისაა, რომ ახლახან
    /// ატვირთული (ჯერ შეუნახავი) ქავერი შემთხვევით არ წაიშალოს.
    /// </summary>
    Task<IReadOnlyList<StoredCover>> ListCoversAsync(CancellationToken ct = default);
}

/// <summary>ერთი ქავერი საცავში — სახელი და ატვირთვის დრო.</summary>
public record StoredCover(string FileName, DateTimeOffset CreatedAt);

// ── Identity / AD ───────────────────────────────────────────────────
public interface IAdAuthenticator
{
    Task<AdUser?> AuthenticateAsync(string username, string password, CancellationToken ct = default);
}

public record AdUser(string Account, string DisplayName, IReadOnlyList<string> Roles);

/// <summary>AD-ს დადასტურების შემდეგ სესიის ტოკენს გამოსცემს.</summary>
public interface ITokenService
{
    string Create(AdUser user);
}

/// <summary>
/// Logout-ზე გაუქმებული ტოკენების სია. JWT თავისთავად გაუქმებადი არ არის —
/// ხელმოწერა ვადის ბოლომდე ვალიდური რჩება, ამიტომ სერვერზე ცალკე უნდა ვაწარმოოთ.
/// </summary>
public interface ITokenRevocationStore
{
    Task RevokeAsync(string jti, DateTimeOffset expiresAt, CancellationToken ct = default);
    Task<bool> IsRevokedAsync(string jti, CancellationToken ct = default);
}

/// <summary>მიმდინარე მომხმარებელი (admin) — CreatedBy/audit/წვდომის შემოწმებისთვის.</summary>
public interface ICurrentUser
{
    string? Account { get; }
    string? IpAddress { get; }

    /// <summary>
    /// ბრაუზერის ანონიმური ნიშანი (cookie). ვინაობას არ ადგენს, მაგრამ ერთი
    /// მოწყობილობის მოქმედებებს ერთმანეთს უკავშირებს — IP ხშირად საზიაროა ან ცვალებადი.
    /// </summary>
    string? VisitorId { get; }

    /// <summary>User-Agent header — ბოტების ამოცნობის მინიშნება.</summary>
    string? UserAgent { get; }

    /// <summary>Administrator ხედავს ყველა პროექტის მონაცემს (doc §3.6 + კომენტ. „ადმინს შესაძლოა ჰქონდეს ყველა მონაცემზე წვდომა").</summary>
    bool IsAdministrator { get; }
}

// ── Notifications ───────────────────────────────────────────────────
public interface IEmailSender
{
    Task SendAsync(string to, string subject, string htmlBody, CancellationToken ct = default);
}

// ── Audit ───────────────────────────────────────────────────────────
public interface IAuditLogger
{
    /// <summary>actor მიმდინარე მომხმარებლიდან აიღება (ან „anonymous"/„system").</summary>
    Task LogAsync(string action, string? entityType = null, string? entityId = null,
                  string? details = null, CancellationToken ct = default);

    /// <summary>
    /// actor ცალკე მითითებით — ავთენტიფიკაციისთვის: შესვლის მომენტში ვინაობა
    /// ჯერ არ არის კონტექსტში, სახელი კი ცნობილია. ამის გარეშე ჟურნალში ყველა
    /// შესვლა „anonymous"-ად ჩაიწერებოდა და „ვინ რა გააკეთა" ვერ დაჯგუფდებოდა.
    /// </summary>
    Task LogForActorAsync(string actor, string action, string? entityType = null,
                          string? entityId = null, string? details = null, CancellationToken ct = default);
}

// ── Excel export ────────────────────────────────────────────────────
public interface IExcelExporter
{
    byte[] Export(ExcelSheet sheet);
}

public class ExcelSheet
{
    public string Name { get; set; } = "Sheet1";
    public List<string> Headers { get; set; } = new();
    public List<List<string>> Rows { get; set; } = new();

    /// <summary>
    /// (სტრიქონი, სვეტი) → მისამართი. ორივე ნულიდან ითვლება, სათაურის სტრიქონის გარეშე.
    /// უჯრა ტექსტს ინარჩუნებს და დამატებით დაწკაპუნებადი ხდება.
    /// </summary>
    public Dictionary<(int Row, int Column), string> Links { get; } = new();
}
