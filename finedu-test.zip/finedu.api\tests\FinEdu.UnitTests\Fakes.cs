using FinEdu.Application.Common.Interfaces;

namespace FinEdu.UnitTests;

/// <summary>
/// ტესტების საერთო ორეულები. ადრე თითოეულ ტესტ-კლასს თავისი ჰქონდა და ისინი ერთმანეთს
/// უკვე აცდენდნენ (სხვადასხვა სახელი, სხვადასხვა ქცევა) — ინტერფეისის ყოველი ცვლილება კი
/// მათ ცალ-ცალკე ასწორებინებდა.
/// </summary>
public sealed record TestUser(string? Account, bool IsAdministrator) : ICurrentUser
{
    public string? IpAddress => null;
    public string? VisitorId => null;
    public string? UserAgent => null;

    /// <summary>ფონური job-ის კონტექსტი — ყველა კონკურსზე მუშაობს, HTTP მოთხოვნა არ არსებობს.</summary>
    public static TestUser System() => new("system", IsAdministrator: true);
}

/// <summary>ვის გაეგზავნა წერილი — სწორედ ეს განასხვავებს მოთხოვნას დადასტურებისგან.</summary>
public sealed class FakeEmail : IEmailSender
{
    public List<(string To, string Subject)> Sent { get; } = [];

    public Task SendAsync(string to, string subject, string htmlBody, CancellationToken ct = default)
    {
        Sent.Add((to, subject));
        return Task.CompletedTask;
    }
}

/// <summary>რომელი მოქმედება ჩაიწერა ჟურნალში და რამდენჯერ.</summary>
public sealed class RecordingAudit : IAuditLogger
{
    private readonly List<string> _actions = [];

    public int Count(string action) => _actions.Count(a => a == action);

    public Task LogAsync(string action, string? entityType = null, string? entityId = null,
        string? details = null, CancellationToken ct = default)
    {
        _actions.Add(action);
        return Task.CompletedTask;
    }

    public Task LogForActorAsync(string actor, string action, string? entityType = null,
        string? entityId = null, string? details = null, CancellationToken ct = default)
    {
        _actions.Add(action);
        return Task.CompletedTask;
    }
}

/// <summary>
/// ფაილსაცავი მეხსიერებაში: რომელი გზები წაიშალა და რა ქავერები „დევს" დისკზე.
/// წაშლის ჩაწერა კრიტიკულია — სწორედ ის განასხვავებს „ჩანაწერი წავიდა"-ს და „ფაილიც წავიდა"-ს.
/// </summary>
public sealed class FakeStorage : IFileStorage
{
    public List<string> Deleted { get; } = [];

    /// <summary>„დისკზე" არსებული ქავერები — ობოლების გასუფთავების ტესტებისთვის.</summary>
    public List<StoredCover> Covers { get; } = [];

    public List<string> DeletedCovers { get; } = [];

    public Task DeleteAsync(string path, CancellationToken ct = default)
    {
        Deleted.Add(path);
        return Task.CompletedTask;
    }

    public Task<IReadOnlyList<StoredCover>> ListCoversAsync(CancellationToken ct = default) =>
        Task.FromResult<IReadOnlyList<StoredCover>>(Covers);

    public Task DeleteCoverAsync(string coverFileName, CancellationToken ct = default)
    {
        DeletedCovers.Add(coverFileName);
        Covers.RemoveAll(c => c.FileName == coverFileName);
        return Task.CompletedTask;
    }

    // ── ამ ტესტებში გამოუყენებელი ნაწილი ────────────────────────────
    // განზრახ აგდებს და არ აბრუნებს ცარიელს: შემთხვევითი გამოძახება ტესტმა
    // ხმაურის ნაცვლად ცხადი შეცდომით უნდა დაიჭიროს.

    public Task<string> SaveToQuarantineAsync(Stream content, string fileName, CancellationToken ct = default) =>
        throw new NotSupportedException();

    public Task<string> MoveToPermanentAsync(string quarantinePath, CancellationToken ct = default) =>
        throw new NotSupportedException();

    public Task<Stream> OpenReadAsync(string path, CancellationToken ct = default) =>
        throw new NotSupportedException();

    public Task<string> SaveCoverAsync(Stream content, string fileName, CancellationToken ct = default) =>
        throw new NotSupportedException();

    public Task<Stream> OpenCoverAsync(string coverFileName, CancellationToken ct = default) =>
        throw new NotSupportedException();
}
