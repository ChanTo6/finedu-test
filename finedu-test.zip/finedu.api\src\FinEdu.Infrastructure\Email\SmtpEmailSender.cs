﻿using FinEdu.Application.Common.Interfaces;
using FinEdu.Infrastructure.Options;
using MailKit.Net.Smtp;
using MailKit.Security;
using Microsoft.Extensions.Options;
using MimeKit;

namespace FinEdu.Infrastructure.Email;

/// <summary>SMTP relay-ით ავტო-პასუხი (MailKit). dev-ზე smtp4dev-ს დაუკავშირდება.</summary>
public class SmtpEmailSender(IOptions<SmtpOptions> opts) : IEmailSender
{
    private readonly SmtpOptions _opts = opts.Value;

    public async Task SendAsync(string to, string subject, string htmlBody, CancellationToken ct = default)
    {
        var message = new MimeMessage();
        message.From.Add(MailboxAddress.Parse(_opts.From));
        message.To.Add(MailboxAddress.Parse(to));
        message.Subject = subject;
        message.Body = new TextPart("html") { Text = htmlBody };

        using var client = new SmtpClient { Timeout = _opts.TimeoutSeconds * 1000 };
        var security = _opts.UseStartTls ? SecureSocketOptions.StartTls : SecureSocketOptions.None;
        await client.ConnectAsync(_opts.Host, _opts.Port, security, ct);
        if (!string.IsNullOrEmpty(_opts.User))
            await client.AuthenticateAsync(_opts.User, _opts.Password ?? string.Empty, ct);
        await client.SendAsync(message, ct);
        await client.DisconnectAsync(true, ct);
    }
}
