import {
  AfterViewInit,
  Component,
  ElementRef,
  OnDestroy,
  forwardRef,
  input,
  signal,
  viewChild,
} from '@angular/core';
import { ControlValueAccessor, NG_VALUE_ACCESSOR } from '@angular/forms';
import Quill, { Parchment } from 'quill';

/**
 * ტექსტის რედაქტორი (Quill). გამოიყენება კონკურსის აღწერაზე, პერს. მონაცემთა
 * შეტყობინებასა და დასტურის წერილზე — სამივეგან ერთი და იგივე ღილაკებით.
 *
 * <p>ბიბლიოთეკა პირდაპირ ერთვის და არა `ngx-quill`-ით: ის Angular 22-ს ითხოვს,
 * პროექტი კი 21-ზეა. ვერსია 2.0.2 განზრახაა და არა 2.0.3 — უახლესს XSS-ის
 * გაფრთხილება აქვს სწორედ HTML-ის გატანაზე (GHSA-v3m3-f69x-jf25), რომელსაც
 * აქ ვიყენებთ.</p>
 */
@Component({
  selector: 'app-rich-text-editor',
  templateUrl: './rich-text-editor.html',
  styleUrl: './rich-text-editor.scss',
  providers: [
    {
      provide: NG_VALUE_ACCESSOR,
      useExisting: forwardRef(() => RichTextEditor),
      multi: true,
    },
  ],
})
export class RichTextEditor implements AfterViewInit, OnDestroy, ControlValueAccessor {
  private readonly toolbar = viewChild.required<ElementRef<HTMLDivElement>>('toolbar');
  private readonly host = viewChild.required<ElementRef<HTMLDivElement>>('host');

  readonly placeholder = input('');

  /**
   * შემოკლებული ღილაკები — სათაურისთვის. სია და ციტატა ერთსტრიქონიან
   * ველში აზრს კარგავს და მხოლოდ გაფუჭების საშუალებას აძლევს ავტორს.
   */
  readonly compact = input(false);

  /** ასოს ზომები. ცარიელი მნიშვნელობა = ჩვეულებრივი, ანუ style საერთოდ არ ეწერება. */
  protected readonly sizes = ['12px', '14px', '16px', '20px', '24px', '32px'];

  private quill?: Quill;

  /** რედაქტორის შექმნამდე მოსული მნიშვნელობა — patchValue ხშირად უსწრებს. */
  private pending = '';

  private readonly disabled = signal(false);

  private onChange: (value: string) => void = () => {};
  private onTouched: () => void = () => {};

  ngAfterViewInit(): void {
    RichTextEditor.registerStyleFormats(this.sizes);

    this.quill = new Quill(this.host().nativeElement, {
      theme: 'snow',
      placeholder: this.placeholder(),
      modules: { toolbar: this.toolbar().nativeElement },
    });

    this.write(this.pending);
    if (this.disabled()) this.quill.enable(false);

    // 'user' — API-ით ჩაწერილი შიგთავსი ცვლილებად არ ითვლება, თორემ ფორმა
    // ჩატვირთვისთანავე „შეცვლილად" აღინიშნებოდა.
    this.quill.on('text-change', (_delta, _old, source) => {
      if (source === 'user') this.onChange(this.currentHtml());
    });

    this.quill.on('selection-change', (range) => {
      if (range === null) this.onTouched();
    });
  }

  ngOnDestroy(): void {
    // Quill-ს ცხადი დაშლა არ აქვს; მოსმენების მოხსნა კი საჭიროა, თორემ დამმუშავებლები
    // უკვე წაშლილ კომპონენტს ინახავს.
    this.quill?.off('text-change');
    this.quill?.off('selection-change');
  }

  // ── ControlValueAccessor ────────────────────────────────────────

  writeValue(value: string | null): void {
    this.pending = value ?? '';
    if (this.quill) this.write(this.pending);
  }

  registerOnChange(fn: (value: string) => void): void {
    this.onChange = fn;
  }

  registerOnTouched(fn: () => void): void {
    this.onTouched = fn;
  }

  setDisabledState(isDisabled: boolean): void {
    this.disabled.set(isDisabled);
    this.quill?.enable(!isDisabled);
  }

  // ── შიგნეული ────────────────────────────────────────────────────

  /** სერვერიდან მოსული HTML — უკვე გაწმენდილი (იხ. backend `IHtmlContent`). */
  private write(html: string): void {
    const quill = this.quill;
    if (!quill) return;

    quill.setContents(quill.clipboard.convert({ html }), 'silent');
  }

  /**
   * `getSemanticHTML` და არა `root.innerHTML`: Quill სიის ტიპს `data-list`
   * ატრიბუტით აღნიშნავს და ორივეს `<ol>`-ად წერს — სერვერზე გაწმენდის შემდეგ
   * ბურთულებიანი სია ნუმერაციად გადაიქცეოდა.
   */
  private currentHtml(): string {
    const quill = this.quill;
    if (!quill) return '';

    // ცარიელი რედაქტორიც `<p><br></p>`-ს აბრუნებს — ეს ცარიელი ველია და არა შიგთავსი
    return quill.getText().trim().length === 0 ? '' : quill.getSemanticHTML();
  }

  private static registered = false;

  /**
   * ფერი, ზომა და სწორება კლასების ნაცვლად `style`-ით. კლასი მხოლოდ Quill-ის
   * თავის CSS-თან ერთად მუშაობს — საჯარო გვერდსა და წერილში ის არ არის, ანუ
   * გაფორმება უბრალოდ გაქრებოდა. `style` კი ორივეგან რჩება.
   */
  private static registerStyleFormats(sizes: string[]): void {
    if (RichTextEditor.registered) return;

    const size = Quill.import('attributors/style/size') as Parchment.StyleAttributor;
    size.whitelist = sizes;

    Quill.register(size, true);
    Quill.register(Quill.import('attributors/style/color') as Parchment.StyleAttributor, true);
    Quill.register(Quill.import('attributors/style/background') as Parchment.StyleAttributor, true);
    Quill.register(Quill.import('attributors/style/align') as Parchment.StyleAttributor, true);

    RichTextEditor.registered = true;
  }
}
