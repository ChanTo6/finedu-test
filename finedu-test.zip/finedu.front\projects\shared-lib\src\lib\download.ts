/**
 * ჩამოტვირთული blob-ის შენახვა ფაილად. ორივე აპლიკაცია იყენებს (ადმინის Excel/ფაილები
 * და ჟიურის ფაილები) — ადრე ორივეგან ცალკე ეწერა და მხოლოდ ერთში სწორდებოდა.
 *
 * პირდაპირი `<a href>` ბმული აქ არ გამოდგება: ბრაუზერის ნავიგაციას Angular-ის
 * interceptor ვერ წვდება, ამიტომ Authorization header არ იგზავნება და
 * ავტორიზებული endpoint 401-ს აბრუნებს.
 */
export function saveBlob(blob: Blob, fileName: string): void {
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = fileName;
  link.rel = 'noopener';

  // ბმული დოკუმენტში უნდა იყოს — Firefox-ში მოწყვეტილ ელემენტზე click() უშედეგოა
  document.body.appendChild(link);
  link.click();
  link.remove();

  // revoke *არა* მაშინვე: სინქრონული გაუქმება ჩამოტვირთვას მის დაწყებამდე აუქმებდა
  // (დიდი ფაილი და Firefox — ყველაზე ხშირი შემთხვევა). შემდეგი macrotask უკვე
  // ჩამოტვირთვის დაწყების შემდეგაა.
  setTimeout(() => URL.revokeObjectURL(url));
}
