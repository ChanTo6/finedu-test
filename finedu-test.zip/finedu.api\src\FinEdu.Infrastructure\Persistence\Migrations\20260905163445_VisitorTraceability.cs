﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace FinEdu.Infrastructure.Persistence.Migrations
{
    /// <inheritdoc />
    public partial class VisitorTraceability : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "SubmitterIp",
                table: "Submissions",
                type: "nvarchar(64)",
                maxLength: 64,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "UserAgent",
                table: "Submissions",
                type: "nvarchar(512)",
                maxLength: 512,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "VisitorId",
                table: "Submissions",
                type: "nvarchar(64)",
                maxLength: 64,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "UserAgent",
                table: "AuditLogs",
                type: "nvarchar(512)",
                maxLength: 512,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "VisitorId",
                table: "AuditLogs",
                type: "nvarchar(64)",
                maxLength: 64,
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_Submissions_FormId_SubmitterIp",
                table: "Submissions",
                columns: new[] { "FormId", "SubmitterIp" });

            migrationBuilder.CreateIndex(
                name: "IX_Submissions_FormId_VisitorId",
                table: "Submissions",
                columns: new[] { "FormId", "VisitorId" });

            migrationBuilder.CreateIndex(
                name: "IX_AuditLogs_IpAddress",
                table: "AuditLogs",
                column: "IpAddress");

            migrationBuilder.CreateIndex(
                name: "IX_AuditLogs_VisitorId",
                table: "AuditLogs",
                column: "VisitorId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropIndex(
                name: "IX_Submissions_FormId_SubmitterIp",
                table: "Submissions");

            migrationBuilder.DropIndex(
                name: "IX_Submissions_FormId_VisitorId",
                table: "Submissions");

            migrationBuilder.DropIndex(
                name: "IX_AuditLogs_IpAddress",
                table: "AuditLogs");

            migrationBuilder.DropIndex(
                name: "IX_AuditLogs_VisitorId",
                table: "AuditLogs");

            migrationBuilder.DropColumn(
                name: "SubmitterIp",
                table: "Submissions");

            migrationBuilder.DropColumn(
                name: "UserAgent",
                table: "Submissions");

            migrationBuilder.DropColumn(
                name: "VisitorId",
                table: "Submissions");

            migrationBuilder.DropColumn(
                name: "UserAgent",
                table: "AuditLogs");

            migrationBuilder.DropColumn(
                name: "VisitorId",
                table: "AuditLogs");
        }
    }
}
