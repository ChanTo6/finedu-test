import { InjectionToken } from '@angular/core';
import { FILE_CATEGORIES } from './file-categories';

export type TextParams = Record<string, string | number>;

/** წარწერა გასაღებით; `{name}` ჩასასმელები `params`-იდან ივსება. */
export type UiText = (key: string, params?: TextParams) => string;

export function fillText(text: string, params?: TextParams): string {
  if (!params) return text;
  return Object.entries(params).reduce(
    (result, [name, value]) => result.replaceAll(`{${name}}`, String(value)),
    text,
  );
}

/**
 * საერთო კომპონენტების ქართული წარწერები. საჯარო საიტი მათ სერვერის ტექსტით ცვლის
 * (UI_TEXT-ის საკუთარი provider-ით), ადმინის პანელი კი ამ ნაგულისხმევს იყენებს — ადმინის
 * ზონიდან საჯარო API-ზე მიმართვა იზოლაციის წესით დაუშვებელია.
 * ტექსტი იგივეა, რაც სერვერის UiTexts.resx-ში.
 */
const GEORGIAN: Record<string, string> = {
  'form.maxMb': 'მაქს. {mb} MB',
  'form.fieldMaxFiles': 'ამ ველში მაქს. {n} ფაილი',
  'form.totalMaxFiles': 'მთელ განაცხადზე სულ მაქს. {n} ფაილი',
  'form.fileMissing': 'გთხოვთ ატვირთოთ ფაილი „{label}"-სთვის.',
  'form.fieldMissing': 'გთხოვთ შეავსოთ „{label}".',
  'form.errFieldMaxFiles': 'ამ ველში მაქსიმუმ {n} ფაილი.',
  'form.errTotalFiles':
    'განაცხადზე სულ მაქს. {total} ფაილი — სხვა ველებში უკვე არჩეულია {elsewhere}.',
  'form.errTypeNotAllowed': 'ფაილის ტიპი .{ext} დაუშვებელია.',
  'form.errTypeNotForField': 'ტიპი .{ext} ამ ველისთვის დაუშვებელია.',
  'form.errTooLarge': '„{name}" — {size} MB, ლიმიტია {max} MB.',
  ...Object.fromEntries(FILE_CATEGORIES.map((c) => [`fileCategory.${c.key}`, c.label])),
};

export const UI_TEXT = new InjectionToken<UiText>('UI_TEXT', {
  providedIn: 'root',
  factory: () => (key, params) => fillText(GEORGIAN[key] ?? key, params),
});
