﻿using System.Net.Mail;
using FinEdu.Application.Common.Exceptions;
using FinEdu.Application.Common.Models;
using FinEdu.Domain.Entities;
using FinEdu.Domain.Enums;
using FinEdu.Domain.ValueObjects;
using FinEdu.Application.Resources;

namespace FinEdu.Application.Submissions.Validators;

/// <summary>
/// დინამიური ვალიდაცია — ფორმის ველების განსაზღვრებებზე დაყრდნობით ამოწმებს
/// შემოსულ პასუხებს (required, maxWords, options, scale, file rules).
/// ერთი ვალიდატორი ყველა ფორმისთვის.
/// </summary>
public class SubmissionValidator
{
    /// <summary>
    /// ერთი პასუხის სიმბოლოების ჭერი. სიტყვების ლიმიტი (50/500) ბიზნეს-წესია, ეს კი
    /// ბოროტად გამოყენების ზღვარია: „სიტყვა" თვითონ შეიძლება იყოს მეგაბაიტიანი და
    /// 500 ასეთი სიტყვა წესს არ არღვევდა, სვეტი კი nvarchar(max)-ია.
    /// 500 სიტყვა ქართულად ~4 000 სიმბოლოა — 100 000 მრავალჯერადი მარაგია.
    /// </summary>
    private const int MaxValueLength = 100_000;

    public void Validate(Form form, CreateSubmissionRequest request, IReadOnlyList<SubmissionFileInput> files)
    {
        var errors = new Dictionary<string, string[]>();

        // GDPR: მონაცემთა დამუშავების თანხმობა სავალდებულოა (doc §4.1)
        if (!request.ConsentDataProcessing)
            errors["consent"] = new[] { Messages.ConsentRequired };

        ValidateFieldsBelongToForm(form, request, files, errors);

        // doc §3.2: ზღვარი მთელ განაცხადზეა — ორი ფაილის ველი 6 ფაილს არ უნდა ნიშნავდეს
        if (files.Count > FileUploadPolicy.MaxFilesPerSubmission)
            errors["files"] = new[] { Messages.TooManyFilesTotal(FileUploadPolicy.MaxFilesPerSubmission) };

        if (!string.IsNullOrWhiteSpace(request.NotificationEmail) && !IsValidEmail(request.NotificationEmail))
            errors["notificationEmail"] = new[] { Messages.InvalidEmail };

        var valuesByField = request.Values.ToDictionary(v => v.FieldId, v => v.Value);
        var filesByField = files.GroupBy(f => f.FieldId).ToDictionary(g => g.Key, g => g.ToList());

        foreach (var field in form.Fields)
        {
            var key = field.Id.ToString();
            valuesByField.TryGetValue(field.Id, out var value);
            var hasValue = !string.IsNullOrWhiteSpace(value);
            filesByField.TryGetValue(field.Id, out var fieldFiles);

            if (field.Type == FieldType.FileUpload)
            {
                ValidateFile(field, fieldFiles, errors, key);
                continue;
            }

            if (field.IsRequired && !hasValue)
            {
                errors[key] = new[] { Messages.FieldRequired(field.Label) };
                continue;
            }
            if (!hasValue) continue;

            if (value!.Length > MaxValueLength)
            {
                errors[key] = new[] { Messages.AnswerTooLong(field.Label) };
                continue;
            }

            switch (field.Type)
            {
                case FieldType.ShortAnswer:
                case FieldType.LongAnswer:
                    var max = field.Config.MaxWords ?? (field.Type == FieldType.ShortAnswer ? 50 : 500);
                    if (WordCount(value!) > max)
                        errors[key] = new[] { Messages.MaxWords(field.Label, max) };
                    break;

                case FieldType.MultipleChoice:
                    if (field.Config.Options is { Count: > 0 } && !field.Config.Options.Contains(value!))
                        errors[key] = new[] { Messages.InvalidOption(field.Label) };
                    break;

                case FieldType.Checkboxes:
                    var selected = value!.Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);
                    if (field.Config.Options is { Count: > 0 } && selected.Any(s => !field.Config.Options.Contains(s)))
                        errors[key] = new[] { Messages.InvalidOption(field.Label) };
                    break;

                case FieldType.LinearScale:
                    if (!int.TryParse(value, out var n) ||
                        n < (field.Config.ScaleMin ?? 1) || n > (field.Config.ScaleMax ?? 5))
                        errors[key] = new[] { Messages.ScaleOutOfRange(field.Label) };
                    break;
            }
        }

        if (errors.Count > 0)
            throw new ValidationException(errors);
    }

    /// <summary>
    /// პასუხი მხოლოდ <b>ამ ფორმის</b> ველზე მიიღება, ფაილი კი — მხოლოდ ფაილის ველზე.
    ///
    /// <para>ქვევით მოცემული ციკლი ფორმის ველებს გადის და ფაილს მხოლოდ მაშინ ამოწმებს,
    /// როცა ველის ტიპი <see cref="FieldType.FileUpload"/>-ია. ანუ ორივე შემთხვევაში —
    /// უცხო FieldId და არსებული, მაგრამ ტექსტური ველის FieldId — ატვირთული ფაილი
    /// ვერცერთ შემოწმებას ვერ ხვდებოდა: ვერც ტიპისას, ვერც ზომისას, ვერც ხელმოწერისას —
    /// და მაინც ინახებოდა დისკზე.</para>
    ///
    /// <para>პასუხებზე იგივე გზა ბაზაში შეუზღუდავი რაოდენობის ჩანაწერს უშვებდა
    /// (სხვა ფორმის ნამდვილი ველის id საჯარო ფორმის JSON-ში ისედაც ჩანს).</para>
    ///
    /// <para>შემოწმება <b>ყველა დანარჩენზე ადრე</b> დგას: ფაილები მხოლოდ ვალიდაციის
    /// გავლის შემდეგ ინახება, ანუ დაუშვებელი ფაილი დისკამდე ვერ აღწევს.</para>
    /// </summary>
    private static void ValidateFieldsBelongToForm(
        Form form, CreateSubmissionRequest request, IReadOnlyList<SubmissionFileInput> files,
        Dictionary<string, string[]> errors)
    {
        var known = form.Fields.Select(f => f.Id).ToHashSet();
        var fileFields = form.Fields.Where(f => f.Type == FieldType.FileUpload).Select(f => f.Id).ToHashSet();

        // კონკრეტული id-ის დაბრუნება სხვა ფორმის ველების არსებობას ამხელდა
        if (request.Values.Any(v => !known.Contains(v.FieldId)))
            errors["fields"] = new[] { Messages.UnknownField };

        if (files.Any(f => !fileFields.Contains(f.FieldId)))
            errors["files"] = new[] { Messages.FileOnNonFileField };
    }

    private static void ValidateFile(FormField field, List<SubmissionFileInput>? files,
        Dictionary<string, string[]> errors, string key)
    {
        var count = files?.Count ?? 0;
        if (field.IsRequired && count == 0)
        {
            errors[key] = new[] { Messages.FileRequired(field.Label) };
            return;
        }
        if (files is null) return;

        // მაქსიმუმი ყოველთვის სერვერის პოლიტიკიდან — ფორმის კონფიგს მხოლოდ შევიწროება შეუძლია.
        var maxFiles = Math.Min(field.Config.MaxFiles ?? FileUploadPolicy.MaxFilesPerSubmission,
                                FileUploadPolicy.MaxFilesPerSubmission);
        if (count > maxFiles)
            errors[key] = new[] { Messages.MaxFilesInField(field.Label, maxFiles) };

        foreach (var f in files)
        {
            var ext = FileUploadPolicy.NormalizeExtension(f.FileName);

            // 1) ტიპი დასაშვებთა სიაშია? (სია სერვერზეა, არა ფორმის კონფიგში)
            if (!FileUploadPolicy.TryGetRule(ext, out var rule))
            {
                errors[key] = new[] { Messages.FileTypeNotAllowed(field.Label) };
                continue;
            }

            // 2) ადმინს შეუძლია კიდევ უფრო შეზღუდოს ტიპები
            if (field.Config.AllowedExtensions is { Count: > 0 } &&
                !field.Config.AllowedExtensions.Contains(ext, StringComparer.OrdinalIgnoreCase))
            {
                errors[key] = new[] { Messages.FileExtensionNotAllowed(field.Label, ext) };
                continue;
            }

            // 3) ზომა — კატეგორიის მაქსიმუმი, კონფიგს მხოლოდ დაწევა შეუძლია
            var maxBytes = Math.Min(field.Config.MaxFileSizeBytes ?? rule.MaxBytes, rule.MaxBytes);
            if (f.SizeBytes > maxBytes)
            {
                errors[key] = new[] { Messages.FileTooLarge(field.Label, maxBytes / (1024 * 1024)) };
                continue;
            }

            // 4) შიგთავსი ემთხვევა თუ არა გაფართოებას (magic bytes) — გადარქმეული .exe არ გაძვრეს
            if (!FileSignature.MatchesStream(ext, f.Content))
                errors[key] = new[] { Messages.FileContentMismatch(field.Label) };
        }
    }

    private static int WordCount(string text) =>
        text.Split(new[] { ' ', '\n', '\r', '\t' }, StringSplitOptions.RemoveEmptyEntries).Length;

    /// <summary>
    /// MailAddress-ის პარსერი regex-ზე საიმედოა. სიგრძის მაქსიმუმი ბაზის სვეტს ემთხვევა (320),
    /// ხოლო ახალი ხაზის აკრძალვა header injection-ის დამატებითი ბარიერია.
    /// </summary>
    private static bool IsValidEmail(string value)
    {
        if (value.Length > 320 || value.Any(char.IsControl)) return false;
        return MailAddress.TryCreate(value, out var parsed) && parsed.Address == value;
    }
}
