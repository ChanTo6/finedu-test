﻿using FinEdu.Application.Common.Models;

namespace FinEdu.Application.Submissions;

public interface ISubmissionService
{
    Task<Guid> CreateAsync(string token, CreateSubmissionRequest request,
        IReadOnlyList<SubmissionFileInput> files, CancellationToken ct = default);

    /// <summary>
    /// კონკურსის განაცხადები გვერდებად. ძებნა პასუხების ტექსტსა და განაცხადის ID-ზე
    /// მუშაობს — ადმინს ყველა მონაცემი ერთბაშად არ უნდა ეჩვენებოდეს (doc §4.1).
    /// </summary>
    Task<PagedResult<SubmissionDto>> ListByFormAsync(
        Guid formId, PageQuery query, CancellationToken ct = default);

    /// <summary>retention გასული submission-ების არააღდგენადი წაშლა (Worker-ი იძახებს).</summary>
    Task<int> DeleteExpiredAsync(CancellationToken ct = default);
}
