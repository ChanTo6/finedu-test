﻿using FinEdu.Application.Common.Models;
using FinEdu.Domain.Entities;
using Riok.Mapperly.Abstractions;

namespace FinEdu.Application.Common.Mapping;

/// <summary>Mapperly (source-gen, უფასო) — AutoMapper-ის ნაცვლად.</summary>
[Mapper]
public partial class FormMapper
{
    // DTO-ში განზრახ არ გადადის: განაცხადები და წვდომის სია (ცალკე endpoint-ებია)
    // და აუდიტის ველები.
    [MapperIgnoreSource(nameof(Form.Submissions))]
    [MapperIgnoreSource(nameof(Form.AccessList))]
    [MapperIgnoreSource(nameof(Form.Jurors))]
    [MapperIgnoreSource(nameof(Form.RetentionUntil))]
    [MapperIgnoreSource(nameof(Form.ApprovedBy))]
    [MapperIgnoreSource(nameof(Form.ApprovedAt))]
    [MapperIgnoreSource(nameof(Form.CreatedAt))]
    [MapperIgnoreSource(nameof(Form.CreatedBy))]
    // RowVersion ხელით ივსება: byte[] → base64 სტრიქონი ავტომატურად არ ითარგმნება
    [MapperIgnoreSource(nameof(Form.RowVersion))]
    [MapperIgnoreTarget(nameof(FormDto.RowVersion))]
    public partial FormDto ToDto(Form form);

    [MapperIgnoreSource(nameof(FormField.FormId))]
    [MapperIgnoreSource(nameof(FormField.Form))]
    [MapperIgnoreSource(nameof(FormField.CreatedAt))]
    [MapperIgnoreSource(nameof(FormField.CreatedBy))]
    public partial FormFieldDto ToFieldDto(FormField field);

    // PublicFormDto ხელით იწყობა FormService-ში — HasCover გამოთვლადია, გზა საჯაროდ არ გადის.
}
