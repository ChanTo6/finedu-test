/**
 * აპლიკაციის როლები — backend-ის `Common/Security/Roles.cs`-ის სარკე.
 *
 * ორივე როლი AD-ის ჯგუფიდან მოდის; frontend მათ მხოლოდ იმისთვის იცნობს, რომ
 * ინტერფეისმა უსარგებლო ღილაკი არ აჩვენოს. **უფლებას სერვერი წყვეტს** — აქაური
 * შემოწმება მხოლოდ მოხერხებულობაა და დაცვის ბარიერად არასდროს ჩაითვლება.
 */
export const Roles = {
  Administrator: 'Administrator',
  Moderator: 'Moderator',
} as const;
