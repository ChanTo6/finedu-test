using System.Net;
using FinEdu.Infrastructure.Http;
using Xunit;

namespace FinEdu.IntegrationTests;

/// <summary>
/// „ყველა, ვინც საიტს გახსნის, უნდა იყოს იდენტიფიცირებული" — რეალურ მილსადენზე
/// მოწმდება: ნიშანი პირველივე მოთხოვნაზე გაიცემა, ვალიდური ხელახლა გამოიყენება,
/// მოგონილი კი უარყოფილია (cookie კლიენტის ხელშია, ანუ მისი შინაარსი უცხო მონაცემია).
/// </summary>
public class VisitorTraceabilityTests(PublicApiFactory factory) : IClassFixture<PublicApiFactory>
{
    private static string? CookieValue(HttpResponseMessage response) =>
        response.Headers.TryGetValues("Set-Cookie", out var values)
            ? values.FirstOrDefault(v => v.StartsWith(VisitorCookie.CookieName + "="))
            : null;

    /// <summary>ახალი კლიენტი — cookie-ს ჩვენ ვაყენებთ, არაფერს არ ვეკითხებით.</summary>
    [Fact]
    public async Task Every_visitor_receives_an_anonymous_id_on_first_request()
    {
        var client = factory.CreateClient();

        var response = await client.GetAsync("/api/forms");
        var cookie = CookieValue(response);

        Assert.NotNull(cookie);
        Assert.Contains("httponly", cookie!.ToLowerInvariant());
        Assert.Contains("secure", cookie.ToLowerInvariant());

        var id = cookie.Split(';')[0].Split('=')[1];
        Assert.Equal(32, id.Length);
        Assert.True(id.All(Uri.IsHexDigit));
    }

    /// <summary>ვალიდურ ნიშანს არ ვცვლით — თორემ ყოველი მოთხოვნა ახალ „ვიზიტორად" ჩაითვლებოდა.</summary>
    [Fact]
    public async Task Valid_existing_id_is_not_replaced()
    {
        var client = factory.CreateClient();
        client.DefaultRequestHeaders.Add("Cookie", $"{VisitorCookie.CookieName}=0123456789abcdef0123456789abcdef");

        var response = await client.GetAsync("/api/forms");

        Assert.Null(CookieValue(response));   // ახალი არ გაცემულა
    }

    [Theory]
    [InlineData("not-hex")]
    [InlineData("0123456789ABCDEF0123456789ABCDEF")]
    [InlineData("'; DROP TABLE Submissions; --")]
    public async Task Forged_id_is_replaced_with_a_real_one(string forged)
    {
        var client = factory.CreateClient();
        client.DefaultRequestHeaders.Add("Cookie", $"{VisitorCookie.CookieName}={forged}");

        var response = await client.GetAsync("/api/forms");
        var cookie = CookieValue(response);

        Assert.NotNull(cookie);
        Assert.DoesNotContain(forged, cookie!);
    }

    /// <summary>ჟიურის endpoint-ებზეც იგივე მილსადენია — ვიზიტორის ნიშანი აქაც უნდა გაიცეს.</summary>
    [Fact]
    public async Task Jury_pages_are_traced_too()
    {
        var client = factory.CreateClient();

        var response = await client.GetAsync($"/api/jury/{Guid.NewGuid():N}");

        Assert.Equal(HttpStatusCode.Unauthorized, response.StatusCode);
        Assert.NotNull(CookieValue(response));
    }
}
