﻿using FinEdu.Domain.Common;
using FinEdu.Domain.Enums;

namespace FinEdu.Domain.Entities;

/// <summary>
/// კონკრეტული კონკურსის ჟიურის წევრი — გარე მოქალაქე, რომელსაც AD ანგარიში არ აქვს.
/// წვდომას ორი ფაქტორით იღებს: გამოუცნობი ბმული (<see cref="AccessToken"/>) და
/// მეილზე მისული PIN. ბმულის მოპარვა მარტო არ კმარა, PIN-ის გამოცნობაც — არა.
/// </summary>
public class Juror : BaseEntity
{
    public Guid FormId { get; set; }
    public Form? Form { get; set; }

    /// <summary>რეგისტრირებული მეილი — PIN მხოლოდ აქ იგზავნება, კლიენტისგან მისამართს არასდროს ვიღებთ.</summary>
    public string Email { get; set; } = string.Empty;

    public string DisplayName { get; set; } = string.Empty;

    /// <summary>
    /// დადასტურებულია თუ ჯერ კიდევ ადმინისტრატორის თანხმობას ელოდება.
    /// დაუდასტურებელს წერილიც არ მისვლია და შესვლასაც ვერ შეძლებს.
    /// </summary>
    public JurorStatus Status { get; set; } = JurorStatus.PendingApproval;

    /// <summary>ვინ დაადასტურა (AD ანგარიში). მოთხოვნის ავტორი <c>CreatedBy</c>-შია.</summary>
    public string? ApprovedBy { get; set; }

    public DateTimeOffset? ApprovedAt { get; set; }

    /// <summary>ბმულის უნიკალური, გამოუცნობი token (/j/{token}).</summary>
    public string AccessToken { get; set; } = string.Empty;

    /// <summary>
    /// PBKDF2 hash — PIN ღია ტექსტით არსად ინახება (ბაზაშიც, ლოგშიც არა).
    ///
    /// <para>კოდი მხოლოდ დადასტურების შემდეგ არსებობს: დაუდასტურებელ მოთხოვნას წერილიც
    /// არ გაუგზავნია, ანუ მოქმედი კოდიც არ უნდა ჰქონდეს. <c>null</c> = ჯერ არ გაცემულა.</para>
    /// </summary>
    public string? PinHash { get; set; }

    /// <summary>hash-ის salt — <see cref="PinHash"/>-თან ერთად იწერება და ერთად ინულება.</summary>
    public string? PinSalt { get; set; }

    /// <summary>PIN-ის ვადა. ვადაგასულით შესვლა არ ხდება — საჭიროა „PIN დამავიწყდა".</summary>
    public DateTimeOffset? PinExpiresAt { get; set; }

    /// <summary>ბოლო გაგზავნის დრო — თავიდან გაგზავნის cooldown-ისთვის (მეილის დაბომბვის წინააღმდეგ).</summary>
    public DateTimeOffset PinSentAt { get; set; } = DateTimeOffset.UtcNow;

    /// <summary>ზედიზედ არასწორი მცდელობები. წარმატებულ შესვლაზე ნულდება.</summary>
    public int FailedAttempts { get; set; }

    /// <summary>ბლოკირების ვადა brute force-ის შემდეგ. 6-ნიშნა PIN მხოლოდ 10^6 ვარიანტია.</summary>
    public DateTimeOffset? LockedUntil { get; set; }

    public DateTimeOffset? LastLoginAt { get; set; }

    /// <summary>ადმინის მიერ გამორთვა — ჩანაწერს ვინახავთ (შეფასებები მასზეა მიბმული), წვდომას ვწყვეტთ.</summary>
    public bool IsActive { get; set; } = true;

    public ICollection<Evaluation> Evaluations { get; set; } = new List<Evaluation>();

    /// <summary>
    /// ახალი PIN: hash, salt, ვადა და გაგზავნის დრო ერთად იწერება, ძველი ბლოკირება კი
    /// იხსნება — ძველი კოდი ისედაც აღარ მუშაობს და მისი ბლოკირების შენარჩუნება მხოლოდ
    /// ხელს შეუშლიდა.
    ///
    /// <para>წესი დომენშია, რადგან PIN სამ ადგილას გაიცემა (დამატება, დადასტურება,
    /// „PIN დამავიწყდა") — ცალ-ცალკე დაწერილი სამი ვარიანტი ადრე თუ გვიან ერთმანეთს
    /// აცდებოდა: მაგალითად, ვადის განახლების გარეშე ახალი კოდი მაშინვე ვადაგასული იქნებოდა.</para>
    /// </summary>
    public void IssuePin(string hash, string salt, int validDays, DateTimeOffset now)
    {
        PinHash = hash;
        PinSalt = salt;
        PinExpiresAt = now.AddDays(validDays);
        PinSentAt = now;

        FailedAttempts = 0;
        LockedUntil = null;
    }
}
