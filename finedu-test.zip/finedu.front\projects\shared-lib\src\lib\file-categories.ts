/** ერთი ფორმატი ადმინისთვის — JPG ორ გაფართოებას (jpg, jpeg) ფარავს. */
export interface FileFormat {
  label: string;
  extensions: string[];
}

export interface FileCategory {
  /** წარწერის გასაღები საჯარო საიტზე (`fileCategory.{key}`) — label ადმინისთვისაა. */
  key: string;
  label: string;
  /** მხოლოდ საჩვენებლად — ზღვარს სერვერი ამოწმებს (FileUploadPolicy). */
  maxMb: number;
  formats: FileFormat[];
}

/**
 * ფაილის ტიპები და ზომები doc §3.2-ის მიხედვით. არქივები (ZIP, RAR) განზრახ არ არის —
 * ამოღებულია docx კომენტარით #1 და სერვერიც არ იღებს.
 */
export const FILE_CATEGORIES: readonly FileCategory[] = [
  {
    key: 'images',
    label: 'სურათები',
    maxMb: 10,
    formats: [
      { label: 'JPG', extensions: ['jpg', 'jpeg'] },
      { label: 'PNG', extensions: ['png'] },
      { label: 'GIF', extensions: ['gif'] },
    ],
  },
  {
    key: 'documents',
    label: 'დოკუმენტები',
    maxMb: 25,
    formats: [
      { label: 'PDF', extensions: ['pdf'] },
      { label: 'DOC', extensions: ['doc'] },
      { label: 'DOCX', extensions: ['docx'] },
      { label: 'XLS', extensions: ['xls'] },
      { label: 'XLSX', extensions: ['xlsx'] },
    ],
  },
  {
    key: 'presentations',
    label: 'პრეზენტაციები',
    maxMb: 50,
    formats: [
      { label: 'PPT', extensions: ['ppt'] },
      { label: 'PPTX', extensions: ['pptx'] },
    ],
  },
  {
    key: 'videos',
    label: 'ვიდეოები',
    maxMb: 200,
    formats: [
      { label: 'MP4', extensions: ['mp4'] },
      { label: 'MOV', extensions: ['mov'] },
      { label: 'AVI', extensions: ['avi'] },
    ],
  },
];
