using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using FinEdu.Application.Common.Interfaces;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;

namespace FinEdu.Infrastructure.Identity;

/// <summary>AD-ს დადასტურების შემდეგ JWT-ს გამოსცემს (როლები claim-ებში).</summary>
public class JwtTokenService(IConfiguration config) : ITokenService
{
    /// <summary>როლის claim-ის სახელი. ვალიდაციის მხარეს იგივე უნდა ეწეროს (იხ. JwtSetup).</summary>
    internal const string RoleClaim = "role";

    public string Create(AdUser user)
    {
        var jwt = config.GetSection("Jwt");
        var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwt["Key"]!));
        var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

        var claims = new List<Claim>
        {
            new(JwtRegisteredClaimNames.UniqueName, user.Account),
            // jti — ტოკენის უნიკალური ID; logout-ზე სწორედ ეს ემატება გაუქმებულთა სიაში
            new(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString("N"))
        };
        claims.AddRange(user.Roles.Select(r => new Claim(RoleClaim, r)));

        // ვადა კონფიგურირებადია — ბანკის პოლიტიკამ შეიძლება უფრო მოკლე მოითხოვოს
        var expiryMinutes = jwt.GetValue<int?>("ExpiryMinutes") ?? 60;

        var handler = new JwtSecurityTokenHandler();

        // ნაგულისხმევი outbound map claim-ების სახელებს ჩუმად ცვლის (WS-Federation-ის მემკვიდრეობა).
        // ცხადი სახელები ვალიდაციის მხარესთან შეთანხმებას ერთმნიშვნელოვანს ხდის.
        handler.OutboundClaimTypeMap.Clear();

        var token = new JwtSecurityToken(
            issuer: jwt["Issuer"],
            audience: jwt["Audience"],
            claims: claims,
            expires: DateTime.UtcNow.AddMinutes(expiryMinutes),
            signingCredentials: creds);

        return handler.WriteToken(token);
    }
}
