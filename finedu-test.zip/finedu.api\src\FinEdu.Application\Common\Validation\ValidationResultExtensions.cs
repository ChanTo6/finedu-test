using FinEdu.Application.Common.Exceptions;
using FluentValidation.Results;

namespace FinEdu.Application.Common.Validation;

/// <summary>
/// FluentValidation-ის შედეგი → ჩვენი <see cref="ValidationException"/> (და მისგან 400,
/// ველების სიით).
///
/// <para>ეს ექვსი ხაზი სამივე controller-ში სიტყვასიტყვით ეწერა. ერთში შესწორება
/// დანარჩენებს არ ეხებოდა — ანუ ერთი და იგივე შეცდომა სამი სხვადასხვა ფორმატით
/// დაბრუნდებოდა და კლიენტის მხარეს ველების ჩვენება ზოგ endpoint-ზე გატყდებოდა.</para>
/// </summary>
public static class ValidationResultExtensions
{
    public static void ThrowIfInvalid(this ValidationResult result)
    {
        if (result.IsValid) return;

        throw new ValidationException(result.Errors
            .GroupBy(e => e.PropertyName)
            .ToDictionary(g => g.Key, g => g.Select(e => e.ErrorMessage).ToArray()));
    }
}
