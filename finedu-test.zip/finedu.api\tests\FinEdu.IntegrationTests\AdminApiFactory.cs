﻿using FinEdu.Application.Common.Interfaces;
using FinEdu.Domain.Entities;
using FinEdu.Domain.Enums;
using FinEdu.Infrastructure.Persistence;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;
using Microsoft.Extensions.Hosting;

namespace FinEdu.IntegrationTests;

/// <summary>
/// AdminApi მეხსიერების ბაზაზე — SQL Server-ის გარეშე გაშვებადი, რომ ტესტები
/// ნებისმიერ მანქანაზე და CI-ზე მუშაობდეს.
/// </summary>
public class AdminApiFactory : WebApplicationFactory<Program>
{
    private readonly string _dbName = $"finedu-tests-{Guid.NewGuid():N}";

    protected override void ConfigureWebHost(IWebHostBuilder builder)
    {
        // Development — DevAuth-ის ჩასართავად; LDAP ჰოსტი ცარიელია, ე.ი. მისი ვალიდაცია გამოტოვდება
        builder.UseEnvironment(Environments.Development);

        builder.UseSetting("Jwt:Key", "integration-tests-signing-key-at-least-32-bytes");
        builder.UseSetting("Jwt:Issuer", "FinEdu.AdminApi");
        builder.UseSetting("Jwt:Audience", "FinEdu.Admin");
        builder.UseSetting("Ldap:Host", "");
        builder.UseSetting("DevAuth:Enabled", "true");
        builder.UseSetting("DevAuth:Username", "tester");
        builder.UseSetting("DevAuth:Password", "test-password");

        builder.ConfigureServices(services =>
        {
            services.RemoveAll<DbContextOptions<AppDbContext>>();
            services.RemoveAll<AppDbContext>();
            services.AddDbContext<AppDbContext>(o => o.UseInMemoryDatabase(_dbName));
            services.AddScoped<IAppDbContext>(sp => sp.GetRequiredService<AppDbContext>());
        });
    }

    /// <summary>
    /// განაცხადები არსებულ კონკურსზე — თითო მოცემული პასუხით. გვერდებისა და ძებნის
    /// ტესტებს რეალური მონაცემები სჭირდებათ, საჯარო ფორმის გავლა კი CAPTCHA-სა და
    /// ფაილების მთელ ჯაჭვს ჩართავდა.
    /// </summary>
    public async Task SeedSubmissionsAsync(Guid formId, params string[] answers)
    {
        using var scope = Services.CreateScope();
        var db = scope.ServiceProvider.GetRequiredService<AppDbContext>();

        var fieldId = await db.FormFields.Where(f => f.FormId == formId).Select(f => f.Id).FirstAsync();
        var now = DateTimeOffset.UtcNow;

        for (var i = 0; i < answers.Length; i++)
        {
            var submission = new Submission
            {
                FormId = formId,
                Status = SubmissionStatus.Completed,
                ConsentDataProcessing = true,
                // განსხვავებული დრო — გვერდებს შორის რიგითობა ცალსახა უნდა იყოს
                SubmittedAt = now.AddMinutes(-i)
            };
            submission.Values.Add(new SubmissionValue
            {
                SubmissionId = submission.Id,
                FieldId = fieldId,
                Value = answers[i]
            });
            db.Submissions.Add(submission);
        }

        await db.SaveChangesAsync();
    }

    /// <summary>
    /// სხვისი კონკურსი — შესული მომხმარებელი მასზე წვდომის სიაში არ არის.
    /// სწორედ ამ id-ებით მოწმდება, რომ არცერთ endpoint-ს არ დავიწყებია
    /// object-level შემოწმება (IDOR).
    /// </summary>
    public async Task<ForeignForm> SeedForeignFormAsync()
    {
        using var scope = Services.CreateScope();
        var db = scope.ServiceProvider.GetRequiredService<AppDbContext>();

        var form = new Form { Title = "სხვისი კონკურსი", Status = FormStatus.Live, RetentionDays = 30 };
        form.AccessList.Add(new FormAccess
        {
            FormId = form.Id,
            AdAccount = "someone-else",
            AccessLevel = AccessLevel.Manager
        });

        var submission = new Submission
        {
            FormId = form.Id,
            Status = SubmissionStatus.Completed,
            ConsentDataProcessing = true
        };
        var file = new SubmissionFile
        {
            SubmissionId = submission.Id,
            FieldId = Guid.NewGuid(),
            OriginalFileName = "secret.pdf",
            StoredPath = "/files/secret.pdf",
            ContentType = "application/pdf",
            ScanStatus = ScanStatus.Clean
        };
        submission.Files.Add(file);

        var juror = new Juror
        {
            FormId = form.Id,
            Email = "foreign@example.com",
            DisplayName = "სხვისი ჟიური",
            AccessToken = Guid.NewGuid().ToString("N") + Guid.NewGuid().ToString("N"),
            Status = JurorStatus.PendingApproval
        };

        db.Forms.Add(form);
        db.Submissions.Add(submission);
        db.Jurors.Add(juror);
        await db.SaveChangesAsync();

        var access = form.AccessList.First().Id;
        return new ForeignForm(form.Id, submission.Id, file.Id, juror.Id, access);
    }
}

/// <summary>სხვისი კონკურსის id-ები — IDOR-ის შესამოწმებლად.</summary>
public record ForeignForm(Guid FormId, Guid SubmissionId, Guid FileId, Guid JurorId, Guid AccessId);
