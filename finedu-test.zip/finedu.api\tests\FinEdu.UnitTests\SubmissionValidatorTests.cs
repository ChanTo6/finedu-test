﻿using FinEdu.Application.Common.Exceptions;
using FinEdu.Application.Common.Models;
using FinEdu.Application.Submissions.Validators;
using FinEdu.Domain.Entities;
using FinEdu.Domain.Enums;
using Xunit;

namespace FinEdu.UnitTests;

public class SubmissionValidatorTests
{
    private readonly SubmissionValidator _validator = new();
    private static readonly SubmissionFileInput[] NoFiles = [];

    private static Form FormWith(params FormField[] fields) => new() { Title = "T", Fields = fields };

    [Fact]
    public void Missing_required_field_throws()
    {
        var field = new FormField { Id = Guid.NewGuid(), Type = FieldType.ShortAnswer, Label = "სახელი", IsRequired = true };
        var request = new CreateSubmissionRequest([], ConsentDataProcessing: true, null);

        Assert.Throws<ValidationException>(() => _validator.Validate(FormWith(field), request, NoFiles));
    }

    // ── უცხო ველი ────────────────────────────────────────────────────
    //
    // ვალიდაცია ფორმის ველებზე გადის, ამიტომ უცხო FieldId-ით გამოგზავნილი ფაილი
    // ვერცერთ შემოწმებას ვერ ხვდებოდა (ტიპი, ზომა, ხელმოწერა) და მაინც ინახებოდა.
    // სხვა ფორმის ნამდვილი ველის id საჯარო ფორმის JSON-ში ისედაც ჩანს.

    [Fact]
    public void Value_for_a_field_of_another_form_is_rejected()
    {
        var mine = new FormField { Id = Guid.NewGuid(), Type = FieldType.ShortAnswer, Label = "სახელი" };
        var foreign = Guid.NewGuid();

        var request = new CreateSubmissionRequest(
            [new SubmissionValueInput(foreign, "უცხო")], ConsentDataProcessing: true, null);

        Assert.Throws<ValidationException>(() => _validator.Validate(FormWith(mine), request, NoFiles));
    }

    [Fact]
    public void File_for_an_unknown_field_is_rejected()
    {
        var mine = new FormField { Id = Guid.NewGuid(), Type = FieldType.ShortAnswer, Label = "სახელი" };
        var request = new CreateSubmissionRequest([], ConsentDataProcessing: true, null);

        // .exe — სწორედ ის, რასაც დასაშვებთა სია არ უშვებს
        SubmissionFileInput[] files =
        [
            new()
            {
                FieldId = Guid.NewGuid(),
                FileName = "payload.exe",
                Content = new MemoryStream([0x4D, 0x5A]),
                SizeBytes = 2,
                ContentType = "application/octet-stream"
            }
        ];

        Assert.Throws<ValidationException>(() => _validator.Validate(FormWith(mine), request, files));
    }

    /// <summary>
    /// ველი არსებობს, მაგრამ ტექსტურია. ეს ცალკე ხვრელი იყო: „უცნობი ველის" შემოწმებას
    /// ასეთი id გაივლიდა, ფაილის შემოწმებამდე კი საქმე არ მიდიოდა — ციკლი ფაილს მხოლოდ
    /// FileUpload ტიპის ველზე ამოწმებს. შედეგად .exe სკანერამდე და დისკამდე აღწევდა.
    /// </summary>
    [Fact]
    public void File_attached_to_a_text_field_is_rejected()
    {
        var text = new FormField { Id = Guid.NewGuid(), Type = FieldType.ShortAnswer, Label = "სახელი" };
        var request = new CreateSubmissionRequest([], ConsentDataProcessing: true, null);

        SubmissionFileInput[] files =
        [
            new()
            {
                FieldId = text.Id,
                FileName = "payload.exe",
                Content = new MemoryStream([0x4D, 0x5A]),
                SizeBytes = 2,
                ContentType = "application/octet-stream"
            }
        ];

        Assert.Throws<ValidationException>(() => _validator.Validate(FormWith(text), request, files));
    }

    /// <summary>ფაილის ველზე მიბმული დასაშვები ფაილი უნდა გავიდეს — ბარიერი ზედმეტად მკაცრი არ არის.</summary>
    [Fact]
    public void File_on_its_own_upload_field_passes()
    {
        var upload = new FormField { Id = Guid.NewGuid(), Type = FieldType.FileUpload, Label = "CV" };
        var request = new CreateSubmissionRequest([], ConsentDataProcessing: true, null);

        SubmissionFileInput[] files =
        [
            new()
            {
                FieldId = upload.Id,
                FileName = "cv.pdf",
                Content = new MemoryStream("%PDF-1.7"u8.ToArray()),
                SizeBytes = 9,
                ContentType = "application/pdf"
            }
        ];

        Assert.Null(Record.Exception(() => _validator.Validate(FormWith(upload), request, files)));
    }

    /// <summary>სიტყვების ლიმიტს ერთი უზარმაზარი „სიტყვა" არ არღვევს — ზღვარი სიმბოლოებზეც სჭირდება.</summary>
    [Fact]
    public void Single_enormous_word_is_rejected()
    {
        var id = Guid.NewGuid();
        var field = new FormField { Id = id, Type = FieldType.LongAnswer, Label = "ესე" };
        var request = new CreateSubmissionRequest(
            [new SubmissionValueInput(id, new string('a', 200_000))], ConsentDataProcessing: true, null);

        Assert.Throws<ValidationException>(() => _validator.Validate(FormWith(field), request, NoFiles));
    }

    [Fact]
    public void Missing_data_processing_consent_throws()
    {
        var request = new CreateSubmissionRequest([], ConsentDataProcessing: false, null);

        Assert.Throws<ValidationException>(() => _validator.Validate(FormWith(), request, NoFiles));
    }

    [Fact]
    public void Valid_short_answer_passes()
    {
        var id = Guid.NewGuid();
        var field = new FormField { Id = id, Type = FieldType.ShortAnswer, Label = "სახელი", IsRequired = true };
        var request = new CreateSubmissionRequest(
            [new SubmissionValueInput(id, "ნიკა")], ConsentDataProcessing: true, null);

        var ex = Record.Exception(() => _validator.Validate(FormWith(field), request, NoFiles));
        Assert.Null(ex);
    }

    [Theory]
    [InlineData("არა-ელფოსტა")]
    [InlineData("ორი@მისამართი@example.com")]
    [InlineData("@example.com")]
    [InlineData("user@")]
    // ახალი ხაზი header injection-ის კლასიკური მცდელობაა
    [InlineData("user@example.com\nBcc: victim@example.com")]
    [InlineData("user@example.com\r\nSubject: spam")]
    public void Invalid_notification_email_throws(string email)
    {
        var request = new CreateSubmissionRequest([], ConsentDataProcessing: true, email);

        Assert.Throws<ValidationException>(() => _validator.Validate(FormWith(), request, NoFiles));
    }

    [Fact]
    public void Too_long_notification_email_throws()
    {
        var email = new string('a', 320) + "@example.com";   // ბაზის სვეტი 320-ია
        var request = new CreateSubmissionRequest([], ConsentDataProcessing: true, email);

        Assert.Throws<ValidationException>(() => _validator.Validate(FormWith(), request, NoFiles));
    }

    [Theory]
    [InlineData("nika@example.com")]
    [InlineData("nika.chanturia@finedu.gov.ge")]
    [InlineData(null)]        // არასავალდებულოა
    [InlineData("")]
    public void Valid_notification_email_passes(string? email)
    {
        var request = new CreateSubmissionRequest([], ConsentDataProcessing: true, email);

        var ex = Record.Exception(() => _validator.Validate(FormWith(), request, NoFiles));
        Assert.Null(ex);
    }
}
