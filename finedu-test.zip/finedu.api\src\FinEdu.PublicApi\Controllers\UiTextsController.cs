using FinEdu.PublicApi.Common;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Net.Http.Headers;

namespace FinEdu.PublicApi.Controllers;

[ApiController]
[Route("api/ui-texts")]
public class UiTextsController(UiTextCatalog catalog) : ControllerBase
{
    /// <summary>
    /// საჯარო საიტის წარწერები ერთ ენაზე (ka ან en).
    ///
    /// <para>rate limit განზრახ არ ადევს, ისევე როგორც JS-ფაილებს: პასუხი მეხსიერებიდან
    /// გაიცემა და ყოველ გვერდის გახსნაზე ერთხელ მოითხოვება. ლიმიტში რომ ჩათვლილიყო, ერთი
    /// ქსელიდან შემოსული სკოლის კლასი კატალოგის ლიმიტს ორჯერ უფრო სწრაფად ამოწურავდა.</para>
    /// </summary>
    [HttpGet("{lang}")]
    public IActionResult Get(string lang)
    {
        var entry = catalog.Find(lang);
        if (entry is null) return NotFound();

        var etag = new EntityTagHeaderValue(entry.ETag);
        var headers = Response.GetTypedHeaders();
        headers.ETag = etag;
        // ყოველ ჯერზე გადამოწმება (უცვლელზე 304): deploy-ის შემდეგ ახალი ტექსტი მაშინვე ჩანს
        headers.CacheControl = new CacheControlHeaderValue { NoCache = true };

        var ifNoneMatch = Request.GetTypedHeaders().IfNoneMatch;
        if (ifNoneMatch.Any(t => t.Compare(etag, useStrongComparison: false)))
            return StatusCode(StatusCodes.Status304NotModified);

        return Content(entry.Json, "application/json; charset=utf-8");
    }
}
