using FinEdu.Application.Common.Audit;
using FinEdu.Application.Common.Exceptions;
using FinEdu.Application.Common.Models;
using FinEdu.Application.Common.Security;
using FinEdu.Application.Forms;
using FinEdu.Domain.Entities;
using FinEdu.Domain.Enums;
using FinEdu.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;
using Xunit;

namespace FinEdu.UnitTests;

/// <summary>
/// კონკურსზე წვდომის მინიჭება — ეს ის რგოლია, რომელიც მოდერატორს სხვისი კონკურსის
/// მართვის საშუალებას აძლევს. აქვე მოწმდება, რომ ეს რგოლი უფლებებს *არ* ზრდის:
/// მოდერატორი დამატებული წვდომითაც ვერ ხდება ადმინისტრატორი.
/// </summary>
public class FormAccessTests : IDisposable
{
    private readonly AppDbContext _db;
    private readonly RecordingAudit _audit = new();
    private readonly Guid _formId;

    public FormAccessTests()
    {
        var options = new DbContextOptionsBuilder<AppDbContext>()
            .UseInMemoryDatabase($"access-{Guid.NewGuid()}")
            .Options;
        _db = new AppDbContext(options);

        // ნინომ შექმნა კონკურსი — შემქმნელი ავტომატურად მმართველია
        var form = new Form { Title = "ნინოს კონკურსი", CreatedBy = "nino" };
        form.AccessList.Add(new FormAccess { AdAccount = "nino", AccessLevel = AccessLevel.Manager });
        _db.Forms.Add(form);
        _db.SaveChanges();
        _formId = form.Id;
    }

    public void Dispose() => _db.Dispose();

    // ── მინიჭება ────────────────────────────────────────────────────

    /// <summary>ეს არის მთავარი სცენარი: სხვისი კონკურსი გიორგისთვის მისაწვდომი ხდება.</summary>
    [Fact]
    public async Task Manager_can_hand_the_contest_to_another_moderator()
    {
        await AccessFor("nino").GrantAsync(_formId, Grant("giorgi", AccessLevel.Manager));

        // მანამდე გიორგისთვის ეს კონკურსი საერთოდ არ არსებობდა
        var guard = GuardFor("giorgi");
        Assert.Null(await Record.ExceptionAsync(() => guard.EnsureCanManageAsync(_formId)));
        Assert.Single(guard.Accessible(_db.Forms));

        Assert.Equal(1, _audit.Count(AuditActions.FormAccessGranted));
    }

    /// <summary>დამკვირვებელს ნახვა შეუძლია, შეცვლა — არა. ორი დონე რეალურად განსხვავდება.</summary>
    [Fact]
    public async Task Viewer_gets_read_access_only()
    {
        await AccessFor("nino").GrantAsync(_formId, Grant("giorgi", AccessLevel.Viewer));

        var guard = GuardFor("giorgi");
        Assert.Null(await Record.ExceptionAsync(() => guard.EnsureCanAccessAsync(_formId)));
        await Assert.ThrowsAsync<ForbiddenException>(() => guard.EnsureCanManageAsync(_formId));
    }

    /// <summary>ხელახალი მინიჭება დონეს ცვლის და მეორე ჩანაწერს არ ქმნის.</summary>
    [Fact]
    public async Task Granting_again_changes_the_level_in_place()
    {
        var service = AccessFor("nino");
        await service.GrantAsync(_formId, Grant("giorgi", AccessLevel.Viewer));
        await service.GrantAsync(_formId, Grant("giorgi", AccessLevel.Manager));

        var rows = await _db.FormAccessList.Where(a => a.AdAccount == "giorgi").ToListAsync();

        Assert.Single(rows);
        Assert.Equal(AccessLevel.Manager, rows[0].AccessLevel);
    }

    [Fact]
    public async Task Viewer_cannot_hand_out_access()
    {
        await AccessFor("nino").GrantAsync(_formId, Grant("giorgi", AccessLevel.Viewer));

        await Assert.ThrowsAsync<ForbiddenException>(
            () => AccessFor("giorgi").GrantAsync(_formId, Grant("dato", AccessLevel.Manager)));
    }

    [Fact]
    public async Task Stranger_cannot_hand_out_access()
    {
        await Assert.ThrowsAsync<ForbiddenException>(
            () => AccessFor("dato").GrantAsync(_formId, Grant("dato", AccessLevel.Manager)));
    }

    /// <summary>ადმინისტრატორისთვის guard არაფერს ამოწმებს — ფორმის არსებობა ცხადად უნდა შემოწმდეს.</summary>
    [Fact]
    public async Task Granting_on_a_missing_contest_is_not_found()
    {
        await Assert.ThrowsAsync<NotFoundException>(
            () => AccessFor("admin", isAdmin: true).GrantAsync(Guid.NewGuid(), Grant("giorgi", AccessLevel.Viewer)));
    }

    // ── მოხსნა ──────────────────────────────────────────────────────

    [Fact]
    public async Task Revoking_removes_the_access()
    {
        await AccessFor("nino").GrantAsync(_formId, Grant("giorgi", AccessLevel.Manager));
        var id = (await _db.FormAccessList.FirstAsync(a => a.AdAccount == "giorgi")).Id;

        await AccessFor("nino").RevokeAsync(_formId, id);

        await Assert.ThrowsAsync<ForbiddenException>(() => GuardFor("giorgi").EnsureCanAccessAsync(_formId));
        Assert.Equal(1, _audit.Count(AuditActions.FormAccessRevoked));
    }

    /// <summary>საკუთარი წვდომის მოხსნა კონკურსზე დაბრუნებას შეუძლებელს გახდიდა.</summary>
    [Fact]
    public async Task Cannot_lock_yourself_out()
    {
        var id = (await _db.FormAccessList.FirstAsync(a => a.AdAccount == "nino")).Id;

        await Assert.ThrowsAsync<DomainException>(() => AccessFor("nino").RevokeAsync(_formId, id));
    }

    /// <summary>სხვისი კონკურსის ჩანაწერის id-ის მითითება წვდომის შემოწმებას გვერდს ვერ აუვლის.</summary>
    [Fact]
    public async Task Revoking_a_row_from_another_contest_is_not_found()
    {
        var other = new Form { Title = "სხვა კონკურსი", CreatedBy = "dato" };
        other.AccessList.Add(new FormAccess { AdAccount = "dato", AccessLevel = AccessLevel.Manager });
        _db.Forms.Add(other);
        await _db.SaveChangesAsync();

        var foreignId = (await _db.FormAccessList.FirstAsync(a => a.AdAccount == "dato")).Id;

        await Assert.ThrowsAsync<NotFoundException>(() => AccessFor("nino").RevokeAsync(_formId, foreignId));
    }

    // ── დამხმარეები ─────────────────────────────────────────────────

    private static GrantFormAccessRequest Grant(string account, AccessLevel level) => new(account, level);

    private FormAccessService AccessFor(string account, bool isAdmin = false)
    {
        var user = new TestUser(account, isAdmin);
        return new FormAccessService(_db, new FormAccessGuard(_db, user), user, _audit);
    }

    private FormAccessGuard GuardFor(string account, bool isAdmin = false) =>
        new(_db, new TestUser(account, isAdmin));
}
