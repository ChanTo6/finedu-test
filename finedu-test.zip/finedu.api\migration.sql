﻿IF OBJECT_ID(N'[__EFMigrationsHistory]') IS NULL
BEGIN
    CREATE TABLE [__EFMigrationsHistory] (
        [MigrationId] nvarchar(150) NOT NULL,
        [ProductVersion] nvarchar(32) NOT NULL,
        CONSTRAINT [PK___EFMigrationsHistory] PRIMARY KEY ([MigrationId])
    );
END;
GO

BEGIN TRANSACTION;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260729111924_Initial'
)
BEGIN
    CREATE TABLE [AuditLogs] (
        [Id] uniqueidentifier NOT NULL,
        [Actor] nvarchar(max) NOT NULL,
        [Action] nvarchar(max) NOT NULL,
        [EntityType] nvarchar(max) NULL,
        [EntityId] nvarchar(max) NULL,
        [Details] nvarchar(max) NULL,
        [IpAddress] nvarchar(max) NULL,
        [CreatedAt] datetimeoffset NOT NULL,
        [CreatedBy] nvarchar(max) NULL,
        CONSTRAINT [PK_AuditLogs] PRIMARY KEY ([Id])
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260729111924_Initial'
)
BEGIN
    CREATE TABLE [Forms] (
        [Id] uniqueidentifier NOT NULL,
        [Title] nvarchar(300) NOT NULL,
        [Description] nvarchar(max) NULL,
        [CoverImagePath] nvarchar(max) NULL,
        [CloseDate] datetimeoffset NULL,
        [MaxParticipants] int NULL,
        [RetentionDays] int NOT NULL,
        [RetentionUntil] datetimeoffset NULL,
        [Status] int NOT NULL,
        [TermsFilePath] nvarchar(max) NULL,
        [PrivacyPolicyFilePath] nvarchar(max) NULL,
        [PrivacyNoticeHtml] nvarchar(max) NULL,
        [CollectPhotoVideoConsent] bit NOT NULL,
        [PublicToken] nvarchar(64) NOT NULL,
        [ApprovedBy] nvarchar(max) NULL,
        [ApprovedAt] datetimeoffset NULL,
        [CreatedAt] datetimeoffset NOT NULL,
        [CreatedBy] nvarchar(max) NULL,
        CONSTRAINT [PK_Forms] PRIMARY KEY ([Id])
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260729111924_Initial'
)
BEGIN
    CREATE TABLE [FormAccessList] (
        [Id] uniqueidentifier NOT NULL,
        [FormId] uniqueidentifier NOT NULL,
        [AdAccount] nvarchar(max) NOT NULL,
        [AccessLevel] int NOT NULL,
        [CreatedAt] datetimeoffset NOT NULL,
        [CreatedBy] nvarchar(max) NULL,
        CONSTRAINT [PK_FormAccessList] PRIMARY KEY ([Id]),
        CONSTRAINT [FK_FormAccessList_Forms_FormId] FOREIGN KEY ([FormId]) REFERENCES [Forms] ([Id]) ON DELETE CASCADE
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260729111924_Initial'
)
BEGIN
    CREATE TABLE [FormFields] (
        [Id] uniqueidentifier NOT NULL,
        [FormId] uniqueidentifier NOT NULL,
        [Order] int NOT NULL,
        [Type] int NOT NULL,
        [Label] nvarchar(500) NOT NULL,
        [IsRequired] bit NOT NULL,
        [Config] nvarchar(max) NOT NULL,
        [CreatedAt] datetimeoffset NOT NULL,
        [CreatedBy] nvarchar(max) NULL,
        CONSTRAINT [PK_FormFields] PRIMARY KEY ([Id]),
        CONSTRAINT [FK_FormFields_Forms_FormId] FOREIGN KEY ([FormId]) REFERENCES [Forms] ([Id]) ON DELETE CASCADE
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260729111924_Initial'
)
BEGIN
    CREATE TABLE [Submissions] (
        [Id] uniqueidentifier NOT NULL,
        [FormId] uniqueidentifier NOT NULL,
        [SubmittedAt] datetimeoffset NOT NULL,
        [Status] int NOT NULL,
        [ConsentDataProcessing] bit NOT NULL,
        [ConsentPhotoVideo] bit NULL,
        [IsMinor] bit NOT NULL,
        [LegalRepresentativeJson] nvarchar(max) NULL,
        [NotificationEmail] nvarchar(320) NULL,
        [CreatedAt] datetimeoffset NOT NULL,
        [CreatedBy] nvarchar(max) NULL,
        CONSTRAINT [PK_Submissions] PRIMARY KEY ([Id]),
        CONSTRAINT [FK_Submissions_Forms_FormId] FOREIGN KEY ([FormId]) REFERENCES [Forms] ([Id]) ON DELETE CASCADE
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260729111924_Initial'
)
BEGIN
    CREATE TABLE [SubmissionFiles] (
        [Id] uniqueidentifier NOT NULL,
        [SubmissionId] uniqueidentifier NOT NULL,
        [FieldId] uniqueidentifier NOT NULL,
        [OriginalFileName] nvarchar(500) NOT NULL,
        [StoredPath] nvarchar(1000) NOT NULL,
        [SizeBytes] bigint NOT NULL,
        [ContentType] nvarchar(255) NOT NULL,
        [ScanStatus] int NOT NULL,
        [CreatedAt] datetimeoffset NOT NULL,
        [CreatedBy] nvarchar(max) NULL,
        CONSTRAINT [PK_SubmissionFiles] PRIMARY KEY ([Id]),
        CONSTRAINT [FK_SubmissionFiles_Submissions_SubmissionId] FOREIGN KEY ([SubmissionId]) REFERENCES [Submissions] ([Id]) ON DELETE CASCADE
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260729111924_Initial'
)
BEGIN
    CREATE TABLE [SubmissionValues] (
        [Id] uniqueidentifier NOT NULL,
        [SubmissionId] uniqueidentifier NOT NULL,
        [FieldId] uniqueidentifier NOT NULL,
        [Value] nvarchar(max) NULL,
        [CreatedAt] datetimeoffset NOT NULL,
        [CreatedBy] nvarchar(max) NULL,
        CONSTRAINT [PK_SubmissionValues] PRIMARY KEY ([Id]),
        CONSTRAINT [FK_SubmissionValues_FormFields_FieldId] FOREIGN KEY ([FieldId]) REFERENCES [FormFields] ([Id]) ON DELETE NO ACTION,
        CONSTRAINT [FK_SubmissionValues_Submissions_SubmissionId] FOREIGN KEY ([SubmissionId]) REFERENCES [Submissions] ([Id]) ON DELETE CASCADE
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260729111924_Initial'
)
BEGIN
    CREATE INDEX [IX_FormAccessList_FormId] ON [FormAccessList] ([FormId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260729111924_Initial'
)
BEGIN
    CREATE INDEX [IX_FormFields_FormId] ON [FormFields] ([FormId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260729111924_Initial'
)
BEGIN
    CREATE UNIQUE INDEX [IX_Forms_PublicToken] ON [Forms] ([PublicToken]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260729111924_Initial'
)
BEGIN
    CREATE INDEX [IX_Forms_Status] ON [Forms] ([Status]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260729111924_Initial'
)
BEGIN
    CREATE INDEX [IX_SubmissionFiles_SubmissionId] ON [SubmissionFiles] ([SubmissionId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260729111924_Initial'
)
BEGIN
    CREATE INDEX [IX_Submissions_FormId] ON [Submissions] ([FormId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260729111924_Initial'
)
BEGIN
    CREATE INDEX [IX_SubmissionValues_FieldId] ON [SubmissionValues] ([FieldId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260729111924_Initial'
)
BEGIN
    CREATE INDEX [IX_SubmissionValues_SubmissionId] ON [SubmissionValues] ([SubmissionId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260729111924_Initial'
)
BEGIN
    INSERT INTO [__EFMigrationsHistory] ([MigrationId], [ProductVersion])
    VALUES (N'20260729111924_Initial', N'8.0.11');
END;
GO

COMMIT;
GO

BEGIN TRANSACTION;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260807074125_AddGuardianConfirmation'
)
BEGIN
    ALTER TABLE [Submissions] ADD [ConfirmationToken] nvarchar(64) NULL;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260807074125_AddGuardianConfirmation'
)
BEGIN
    ALTER TABLE [Submissions] ADD [ConfirmedAt] datetimeoffset NULL;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260807074125_AddGuardianConfirmation'
)
BEGIN
    ALTER TABLE [Submissions] ADD [RepresentativeEmail] nvarchar(320) NULL;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260807074125_AddGuardianConfirmation'
)
BEGIN
    INSERT INTO [__EFMigrationsHistory] ([MigrationId], [ProductVersion])
    VALUES (N'20260807074125_AddGuardianConfirmation', N'8.0.11');
END;
GO

COMMIT;
GO

BEGIN TRANSACTION;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260812070641_RemoveMinorAndPhotoConsent'
)
BEGIN
    DECLARE @var0 sysname;
    SELECT @var0 = [d].[name]
    FROM [sys].[default_constraints] [d]
    INNER JOIN [sys].[columns] [c] ON [d].[parent_column_id] = [c].[column_id] AND [d].[parent_object_id] = [c].[object_id]
    WHERE ([d].[parent_object_id] = OBJECT_ID(N'[Submissions]') AND [c].[name] = N'ConfirmationToken');
    IF @var0 IS NOT NULL EXEC(N'ALTER TABLE [Submissions] DROP CONSTRAINT [' + @var0 + '];');
    ALTER TABLE [Submissions] DROP COLUMN [ConfirmationToken];
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260812070641_RemoveMinorAndPhotoConsent'
)
BEGIN
    DECLARE @var1 sysname;
    SELECT @var1 = [d].[name]
    FROM [sys].[default_constraints] [d]
    INNER JOIN [sys].[columns] [c] ON [d].[parent_column_id] = [c].[column_id] AND [d].[parent_object_id] = [c].[object_id]
    WHERE ([d].[parent_object_id] = OBJECT_ID(N'[Submissions]') AND [c].[name] = N'ConfirmedAt');
    IF @var1 IS NOT NULL EXEC(N'ALTER TABLE [Submissions] DROP CONSTRAINT [' + @var1 + '];');
    ALTER TABLE [Submissions] DROP COLUMN [ConfirmedAt];
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260812070641_RemoveMinorAndPhotoConsent'
)
BEGIN
    DECLARE @var2 sysname;
    SELECT @var2 = [d].[name]
    FROM [sys].[default_constraints] [d]
    INNER JOIN [sys].[columns] [c] ON [d].[parent_column_id] = [c].[column_id] AND [d].[parent_object_id] = [c].[object_id]
    WHERE ([d].[parent_object_id] = OBJECT_ID(N'[Submissions]') AND [c].[name] = N'ConsentPhotoVideo');
    IF @var2 IS NOT NULL EXEC(N'ALTER TABLE [Submissions] DROP CONSTRAINT [' + @var2 + '];');
    ALTER TABLE [Submissions] DROP COLUMN [ConsentPhotoVideo];
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260812070641_RemoveMinorAndPhotoConsent'
)
BEGIN
    DECLARE @var3 sysname;
    SELECT @var3 = [d].[name]
    FROM [sys].[default_constraints] [d]
    INNER JOIN [sys].[columns] [c] ON [d].[parent_column_id] = [c].[column_id] AND [d].[parent_object_id] = [c].[object_id]
    WHERE ([d].[parent_object_id] = OBJECT_ID(N'[Submissions]') AND [c].[name] = N'IsMinor');
    IF @var3 IS NOT NULL EXEC(N'ALTER TABLE [Submissions] DROP CONSTRAINT [' + @var3 + '];');
    ALTER TABLE [Submissions] DROP COLUMN [IsMinor];
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260812070641_RemoveMinorAndPhotoConsent'
)
BEGIN
    DECLARE @var4 sysname;
    SELECT @var4 = [d].[name]
    FROM [sys].[default_constraints] [d]
    INNER JOIN [sys].[columns] [c] ON [d].[parent_column_id] = [c].[column_id] AND [d].[parent_object_id] = [c].[object_id]
    WHERE ([d].[parent_object_id] = OBJECT_ID(N'[Submissions]') AND [c].[name] = N'LegalRepresentativeJson');
    IF @var4 IS NOT NULL EXEC(N'ALTER TABLE [Submissions] DROP CONSTRAINT [' + @var4 + '];');
    ALTER TABLE [Submissions] DROP COLUMN [LegalRepresentativeJson];
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260812070641_RemoveMinorAndPhotoConsent'
)
BEGIN
    DECLARE @var5 sysname;
    SELECT @var5 = [d].[name]
    FROM [sys].[default_constraints] [d]
    INNER JOIN [sys].[columns] [c] ON [d].[parent_column_id] = [c].[column_id] AND [d].[parent_object_id] = [c].[object_id]
    WHERE ([d].[parent_object_id] = OBJECT_ID(N'[Submissions]') AND [c].[name] = N'RepresentativeEmail');
    IF @var5 IS NOT NULL EXEC(N'ALTER TABLE [Submissions] DROP CONSTRAINT [' + @var5 + '];');
    ALTER TABLE [Submissions] DROP COLUMN [RepresentativeEmail];
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260812070641_RemoveMinorAndPhotoConsent'
)
BEGIN
    DECLARE @var6 sysname;
    SELECT @var6 = [d].[name]
    FROM [sys].[default_constraints] [d]
    INNER JOIN [sys].[columns] [c] ON [d].[parent_column_id] = [c].[column_id] AND [d].[parent_object_id] = [c].[object_id]
    WHERE ([d].[parent_object_id] = OBJECT_ID(N'[Forms]') AND [c].[name] = N'CollectPhotoVideoConsent');
    IF @var6 IS NOT NULL EXEC(N'ALTER TABLE [Forms] DROP CONSTRAINT [' + @var6 + '];');
    ALTER TABLE [Forms] DROP COLUMN [CollectPhotoVideoConsent];
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260812070641_RemoveMinorAndPhotoConsent'
)
BEGIN
    INSERT INTO [__EFMigrationsHistory] ([MigrationId], [ProductVersion])
    VALUES (N'20260812070641_RemoveMinorAndPhotoConsent', N'8.0.11');
END;
GO

COMMIT;
GO

BEGIN TRANSACTION;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260904145900_AddRevokedTokensAndAuditIndexes'
)
BEGIN
    DECLARE @var7 sysname;
    SELECT @var7 = [d].[name]
    FROM [sys].[default_constraints] [d]
    INNER JOIN [sys].[columns] [c] ON [d].[parent_column_id] = [c].[column_id] AND [d].[parent_object_id] = [c].[object_id]
    WHERE ([d].[parent_object_id] = OBJECT_ID(N'[AuditLogs]') AND [c].[name] = N'IpAddress');
    IF @var7 IS NOT NULL EXEC(N'ALTER TABLE [AuditLogs] DROP CONSTRAINT [' + @var7 + '];');
    ALTER TABLE [AuditLogs] ALTER COLUMN [IpAddress] nvarchar(64) NULL;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260904145900_AddRevokedTokensAndAuditIndexes'
)
BEGIN
    DECLARE @var8 sysname;
    SELECT @var8 = [d].[name]
    FROM [sys].[default_constraints] [d]
    INNER JOIN [sys].[columns] [c] ON [d].[parent_column_id] = [c].[column_id] AND [d].[parent_object_id] = [c].[object_id]
    WHERE ([d].[parent_object_id] = OBJECT_ID(N'[AuditLogs]') AND [c].[name] = N'EntityType');
    IF @var8 IS NOT NULL EXEC(N'ALTER TABLE [AuditLogs] DROP CONSTRAINT [' + @var8 + '];');
    ALTER TABLE [AuditLogs] ALTER COLUMN [EntityType] nvarchar(128) NULL;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260904145900_AddRevokedTokensAndAuditIndexes'
)
BEGIN
    DECLARE @var9 sysname;
    SELECT @var9 = [d].[name]
    FROM [sys].[default_constraints] [d]
    INNER JOIN [sys].[columns] [c] ON [d].[parent_column_id] = [c].[column_id] AND [d].[parent_object_id] = [c].[object_id]
    WHERE ([d].[parent_object_id] = OBJECT_ID(N'[AuditLogs]') AND [c].[name] = N'EntityId');
    IF @var9 IS NOT NULL EXEC(N'ALTER TABLE [AuditLogs] DROP CONSTRAINT [' + @var9 + '];');
    ALTER TABLE [AuditLogs] ALTER COLUMN [EntityId] nvarchar(64) NULL;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260904145900_AddRevokedTokensAndAuditIndexes'
)
BEGIN
    DECLARE @var10 sysname;
    SELECT @var10 = [d].[name]
    FROM [sys].[default_constraints] [d]
    INNER JOIN [sys].[columns] [c] ON [d].[parent_column_id] = [c].[column_id] AND [d].[parent_object_id] = [c].[object_id]
    WHERE ([d].[parent_object_id] = OBJECT_ID(N'[AuditLogs]') AND [c].[name] = N'Details');
    IF @var10 IS NOT NULL EXEC(N'ALTER TABLE [AuditLogs] DROP CONSTRAINT [' + @var10 + '];');
    ALTER TABLE [AuditLogs] ALTER COLUMN [Details] nvarchar(2000) NULL;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260904145900_AddRevokedTokensAndAuditIndexes'
)
BEGIN
    DECLARE @var11 sysname;
    SELECT @var11 = [d].[name]
    FROM [sys].[default_constraints] [d]
    INNER JOIN [sys].[columns] [c] ON [d].[parent_column_id] = [c].[column_id] AND [d].[parent_object_id] = [c].[object_id]
    WHERE ([d].[parent_object_id] = OBJECT_ID(N'[AuditLogs]') AND [c].[name] = N'Actor');
    IF @var11 IS NOT NULL EXEC(N'ALTER TABLE [AuditLogs] DROP CONSTRAINT [' + @var11 + '];');
    ALTER TABLE [AuditLogs] ALTER COLUMN [Actor] nvarchar(256) NOT NULL;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260904145900_AddRevokedTokensAndAuditIndexes'
)
BEGIN
    DECLARE @var12 sysname;
    SELECT @var12 = [d].[name]
    FROM [sys].[default_constraints] [d]
    INNER JOIN [sys].[columns] [c] ON [d].[parent_column_id] = [c].[column_id] AND [d].[parent_object_id] = [c].[object_id]
    WHERE ([d].[parent_object_id] = OBJECT_ID(N'[AuditLogs]') AND [c].[name] = N'Action');
    IF @var12 IS NOT NULL EXEC(N'ALTER TABLE [AuditLogs] DROP CONSTRAINT [' + @var12 + '];');
    ALTER TABLE [AuditLogs] ALTER COLUMN [Action] nvarchar(128) NOT NULL;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260904145900_AddRevokedTokensAndAuditIndexes'
)
BEGIN
    CREATE TABLE [RevokedTokens] (
        [Id] uniqueidentifier NOT NULL,
        [Jti] nvarchar(64) NOT NULL,
        [ExpiresAt] datetimeoffset NOT NULL,
        [CreatedAt] datetimeoffset NOT NULL,
        [CreatedBy] nvarchar(max) NULL,
        CONSTRAINT [PK_RevokedTokens] PRIMARY KEY ([Id])
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260904145900_AddRevokedTokensAndAuditIndexes'
)
BEGIN
    CREATE INDEX [IX_AuditLogs_Actor] ON [AuditLogs] ([Actor]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260904145900_AddRevokedTokensAndAuditIndexes'
)
BEGIN
    CREATE INDEX [IX_AuditLogs_CreatedAt] ON [AuditLogs] ([CreatedAt]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260904145900_AddRevokedTokensAndAuditIndexes'
)
BEGIN
    CREATE INDEX [IX_RevokedTokens_ExpiresAt] ON [RevokedTokens] ([ExpiresAt]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260904145900_AddRevokedTokensAndAuditIndexes'
)
BEGIN
    CREATE UNIQUE INDEX [IX_RevokedTokens_Jti] ON [RevokedTokens] ([Jti]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260904145900_AddRevokedTokensAndAuditIndexes'
)
BEGIN
    INSERT INTO [__EFMigrationsHistory] ([MigrationId], [ProductVersion])
    VALUES (N'20260904145900_AddRevokedTokensAndAuditIndexes', N'8.0.11');
END;
GO

COMMIT;
GO

BEGIN TRANSACTION;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260905105848_AddJuryAndEvaluations'
)
BEGIN
    CREATE TABLE [Jurors] (
        [Id] uniqueidentifier NOT NULL,
        [FormId] uniqueidentifier NOT NULL,
        [Email] nvarchar(320) NOT NULL,
        [DisplayName] nvarchar(200) NOT NULL,
        [AccessToken] nvarchar(64) NOT NULL,
        [PinHash] nvarchar(128) NOT NULL,
        [PinSalt] nvarchar(64) NOT NULL,
        [PinExpiresAt] datetimeoffset NOT NULL,
        [PinSentAt] datetimeoffset NOT NULL,
        [FailedAttempts] int NOT NULL,
        [LockedUntil] datetimeoffset NULL,
        [LastLoginAt] datetimeoffset NULL,
        [IsActive] bit NOT NULL,
        [CreatedAt] datetimeoffset NOT NULL,
        [CreatedBy] nvarchar(max) NULL,
        CONSTRAINT [PK_Jurors] PRIMARY KEY ([Id]),
        CONSTRAINT [FK_Jurors_Forms_FormId] FOREIGN KEY ([FormId]) REFERENCES [Forms] ([Id]) ON DELETE CASCADE
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260905105848_AddJuryAndEvaluations'
)
BEGIN
    CREATE TABLE [Evaluations] (
        [Id] uniqueidentifier NOT NULL,
        [JurorId] uniqueidentifier NOT NULL,
        [SubmissionId] uniqueidentifier NOT NULL,
        [Score] int NOT NULL,
        [Comment] nvarchar(2000) NULL,
        [UpdatedAt] datetimeoffset NOT NULL,
        [CreatedAt] datetimeoffset NOT NULL,
        [CreatedBy] nvarchar(max) NULL,
        CONSTRAINT [PK_Evaluations] PRIMARY KEY ([Id]),
        CONSTRAINT [FK_Evaluations_Jurors_JurorId] FOREIGN KEY ([JurorId]) REFERENCES [Jurors] ([Id]) ON DELETE NO ACTION,
        CONSTRAINT [FK_Evaluations_Submissions_SubmissionId] FOREIGN KEY ([SubmissionId]) REFERENCES [Submissions] ([Id]) ON DELETE CASCADE
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260905105848_AddJuryAndEvaluations'
)
BEGIN
    CREATE UNIQUE INDEX [IX_Evaluations_JurorId_SubmissionId] ON [Evaluations] ([JurorId], [SubmissionId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260905105848_AddJuryAndEvaluations'
)
BEGIN
    CREATE INDEX [IX_Evaluations_SubmissionId] ON [Evaluations] ([SubmissionId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260905105848_AddJuryAndEvaluations'
)
BEGIN
    CREATE UNIQUE INDEX [IX_Jurors_AccessToken] ON [Jurors] ([AccessToken]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260905105848_AddJuryAndEvaluations'
)
BEGIN
    CREATE UNIQUE INDEX [IX_Jurors_FormId_Email] ON [Jurors] ([FormId], [Email]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260905105848_AddJuryAndEvaluations'
)
BEGIN
    INSERT INTO [__EFMigrationsHistory] ([MigrationId], [ProductVersion])
    VALUES (N'20260905105848_AddJuryAndEvaluations', N'8.0.11');
END;
GO

COMMIT;
GO

BEGIN TRANSACTION;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260905154518_AuditLogAppendOnly'
)
BEGIN
    IF OBJECT_ID(N'dbo.TR_AuditLogs_AppendOnly', N'TR') IS NOT NULL
        DROP TRIGGER dbo.TR_AuditLogs_AppendOnly;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260905154518_AuditLogAppendOnly'
)
BEGIN
    EXEC(N'
    CREATE TRIGGER dbo.TR_AuditLogs_AppendOnly
    ON dbo.AuditLogs
    INSTEAD OF UPDATE, DELETE
    AS
    BEGIN
        SET NOCOUNT ON;
        THROW 51000, N''AuditLogs is append-only: UPDATE and DELETE are not permitted.'', 1;
    END');
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260905154518_AuditLogAppendOnly'
)
BEGIN
    INSERT INTO [__EFMigrationsHistory] ([MigrationId], [ProductVersion])
    VALUES (N'20260905154518_AuditLogAppendOnly', N'8.0.11');
END;
GO

COMMIT;
GO

BEGIN TRANSACTION;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260905163445_VisitorTraceability'
)
BEGIN
    ALTER TABLE [Submissions] ADD [SubmitterIp] nvarchar(64) NULL;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260905163445_VisitorTraceability'
)
BEGIN
    ALTER TABLE [Submissions] ADD [UserAgent] nvarchar(512) NULL;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260905163445_VisitorTraceability'
)
BEGIN
    ALTER TABLE [Submissions] ADD [VisitorId] nvarchar(64) NULL;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260905163445_VisitorTraceability'
)
BEGIN
    ALTER TABLE [AuditLogs] ADD [UserAgent] nvarchar(512) NULL;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260905163445_VisitorTraceability'
)
BEGIN
    ALTER TABLE [AuditLogs] ADD [VisitorId] nvarchar(64) NULL;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260905163445_VisitorTraceability'
)
BEGIN
    CREATE INDEX [IX_Submissions_FormId_SubmitterIp] ON [Submissions] ([FormId], [SubmitterIp]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260905163445_VisitorTraceability'
)
BEGIN
    CREATE INDEX [IX_Submissions_FormId_VisitorId] ON [Submissions] ([FormId], [VisitorId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260905163445_VisitorTraceability'
)
BEGIN
    CREATE INDEX [IX_AuditLogs_IpAddress] ON [AuditLogs] ([IpAddress]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260905163445_VisitorTraceability'
)
BEGIN
    CREATE INDEX [IX_AuditLogs_VisitorId] ON [AuditLogs] ([VisitorId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260905163445_VisitorTraceability'
)
BEGIN
    INSERT INTO [__EFMigrationsHistory] ([MigrationId], [ProductVersion])
    VALUES (N'20260905163445_VisitorTraceability', N'8.0.11');
END;
GO

COMMIT;
GO

BEGIN TRANSACTION;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260906081006_JuryApprovalWorkflow'
)
BEGIN
    DROP INDEX [IX_FormAccessList_FormId] ON [FormAccessList];
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260906081006_JuryApprovalWorkflow'
)
BEGIN
    DECLARE @var13 sysname;
    SELECT @var13 = [d].[name]
    FROM [sys].[default_constraints] [d]
    INNER JOIN [sys].[columns] [c] ON [d].[parent_column_id] = [c].[column_id] AND [d].[parent_object_id] = [c].[object_id]
    WHERE ([d].[parent_object_id] = OBJECT_ID(N'[Jurors]') AND [c].[name] = N'PinSalt');
    IF @var13 IS NOT NULL EXEC(N'ALTER TABLE [Jurors] DROP CONSTRAINT [' + @var13 + '];');
    ALTER TABLE [Jurors] ALTER COLUMN [PinSalt] nvarchar(64) NULL;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260906081006_JuryApprovalWorkflow'
)
BEGIN
    DECLARE @var14 sysname;
    SELECT @var14 = [d].[name]
    FROM [sys].[default_constraints] [d]
    INNER JOIN [sys].[columns] [c] ON [d].[parent_column_id] = [c].[column_id] AND [d].[parent_object_id] = [c].[object_id]
    WHERE ([d].[parent_object_id] = OBJECT_ID(N'[Jurors]') AND [c].[name] = N'PinHash');
    IF @var14 IS NOT NULL EXEC(N'ALTER TABLE [Jurors] DROP CONSTRAINT [' + @var14 + '];');
    ALTER TABLE [Jurors] ALTER COLUMN [PinHash] nvarchar(128) NULL;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260906081006_JuryApprovalWorkflow'
)
BEGIN
    DECLARE @var15 sysname;
    SELECT @var15 = [d].[name]
    FROM [sys].[default_constraints] [d]
    INNER JOIN [sys].[columns] [c] ON [d].[parent_column_id] = [c].[column_id] AND [d].[parent_object_id] = [c].[object_id]
    WHERE ([d].[parent_object_id] = OBJECT_ID(N'[Jurors]') AND [c].[name] = N'PinExpiresAt');
    IF @var15 IS NOT NULL EXEC(N'ALTER TABLE [Jurors] DROP CONSTRAINT [' + @var15 + '];');
    ALTER TABLE [Jurors] ALTER COLUMN [PinExpiresAt] datetimeoffset NULL;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260906081006_JuryApprovalWorkflow'
)
BEGIN
    ALTER TABLE [Jurors] ADD [ApprovedAt] datetimeoffset NULL;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260906081006_JuryApprovalWorkflow'
)
BEGIN
    ALTER TABLE [Jurors] ADD [ApprovedBy] nvarchar(256) NULL;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260906081006_JuryApprovalWorkflow'
)
BEGIN
    ALTER TABLE [Jurors] ADD [Status] int NOT NULL DEFAULT 1;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260906081006_JuryApprovalWorkflow'
)
BEGIN
    UPDATE dbo.Jurors SET Status = 2;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260906081006_JuryApprovalWorkflow'
)
BEGIN
    DECLARE @var16 sysname;
    SELECT @var16 = [d].[name]
    FROM [sys].[default_constraints] [d]
    INNER JOIN [sys].[columns] [c] ON [d].[parent_column_id] = [c].[column_id] AND [d].[parent_object_id] = [c].[object_id]
    WHERE ([d].[parent_object_id] = OBJECT_ID(N'[FormAccessList]') AND [c].[name] = N'AdAccount');
    IF @var16 IS NOT NULL EXEC(N'ALTER TABLE [FormAccessList] DROP CONSTRAINT [' + @var16 + '];');
    ALTER TABLE [FormAccessList] ALTER COLUMN [AdAccount] nvarchar(256) NOT NULL;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260906081006_JuryApprovalWorkflow'
)
BEGIN
    CREATE INDEX [IX_Jurors_FormId_Status] ON [Jurors] ([FormId], [Status]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260906081006_JuryApprovalWorkflow'
)
BEGIN
    CREATE UNIQUE INDEX [IX_FormAccessList_FormId_AdAccount] ON [FormAccessList] ([FormId], [AdAccount]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260906081006_JuryApprovalWorkflow'
)
BEGIN
    INSERT INTO [__EFMigrationsHistory] ([MigrationId], [ProductVersion])
    VALUES (N'20260906081006_JuryApprovalWorkflow', N'8.0.11');
END;
GO

COMMIT;
GO

BEGIN TRANSACTION;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260906140231_FormConcurrencyToken'
)
BEGIN
    ALTER TABLE [Forms] ADD [RowVersion] rowversion NULL;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260906140231_FormConcurrencyToken'
)
BEGIN
    INSERT INTO [__EFMigrationsHistory] ([MigrationId], [ProductVersion])
    VALUES (N'20260906140231_FormConcurrencyToken', N'8.0.11');
END;
GO

COMMIT;
GO

BEGIN TRANSACTION;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260908095732_FormRichTextAndConfirmationEmail'
)
BEGIN
    ALTER TABLE [Forms] ADD [ConfirmationEmailBody] nvarchar(max) NULL;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260908095732_FormRichTextAndConfirmationEmail'
)
BEGIN
    ALTER TABLE [Forms] ADD [ConfirmationEmailSubject] nvarchar(300) NULL;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260908095732_FormRichTextAndConfirmationEmail'
)
BEGIN
    INSERT INTO [__EFMigrationsHistory] ([MigrationId], [ProductVersion])
    VALUES (N'20260908095732_FormRichTextAndConfirmationEmail', N'8.0.11');
END;
GO

COMMIT;
GO

BEGIN TRANSACTION;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260910195434_SubmissionEmailIndex'
)
BEGIN
    CREATE INDEX [IX_Submissions_FormId_NotificationEmail] ON [Submissions] ([FormId], [NotificationEmail]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260910195434_SubmissionEmailIndex'
)
BEGIN
    INSERT INTO [__EFMigrationsHistory] ([MigrationId], [ProductVersion])
    VALUES (N'20260910195434_SubmissionEmailIndex', N'8.0.11');
END;
GO

COMMIT;
GO

BEGIN TRANSACTION;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260910202328_RemoveUnusedPolicyFilePaths'
)
BEGIN
    DECLARE @var17 sysname;
    SELECT @var17 = [d].[name]
    FROM [sys].[default_constraints] [d]
    INNER JOIN [sys].[columns] [c] ON [d].[parent_column_id] = [c].[column_id] AND [d].[parent_object_id] = [c].[object_id]
    WHERE ([d].[parent_object_id] = OBJECT_ID(N'[Forms]') AND [c].[name] = N'PrivacyPolicyFilePath');
    IF @var17 IS NOT NULL EXEC(N'ALTER TABLE [Forms] DROP CONSTRAINT [' + @var17 + '];');
    ALTER TABLE [Forms] DROP COLUMN [PrivacyPolicyFilePath];
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260910202328_RemoveUnusedPolicyFilePaths'
)
BEGIN
    DECLARE @var18 sysname;
    SELECT @var18 = [d].[name]
    FROM [sys].[default_constraints] [d]
    INNER JOIN [sys].[columns] [c] ON [d].[parent_column_id] = [c].[column_id] AND [d].[parent_object_id] = [c].[object_id]
    WHERE ([d].[parent_object_id] = OBJECT_ID(N'[Forms]') AND [c].[name] = N'TermsFilePath');
    IF @var18 IS NOT NULL EXEC(N'ALTER TABLE [Forms] DROP CONSTRAINT [' + @var18 + '];');
    ALTER TABLE [Forms] DROP COLUMN [TermsFilePath];
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260910202328_RemoveUnusedPolicyFilePaths'
)
BEGIN
    INSERT INTO [__EFMigrationsHistory] ([MigrationId], [ProductVersion])
    VALUES (N'20260910202328_RemoveUnusedPolicyFilePaths', N'8.0.11');
END;
GO

COMMIT;
GO

BEGIN TRANSACTION;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260911072009_FormTitleHtml'
)
BEGIN
    ALTER TABLE [Forms] ADD [TitleHtml] nvarchar(max) NULL;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260911072009_FormTitleHtml'
)
BEGIN
    INSERT INTO [__EFMigrationsHistory] ([MigrationId], [ProductVersion])
    VALUES (N'20260911072009_FormTitleHtml', N'8.0.11');
END;
GO

COMMIT;
GO

BEGIN TRANSACTION;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260911073220_FormFieldVisibleToJury'
)
BEGIN
    ALTER TABLE [FormFields] ADD [VisibleToJury] bit NOT NULL DEFAULT CAST(0 AS bit);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260911073220_FormFieldVisibleToJury'
)
BEGIN
    INSERT INTO [__EFMigrationsHistory] ([MigrationId], [ProductVersion])
    VALUES (N'20260911073220_FormFieldVisibleToJury', N'8.0.11');
END;
GO

COMMIT;
GO

BEGIN TRANSACTION;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260914120614_AddHttpRequestLogs'
)
BEGIN
    CREATE TABLE [HttpRequestLogs] (
        [Id] uniqueidentifier NOT NULL,
        [Timestamp] datetimeoffset NOT NULL,
        [Method] nvarchar(10) NOT NULL,
        [Path] nvarchar(2000) NOT NULL,
        [StatusCode] int NOT NULL,
        [ElapsedMs] bigint NOT NULL,
        [IpAddress] nvarchar(64) NULL,
        [VisitorId] nvarchar(64) NULL,
        [UserAgent] nvarchar(512) NULL,
        [Exception] nvarchar(4000) NULL,
        CONSTRAINT [PK_HttpRequestLogs] PRIMARY KEY ([Id])
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260914120614_AddHttpRequestLogs'
)
BEGIN
    CREATE INDEX [IX_HttpRequestLogs_IpAddress] ON [HttpRequestLogs] ([IpAddress]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260914120614_AddHttpRequestLogs'
)
BEGIN
    CREATE INDEX [IX_HttpRequestLogs_StatusCode] ON [HttpRequestLogs] ([StatusCode]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260914120614_AddHttpRequestLogs'
)
BEGIN
    CREATE INDEX [IX_HttpRequestLogs_Timestamp] ON [HttpRequestLogs] ([Timestamp]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260914120614_AddHttpRequestLogs'
)
BEGIN
    INSERT INTO [__EFMigrationsHistory] ([MigrationId], [ProductVersion])
    VALUES (N'20260914120614_AddHttpRequestLogs', N'8.0.11');
END;
GO

COMMIT;
GO

