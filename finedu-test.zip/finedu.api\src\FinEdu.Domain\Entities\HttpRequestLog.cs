namespace FinEdu.Domain.Entities;

public class HttpRequestLog
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public DateTimeOffset Timestamp { get; set; } = DateTimeOffset.UtcNow;
    public string Method { get; set; } = string.Empty;
    public string Path { get; set; } = string.Empty;
    public int StatusCode { get; set; }
    public long ElapsedMs { get; set; }
    public string? IpAddress { get; set; }
    public string? VisitorId { get; set; }
    public string? UserAgent { get; set; }
    public string? Exception { get; set; }
}
