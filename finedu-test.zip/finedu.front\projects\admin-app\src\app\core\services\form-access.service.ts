import { HttpClient } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';
import { FormAccess, GrantFormAccessRequest } from '../models/form-access';

/**
 * კონკურსზე წვდომის მართვა. ეს **მომხმარებლების მართვა არ არის**: ანგარიშები AD-შია
 * და აქედან არც იქმნება, არც იშლება — ინახება მხოლოდ კავშირი „ვის რომელ კონკურსზე
 * რა უფლება აქვს".
 */
@Injectable({ providedIn: 'root' })
export class FormAccessService {
  private readonly http = inject(HttpClient);
  private readonly base = environment.apiUrl;

  list(formId: string): Observable<FormAccess[]> {
    return this.http.get<FormAccess[]>(`${this.base}/forms/${formId}/access`);
  }

  /** ახალი წვდომა ან არსებულის დონის შეცვლა — სერვერზე ერთი და იგივე მოქმედებაა. */
  grant(formId: string, request: GrantFormAccessRequest): Observable<void> {
    return this.http.post<void>(`${this.base}/forms/${formId}/access`, request);
  }

  /** მოხსნა ჩანაწერის id-ით: AD-ის სახელი შეიძლება შეიცავდეს `\` ან `@` სიმბოლოს. */
  revoke(formId: string, accessId: string): Observable<void> {
    return this.http.delete<void>(`${this.base}/forms/${formId}/access/${accessId}`);
  }
}
