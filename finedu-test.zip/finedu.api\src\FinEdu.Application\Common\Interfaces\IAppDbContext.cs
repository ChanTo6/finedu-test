using FinEdu.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure;

namespace FinEdu.Application.Common.Interfaces;

/// <summary>
/// DB-ს აბსტრაქცია — services ამას იყენებენ, არა კონკრეტულ AppDbContext-ს.
/// Infrastructure-ში AppDbContext ახორციელებს.
///
/// <para>
/// <b>AuditLogs აქ განზრახ არ არის.</b> აუდიტის ჟურნალი აპლიკაციისთვის
/// „მხოლოდ ჩაწერადია": მისი ერთადერთი გზა <see cref="IAuditLogger"/>-ია.
/// ამიტომ ვერც ერთი სერვისი და ვერც ერთი endpoint ვერ წაიკითხავს ჟურნალს —
/// ეს კომპილატორით არის აღკვეთილი, არა შეთანხმებით. ჟურნალს მხოლოდ ბაზიდან
/// კითხულობს ცალკე, read-only SQL ანგარიში (იხ. DEPLOY.md — აუდიტის ჟურნალი).
/// </para>
/// </summary>
public interface IAppDbContext
{
    DbSet<Form> Forms { get; }
    DbSet<FormField> FormFields { get; }
    DbSet<Submission> Submissions { get; }
    DbSet<SubmissionValue> SubmissionValues { get; }
    DbSet<SubmissionFile> SubmissionFiles { get; }
    DbSet<FormAccess> FormAccessList { get; }
    DbSet<RevokedToken> RevokedTokens { get; }
    DbSet<Juror> Jurors { get; }
    DbSet<Evaluation> Evaluations { get; }

    Task<int> SaveChangesAsync(CancellationToken ct = default);

    /// <summary>ტრანზაქციებისთვის — მონაწილეთა ლიმიტის race-ის ასაცილებლად.</summary>
    DatabaseFacade Database { get; }
}
