﻿using System.Globalization;
using System.Threading.RateLimiting;
using FinEdu.Application;
using FinEdu.Application.Common.Interfaces;
using FinEdu.Infrastructure;
using FinEdu.Infrastructure.Http;
using FinEdu.Infrastructure.Identity;
using FinEdu.PublicApi.Common;
using Microsoft.AspNetCore.Localization;
using Microsoft.AspNetCore.RateLimiting;
using Serilog;

var builder = WebApplication.CreateBuilder(args);

builder.Host.UseSerilog((ctx, cfg) => cfg.ReadFrom.Configuration(ctx.Configuration).WriteTo.Console());

builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

builder.Services.AddApplication();
builder.Services.AddInfrastructure(builder.Configuration);
builder.Services.AddHttpContextAccessor();
builder.Services.AddScoped<ICurrentUser, AnonymousCurrentUser>();
builder.Services.AddSingleton<UiTextCatalog>();

builder.Services.AddFinEduForwardedHeaders(builder.Configuration);
builder.Services.AddFinEduCors(builder.Configuration);
builder.Services.AddFinEduHealthChecks();

// rate limiting საჯარო endpoint-ებზე (built-in, doc §4).
// ლიმიტი ითვლება *თითო IP-ზე* — გლობალური ლიმიტი საშიშია: ერთ მომხმარებელს
// შეეძლებოდა კვოტა ამოეწურა და ფორმა ყველასთვის დაებლოკა.
builder.Services.AddRateLimiter(o =>
{
    o.RejectionStatusCode = StatusCodes.Status429TooManyRequests;

    // განაცხადის გაგზავნა — მკაცრი ლიმიტი
    o.AddPolicy("public", ctx => RateLimitPartition.GetFixedWindowLimiter(
        WebSetup.ClientKey(ctx),
        _ => new FixedWindowRateLimiterOptions
        {
            Window = TimeSpan.FromMinutes(1),
            PermitLimit = 10,
            QueueLimit = 0
        }));

    // კატალოგის/ფორმის დათვალიერება და ქავერები — რბილი ლიმიტი, ნორმალურ ბრაუზინგს რომ არ შეუშალოს
    o.AddPolicy("public-read", ctx => RateLimitPartition.GetFixedWindowLimiter(
        WebSetup.ClientKey(ctx),
        _ => new FixedWindowRateLimiterOptions
        {
            Window = TimeSpan.FromMinutes(1),
            PermitLimit = 120,
            QueueLimit = 0
        }));

});

var app = builder.Build();

// სატესტო კონკურსები — SeedTestData.cs წაშლით ავტომატურად გაითიშება
var seedType = typeof(Program).Assembly.GetType("FinEdu.PublicApi.SeedTestData");
var seedMethod = seedType?.GetMethod("RunAsync", System.Reflection.BindingFlags.Public | System.Reflection.BindingFlags.Static);
if (seedMethod != null) await (Task)seedMethod.Invoke(null, [app.Services])!;

app.UseForwardedHeaders();

// Swagger მხოლოდ Development-ში — საჯარო API-ს სქემას ინტერნეტში არ ვაქვეყნებთ
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}
else
{
    app.UseHsts();
}

app.UseSecurityHeaders();

// ვიზიტორის ანონიმური ნიშანი — request-ლოგამდე, რომ ყოველ ჩანაწერში მოხვდეს
app.UseVisitorCookie();

// შეტყობინებების ენა Accept-Language-იდან: საჯარო საიტი მას ყოველ მოთხოვნაზე ცხადად აგზავნის
// (ka ან en), თორემ ბრაუზერის ენა აირჩევდა. შეცდომების დამმუშავებელზე ზემოთ დგას, რომ
// „სერვერის შეცდომაც" არჩეულ ენაზე დაიწეროს. იცვლება მხოლოდ ტექსტის ენა (UICulture) —
// რიცხვებისა და თარიღების ფორმატი სერვერისავე რჩება.
var serverFormat = CultureInfo.CurrentCulture;
app.UseRequestLocalization(new RequestLocalizationOptions
{
    DefaultRequestCulture = new RequestCulture(serverFormat, CultureInfo.GetCultureInfo("ka")),
    SupportedCultures = [serverFormat],
    SupportedUICultures = [CultureInfo.GetCultureInfo("ka"), CultureInfo.GetCultureInfo("en")],
    RequestCultureProviders = [new AcceptLanguageHeaderRequestCultureProvider()],
});

// ყოველი მოთხოვნა IP-ით, ვიზიტორის ნიშნით და ბრაუზერით. სტანდარტული ჩანაწერი მხოლოდ
// მეთოდს/გზას/სტატუსს იწერს — ამის გარეშე იმ ვიზიტების კვალი დაიკარგებოდა, რომლებიც
// აუდიტში არ ჯდება (კატალოგის დათვალიერება, ფორმის გახსნა).
//
// შეცდომების დამმუშავებელზე *ზემოთ* დგას განზრახ: ქვემოთ რომ იყოს, ლოგში დამუშავებული
// შეცდომა 500-ად ჩაიწერებოდა, კლიენტი კი 409-ს იღებდა — ანუ ჟურნალი ტყუოდა.
app.UseDbRequestLogging();

app.UseFinEduExceptionHandling();
app.UseHttpsRedirection();
app.UseCors();
app.UseRateLimiter();
app.UseDefaultFiles();
app.UseStaticFiles();
app.MapControllers();
app.MapFinEduHealthChecks();
app.MapFallbackToFile("index.html").AllowAnonymous();

app.Run();

// WebApplicationFactory-ს საჯარო Program ტიპი სჭირდება (top-level statements-ით ის internal-ია).
public partial class Program;
