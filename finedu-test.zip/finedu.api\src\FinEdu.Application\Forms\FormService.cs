﻿using FinEdu.Application.Common;
using FinEdu.Application.Common.Audit;
using FinEdu.Application.Common.Exceptions;
using FinEdu.Application.Common.Interfaces;
using FinEdu.Application.Common.Mapping;
using FinEdu.Application.Common.Models;
using FinEdu.Application.Common.Security;
using FinEdu.Domain.Entities;
using FinEdu.Domain.Enums;
using FinEdu.Domain.ValueObjects;   // UploadLimitsDto — საჯარო ფორმას ლიმიტები მიჰყვება
using Microsoft.EntityFrameworkCore;

namespace FinEdu.Application.Forms;

public class FormService(
    IAppDbContext db,
    ICurrentUser currentUser,
    IAuditLogger audit,
    IFileStorage storage,
    IFormAccessGuard accessGuard,
    IHtmlContent html) : IFormService
{
    /// <summary>კატალოგის ბარათზე აღწერა მოკლედ და გაფორმების გარეშე — თორემ განლაგება ირღვევა.</summary>
    private const int CatalogDescriptionLength = 300;

    // სვეტების ზღვრები (იხ. FormConfiguration). ვალიდატორი იმავე რიცხვებს ამოწმებს —
    // აქ გაწმენდა მეორე ბარიერია: საკონტროლო სიმბოლო სათაურში ჟურნალის ერთ ჩანაწერს
    // ორად ჩაწერდა (სწორედ ამისთვის არსებობს SafeText).
    private const int TitleMaxLength = 300;
    private const int LabelMaxLength = 500;

    private readonly FormMapper _mapper = new();

    /// <summary>კონკურენტული რედაქტირების პასუხი — გასაგები და ქმედითი.</summary>
    private const string ConcurrencyMessage =
        "ფორმა ამასობაში სხვამ შეცვალა. გთხოვთ, ხელახლა ჩატვირთოთ გვერდი და ცვლილება თავიდან შეიტანოთ.";

    public async Task<Guid> CreateAsync(CreateFormRequest request, CancellationToken ct = default)
    {
        var form = new Form
        {
            Title = PlainTitle(request.Title),
            TitleHtml = html.Sanitize(request.Title),
            // გაფორმებული ტექსტი ბაზაში მხოლოდ გაწმენდილი ხვდება (იხ. IHtmlContent)
            Description = html.Sanitize(request.Description),
            CloseDate = request.CloseDate,
            MaxParticipants = request.MaxParticipants,
            RetentionDays = request.RetentionDays,
            PrivacyNoticeHtml = html.Sanitize(request.PrivacyNoticeHtml),
            ConfirmationEmailSubject = EmailSubject(request.ConfirmationEmailSubject),
            ConfirmationEmailBody = html.Sanitize(request.ConfirmationEmailBody),
            CoverImagePath = CoverName.Normalized(request.CoverImagePath),
            Status = FormStatus.Draft,
            CreatedBy = currentUser.Account,
            Fields = request.Fields.Select(MapField).ToList()
        };

        // შემქმნელს მაშინვე ეძლევა წვდომა თავის პროექტზე — თორემ საკუთარ ფორმას ვერ ნახავდა.
        if (!string.IsNullOrWhiteSpace(currentUser.Account))
        {
            form.AccessList.Add(new FormAccess
            {
                AdAccount = currentUser.Account!,
                AccessLevel = AccessLevel.Manager,
                CreatedBy = currentUser.Account
            });
        }

        db.Forms.Add(form);
        await db.SaveChangesAsync(ct);
        await audit.LogAsync(AuditActions.FormCreated, nameof(Form), form.Id.ToString(), form.Title, ct);
        return form.Id;
    }

    public async Task UpdateAsync(Guid id, UpdateFormRequest request, CancellationToken ct = default)
    {
        await accessGuard.EnsureCanManageAsync(id, ct);

        var form = await db.Forms.Include(f => f.Fields)
            .FirstOrDefaultAsync(f => f.Id == id, ct)
            ?? throw new NotFoundException(nameof(Form), id);

        if (form.Status is FormStatus.Live or FormStatus.Closed)
            throw new DomainException("გამოქვეყნებული/დახურული ფორმა ვერ რედაქტირდება.");

        form.Title = PlainTitle(request.Title);
        form.TitleHtml = html.Sanitize(request.Title);
        form.Description = html.Sanitize(request.Description);
        form.CloseDate = request.CloseDate;
        form.MaxParticipants = request.MaxParticipants;
        form.RetentionDays = request.RetentionDays;
        form.PrivacyNoticeHtml = html.Sanitize(request.PrivacyNoticeHtml);
        form.ConfirmationEmailSubject = EmailSubject(request.ConfirmationEmailSubject);
        form.ConfirmationEmailBody = html.Sanitize(request.ConfirmationEmailBody);

        // null → ქავერი უცვლელი რჩება; "" → ცხადი წაშლა; სახელი → ჩანაცვლება.
        // ძველი ფაილი *მხოლოდ წარმატებული ჩაწერის შემდეგ* იშლება (იხ. ქვემოთ): აქ წაშლა
        // კონფლიქტის ან ნებისმიერი სხვა ჩავარდნის შემთხვევაში ბაზას არარსებულ ფაილზე
        // დატოვებდა მიმართებით.
        var requestedCover = CoverName.Validated(request.CoverImagePath);
        string? replacedCover = null;

        if (requestedCover is not null)
        {
            var resolved = requestedCover.Length == 0 ? null : requestedCover;
            if (resolved != form.CoverImagePath)
            {
                replacedCover = form.CoverImagePath;
                form.CoverImagePath = resolved;
            }
        }

        // ველების ჩანაცვლება: ძველებს cascade-delete-orphan შლის Clear()-ზე.
        // ახლები ცხადად უნდა დაემატოს DbSet-ში: BaseEntity Id-ს კონსტრუქციისთანავე ავსებს,
        // ხოლო შევსებული Guid-ის მიხედვით EF მათ არსებულად თვლის და INSERT-ის ნაცვლად
        // UPDATE-ს აგენერირებდა — არარსებულ სტრიქონზე, რაც SaveChanges-ს ვარდნით ამთავრებდა.
        form.Fields.Clear();
        foreach (var field in request.Fields.Select(MapField))
        {
            db.FormFields.Add(field);
            form.Fields.Add(field);
        }

        // ფორმა და მისი ველები ერთი მთლიანობაა: თუ მხოლოდ ველები შეიცვალა, EF Forms-ის
        // სტრიქონს საერთოდ არ განაახლებდა — ვერსია არ იზრდებოდა და შემოწმებაც არ ხდებოდა,
        // ანუ ორი პარალელური რედაქტირება ველებს ჩუმად გადააწერდა ერთმანეთს.
        // ცხადი Modified აიძულებს UPDATE-ს, რომელსაც ვერსია WHERE-ში მიჰყვება.
        db.Forms.Entry(form).State = EntityState.Modified;

        ApplyExpectedVersion(form, request.RowVersion);

        try
        {
            await db.SaveChangesAsync(ct);
        }
        catch (DbUpdateConcurrencyException)
        {
            // ორი პარალელური რედაქტირებიდან მეორეს UPDATE ვერცერთ სტრიქონს ვერ იპოვის.
            // ჩუმად გადაწერის ნაცვლად — 409 და გასაგები შეტყობინება.
            throw new DomainException(ConcurrencyMessage);
        }

        // ძველი ქავერი მხოლოდ ახლა: ჩაწერა უკვე გატარდა და ბაზა ახალ სახელზე მიუთითებს
        if (!string.IsNullOrWhiteSpace(replacedCover))
            await storage.DeleteCoverAsync(replacedCover, ct);

        await audit.LogAsync(AuditActions.FormUpdated, nameof(Form), id.ToString(), null, ct);
    }

    /// <summary>
    /// კლიენტმა უნდა დაგვიბრუნოს ის ვერსია, რომელიც ფორმის ჩატვირთვისას მიიღო —
    /// სწორედ ის ხდება UPDATE-ის WHERE-ის ნაწილი.
    ///
    /// <para>თუ ჩანაწერს ვერსია საერთოდ არ აქვს, შემოწმება გამოტოვდება: ეს მხოლოდ იმ
    /// პროვაიდერზეა შესაძლებელი, რომელიც rowversion-ს არ აგენერირებს (ტესტების
    /// in-memory ბაზა). SQL Server-ზე ვერსია ყოველთვის არსებობს, ანუ პროდაქშენში
    /// შემოწმება ყოველთვის ხდება და კლიენტს მისი გამოტოვება არ შეუძლია.</para>
    /// </summary>
    private void ApplyExpectedVersion(Form form, string? expected)
    {
        if (form.RowVersion is null) return;

        if (string.IsNullOrWhiteSpace(expected))
            throw new ValidationException(nameof(UpdateFormRequest.RowVersion),
                "ფორმის ვერსია არ არის მითითებული — გთხოვთ, ხელახლა ჩატვირთოთ გვერდი.");

        byte[] version;
        try
        {
            version = Convert.FromBase64String(expected);
        }
        catch (FormatException)
        {
            throw new ValidationException(nameof(UpdateFormRequest.RowVersion), "ფორმის ვერსია არასწორია.");
        }

        db.Forms.Entry(form).Property(f => f.RowVersion).OriginalValue = version;
    }

    public async Task<FormDto> GetByIdAsync(Guid id, CancellationToken ct = default)
    {
        await accessGuard.EnsureCanAccessAsync(id, ct);

        var form = await db.Forms.Include(f => f.Fields.OrderBy(x => x.Order))
            .AsNoTracking()
            .FirstOrDefaultAsync(f => f.Id == id, ct)
            ?? throw new NotFoundException(nameof(Form), id);

        // ვერსია ხელით — Mapperly byte[]-ს სტრიქონად არ თარგმნის (იხ. FormMapper)
        return _mapper.ToDto(form) with { RowVersion = EncodeVersion(form.RowVersion) };
    }

    /// <summary>rowversion → base64. <c>null</c> რჩება <c>null</c>-ად (იხ. ApplyExpectedVersion).</summary>
    private static string? EncodeVersion(byte[]? rowVersion) =>
        rowVersion is null ? null : Convert.ToBase64String(rowVersion);

    public async Task<IReadOnlyList<FormSummaryDto>> ListAsync(CancellationToken ct = default)
    {
        // per-project ფილტრი: მოდერატორი მხოლოდ თავის პროექტებს ხედავს, ადმინისტრატორი — ყველას.
        return await accessGuard.Accessible(db.Forms.AsNoTracking())
            .OrderByDescending(f => f.CreatedAt)
            .Select(f => new FormSummaryDto(f.Id, f.Title, f.Status, f.CloseDate, f.Submissions.Count))
            .ToListAsync(ct);
    }
    public async Task<IReadOnlyList<PublicFormListItemDto>> ListPublicAsync(CancellationToken ct = default)
    {
        // მხოლოდ ის ფორმები, რომლებიც რეალურად იღებენ განაცხადებს — წესი Form-შია,
        // საერთო submit-თან და ავტო-დახურვასთან (doc §3.4).
        var forms = await db.Forms.AsNoTracking()
            .Where(Form.AcceptingSubmissions(DateTimeOffset.UtcNow))
            .OrderByDescending(f => f.CreatedAt)
            .Select(f => new
            {
                f.Title,
                f.Description,
                HasCover = f.CoverImagePath != null,
                f.CloseDate,
                f.PublicToken
            })
            .ToListAsync(ct);

        // ბარათზე გაფორმება არ გადმოდის: აღწერა გრძელი და გაფორმებულია, ბარათი კი პატარა —
        // HTML-ის ჩასმა სიის განლაგებას დაანგრევდა.
        return forms
            .Select(f => new PublicFormListItemDto(
                f.Title,
                html.ToPlainText(f.Description, CatalogDescriptionLength),
                f.HasCover,
                f.CloseDate,
                f.PublicToken))
            .ToList();
    }

    public async Task<PublicFormDto> GetPublicByTokenAsync(string token, CancellationToken ct = default)
    {
        var form = await db.Forms.Include(f => f.Fields.OrderBy(x => x.Order))
            .AsNoTracking()
            .FirstOrDefaultAsync(f => f.PublicToken == token && f.Status == FormStatus.Live, ct)
            ?? throw new NotFoundException(nameof(Form), token);

        return new PublicFormDto(
            form.Title,
            form.TitleHtml,
            form.Description,
            form.CoverImagePath != null,
            form.PrivacyNoticeHtml,
            form.Fields.Select(_mapper.ToFieldDto).ToList(),
            // ლიმიტები კლიენტს იმისთვის, რომ ატვირთვამდე გააფრთხილოს — შემოწმება სერვერზეც რჩება
            new UploadLimitsDto(FileUploadPolicy.MaxFilesPerSubmission, FileUploadPolicy.MaxBytesByExtension));
    }

    public async Task SubmitForApprovalAsync(Guid id, CancellationToken ct = default)
    {
        await accessGuard.EnsureCanManageAsync(id, ct);

        var form = await Load(id, ct);
        if (form.Status != FormStatus.Draft)
            throw new DomainException("მხოლოდ Draft ფორმა იგზავნება დასამტკიცებლად.");
        form.Status = FormStatus.PendingApproval;
        await db.SaveChangesAsync(ct);
        await audit.LogAsync(AuditActions.FormSubmittedForApproval, nameof(Form), id.ToString(), null, ct);
    }

    public async Task ApproveAsync(Guid id, CancellationToken ct = default)
    {
        // controller-ზე მხოლოდ Administrator-ია დაშვებული და მას ყველა ფორმაზე წვდომა აქვს,
        // მაგრამ შემოწმება აქაც უნდა იდგეს: ავტორიზაცია ერთადერთ ატრიბუტზე რომ არ ეყრდნობოდეს.
        await accessGuard.EnsureCanManageAsync(id, ct);

        var form = await Load(id, ct);
        if (form.Status != FormStatus.PendingApproval)
            throw new DomainException("მხოლოდ PendingApproval ფორმა მტკიცდება.");
        form.Status = FormStatus.Live;
        form.ApprovedBy = currentUser.Account;
        form.ApprovedAt = DateTimeOffset.UtcNow;
        await db.SaveChangesAsync(ct);
        await audit.LogAsync(AuditActions.FormApproved, nameof(Form), id.ToString(), null, ct);
    }

    public async Task CloseAsync(Guid id, CancellationToken ct = default)
    {
        await accessGuard.EnsureCanManageAsync(id, ct);

        var form = await Load(id, ct);
        if (form.Status != FormStatus.Live)
            throw new DomainException("დახურვა შესაძლებელია მხოლოდ გაშვებული (Live) ფორმისთვის.");

        form.Status = FormStatus.Closed;
        form.RetentionUntil ??= DateTimeOffset.UtcNow.AddDays(form.RetentionDays);
        await db.SaveChangesAsync(ct);
        await audit.LogAsync(AuditActions.FormClosed, nameof(Form), id.ToString(), null, ct);
    }

    public async Task<int> AutoCloseDueAsync(CancellationToken ct = default)
    {
        var now = DateTimeOffset.UtcNow;
        var liveForms = await db.Forms.Where(f => f.Status == FormStatus.Live).ToListAsync(ct);
        if (liveForms.Count == 0) return 0;

        // განაცხადების დათვლა ერთი მოთხოვნით ყველა ფორმაზე. ადრე ციკლის შიგნით იყო
        // და თითო ფორმაზე ცალკე COUNT მიდიოდა ბაზაში (N+1) — job-ი ყოველ საათში ეშვება.
        var liveFormIds = liveForms.Select(f => f.Id).ToList();
        var submissionCounts = await db.Submissions
            .Where(s => liveFormIds.Contains(s.FormId) && s.Status != SubmissionStatus.Rejected)
            .GroupBy(s => s.FormId)
            .Select(g => new { FormId = g.Key, Count = g.Count() })
            .ToDictionaryAsync(x => x.FormId, x => x.Count, ct);

        var closed = 0;
        var closedForms = new List<(Guid FormId, string Reason)>();

        foreach (var form in liveForms)
        {
            // იგივე ორი პირობა, რაც კატალოგსა და submit-ში — Form-ის მეთოდებით
            var expired = !form.IsWithinCloseDate(now);
            var overLimit = !form.HasFreeCapacity(submissionCounts.GetValueOrDefault(form.Id));

            if (expired || overLimit)
            {
                form.Status = FormStatus.Closed;
                form.RetentionUntil ??= now.AddDays(form.RetentionDays);
                closed++;
                closedForms.Add((form.Id, expired ? "expired" : "limit"));
            }
        }

        if (closed == 0) return 0;

        await db.SaveChangesAsync(ct);

        // ავტო-დახურვა სისტემის მოქმედებაა, მაგრამ მაინც მოქმედებაა: ჟურნალში უნდა ჩანდეს,
        // რომ ფორმა ვადის/ლიმიტის გამო დაიხურა და არა იმიტომ, რომ ვინმემ ხელით დახურა.
        foreach (var (formId, reason) in closedForms)
            await audit.LogAsync(AuditActions.FormAutoClosed, nameof(Form), formId.ToString(), reason, ct);

        return closed;
    }

    /// <summary>
    /// წერილის სათაური მხოლოდ ტექსტია — SMTP-ის Subject მარკირებას არ ხატავს და
    /// ჩასმული `<b>` მიმღებს პირდაპირ ტეგად გამოუჩნდებოდა.
    /// </summary>
    private const int EmailSubjectLength = 300;

    private string? EmailSubject(string? value) =>
        SafeText.Clean(html.ToPlainText(value, EmailSubjectLength), EmailSubjectLength);

    /// <summary>
    /// სათაურის ტექსტური ვერსია. ორგანიზატორი სათაურს გაფორმებით წერს, მაგრამ წერილის
    /// თემა, Excel-ის ფაილის სახელი და ჟურნალი მარკირებას ვერ ხატავს — იქ ტეგები
    /// პირდაპირ ტექსტად გამოჩნდებოდა.
    ///
    /// <para>ცალკე ველად შევსება განზრახ არ ხდება: ორი ხელით შევსებული სათაური ადრე
    /// თუ გვიან ერთმანეთს აცდებოდა. აქ ორივე ერთი და იმავე ტექსტიდან იწერება.</para>
    /// </summary>
    private string PlainTitle(string title) =>
        SafeText.Clean(html.ToPlainText(title, TitleMaxLength), TitleMaxLength) ?? title.Trim();

    private async Task<Form> Load(Guid id, CancellationToken ct) =>
        await db.Forms.FirstOrDefaultAsync(f => f.Id == id, ct)
        ?? throw new NotFoundException(nameof(Form), id);

    private FormField MapField(CreateFieldRequest r) => new()
    {
        Order = r.Order,
        Type = r.Type,
        Label = SafeText.Clean(r.Label, LabelMaxLength) ?? r.Label.Trim(),
        IsRequired = r.IsRequired,
        VisibleToJury = r.VisibleToJury,
        Config = r.Config,
        CreatedBy = currentUser.Account
    };
}
