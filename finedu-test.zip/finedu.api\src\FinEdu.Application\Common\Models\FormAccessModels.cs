using FinEdu.Domain.Enums;

namespace FinEdu.Application.Common.Models;

/// <summary>
/// კონკურსზე წვდომის ჩანაწერი. აქ *არ* არის მომხმარებლის სახელი, განყოფილება ან სხვა
/// მონაცემი — ისინი AD-შია და მათი გადმოტანა არსებული სისტემის დუბლირება იქნებოდა.
/// ჩვენ მხოლოდ იმას ვინახავთ, რაც AD-ში არ არსებობს: ვის რომელ კონკურსზე რა უფლება აქვს.
/// </summary>
public record FormAccessDto(
    Guid Id,
    string AdAccount,
    AccessLevel AccessLevel,
    DateTimeOffset GrantedAt,
    string? GrantedBy);

/// <summary>წვდომის მინიჭება/დონის შეცვლა. ანგარიში AD-ის სახელია (sAMAccountName ან UPN).</summary>
public record GrantFormAccessRequest(string AdAccount, AccessLevel AccessLevel);
