﻿using System.Net;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.HttpOverrides;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace FinEdu.Infrastructure.Http;

/// <summary>ორივე API-სთვის საერთო web კონფიგურაცია — თითოში ცალკე რომ არ დუბლირდეს.</summary>
public static class WebSetup
{
    /// <summary>
    /// პროქსის უკან რეალური client IP — rate limit და აუდიტის ლოგი პროქსის მისამართს რომ არ ჩაწეროს.
    /// KnownProxies განზრახ არ იწმინდება: სანდო წყაროს გარეშე ნებისმიერ კლიენტს შეეძლებოდა
    /// X-Forwarded-For-ის გაყალბება და rate limit-ის გვერდის ავლა თითო მოთხოვნაზე ახალი „IP"-თ.
    /// </summary>
    public static IServiceCollection AddFinEduForwardedHeaders(
        this IServiceCollection services, IConfiguration config) =>
        services.Configure<ForwardedHeadersOptions>(o =>
        {
            o.ForwardedHeaders = ForwardedHeaders.XForwardedFor | ForwardedHeaders.XForwardedProto;
            foreach (var proxy in config.GetSection("KnownProxies").Get<string[]>() ?? [])
                o.KnownProxies.Add(IPAddress.Parse(proxy));
        });

    /// <summary>CORS — დაშვებული origin-ები კონფიგიდან, wildcard არასდროს.</summary>
    public static IServiceCollection AddFinEduCors(this IServiceCollection services, IConfiguration config)
    {
        var origins = config.GetSection("Cors:Origins").Get<string[]>() ?? [];
        return services.AddCors(o => o.AddDefaultPolicy(p =>
            p.WithOrigins(origins)
                .AllowAnyHeader()
                .AllowAnyMethod()
                // ჩამოტვირთვისას ფაილის სახელი Content-Disposition-შია. სხვა წყაროდან
                // მოსული პასუხის header-ებს ბრაუზერი ნაგულისხმევად მალავს, ამიტომ
                // Excel-ის ბმულით მოსული ფაილი უსახელო რჩებოდა.
                .WithExposedHeaders("Content-Disposition")));
    }

    /// <summary>
    /// rate limit-ის დანაწილების გასაღები. ForwardedHeaders-ის შემდეგ RemoteIpAddress
    /// უკვე რეალურ კლიენტს აჩვენებს, არა პროქსის.
    /// </summary>
    public static string ClientKey(HttpContext ctx) =>
        ctx.Connection.RemoteIpAddress?.ToString() ?? "unknown";
}
