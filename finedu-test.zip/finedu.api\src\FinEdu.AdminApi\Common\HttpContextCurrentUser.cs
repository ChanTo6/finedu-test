using FinEdu.Application.Common.Interfaces;

namespace FinEdu.AdminApi.Common;

/// <summary>მიმდინარე admin მომხმარებელი JWT claim-ებიდან.</summary>
public class HttpContextCurrentUser(IHttpContextAccessor http) : ICurrentUser
{
    public string? Account => http.HttpContext?.User.Identity?.Name;
    public string? IpAddress => http.HttpContext?.Connection.RemoteIpAddress?.ToString();

    /// <summary>ადმინის ზონაში ვიზიტორის cookie არ გამოიყენება — მომხმარებელი AD ანგარიშით იცნობება.</summary>
    public string? VisitorId => null;

    public string? UserAgent => http.HttpContext?.Request.Headers.UserAgent.ToString();

    // როლი ვალიდირებული JWT-ის claim-იდან — არა კლიენტისგან მოსული მონაცემიდან.
    public bool IsAdministrator => http.HttpContext?.User.IsInRole("Administrator") ?? false;
}
