using FinEdu.Domain.Common;
using FinEdu.Domain.Enums;

namespace FinEdu.Domain.Entities;

/// <summary>per-project წვდომა — ვინ ხედავს რომელი ფორმის მონაცემებს (doc — იზოლაცია).</summary>
public class FormAccess : BaseEntity
{
    public Guid FormId { get; set; }
    public Form? Form { get; set; }

    public string AdAccount { get; set; } = string.Empty;   // sAMAccountName / UPN
    public AccessLevel AccessLevel { get; set; } = AccessLevel.Viewer;
}
