namespace FinEdu.Domain.Enums;

/// <summary>ატვირთული ფაილის ClamAV სკანის სტატუსი.</summary>
public enum ScanStatus
{
    Pending = 1,
    Clean = 2,
    Infected = 3,
    Error = 4
}
