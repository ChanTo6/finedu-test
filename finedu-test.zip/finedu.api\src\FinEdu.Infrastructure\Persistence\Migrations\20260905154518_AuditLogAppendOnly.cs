using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace FinEdu.Infrastructure.Persistence.Migrations
{
    /// <summary>
    /// აუდიტის ჟურნალი მხოლოდ იზრდება: UPDATE/DELETE ბაზის დონეზე იკრძალება.
    ///
    /// უფლებები (რომელ ანგარიშს რა შეუძლია) deploy-ის სკრიპტშია — ისინი login-ების
    /// სახელებზეა დამოკიდებული. trigger კი სქემის ნაწილია და ყველა გარემოში ერთნაირად
    /// უნდა არსებობდეს, თორემ ახლად შექმნილ ბაზაზე ჩუმად აღარ იმუშავებდა.
    ///
    /// DBA-ს შენახვის ვადის გასვლისას: DISABLE TRIGGER → DELETE → ENABLE TRIGGER.
    /// </summary>
    public partial class AuditLogAppendOnly : Migration
    {
        private const string TriggerName = "TR_AuditLogs_AppendOnly";

        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql($"""
                IF OBJECT_ID(N'dbo.{TriggerName}', N'TR') IS NOT NULL
                    DROP TRIGGER dbo.{TriggerName};
                """);

            // EXEC-ით, რადგან CREATE TRIGGER პაკეტში პირველ ბრძანებად უნდა იდგეს
            migrationBuilder.Sql($"""
                EXEC(N'
                CREATE TRIGGER dbo.{TriggerName}
                ON dbo.AuditLogs
                INSTEAD OF UPDATE, DELETE
                AS
                BEGIN
                    SET NOCOUNT ON;
                    THROW 51000, N''AuditLogs is append-only: UPDATE and DELETE are not permitted.'', 1;
                END');
                """);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql($"""
                IF OBJECT_ID(N'dbo.{TriggerName}', N'TR') IS NOT NULL
                    DROP TRIGGER dbo.{TriggerName};
                """);
        }
    }
}
