﻿namespace FinEdu.Domain.Enums;

public enum SubmissionStatus
{
    Pending = 1,    // ფაილები ჯერ სკანირდება
    Completed = 2,
    Rejected = 3    // მაგ. ინფიცირებული ფაილი
}
