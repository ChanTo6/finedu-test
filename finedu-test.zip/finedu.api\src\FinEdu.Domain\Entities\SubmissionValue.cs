using FinEdu.Domain.Common;

namespace FinEdu.Domain.Entities;

/// <summary>EAV — თითო ველის პასუხი. Excel export-ისას ველებად pivot-დება.</summary>
public class SubmissionValue : BaseEntity
{
    public Guid SubmissionId { get; set; }
    public Submission? Submission { get; set; }

    public Guid FieldId { get; set; }
    public FormField? Field { get; set; }

    public string? Value { get; set; }
}
