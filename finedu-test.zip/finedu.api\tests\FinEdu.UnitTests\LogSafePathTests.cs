using FinEdu.Infrastructure.Http;
using Xunit;

namespace FinEdu.UnitTests;

/// <summary>
/// ჟიურის ბმულის token ორფაქტორიანი წვდომის ერთი ნახევარია და მისამართის ნაწილიც —
/// ანუ ყოველი მიმართვა მას access-ლოგში (90 დღე) და შეცდომების ჩანაწერებში ტოვებდა.
/// ეს ტესტი ზუსტად იმას იცავს, რომ ნიღაბი მოქმედებდეს და დანარჩენი მისამართები
/// გამოძიებისთვის კითხვადი დარჩეს.
/// </summary>
public class LogSafePathTests
{
    private const string Token = "3f2a1b0c9d8e7f6a5b4c3d2e1f0a9b8c7d6e5f4a3b2c1d0e9f8a7b6c5d4e3f2a";

    [Theory]
    [InlineData("/api/jury/")]
    [InlineData("/api/jury/{0}/login")]
    [InlineData("/api/jury/{0}/forgot-pin")]
    public void Access_token_never_reaches_the_log(string template)
    {
        var path = string.Format(template.Contains("{0}") ? template : template + "{0}", Token);

        var masked = LogSafePath.Mask(path);

        Assert.DoesNotContain(Token, masked);
        Assert.Contains("***", masked);
    }

    /// <summary>დანარჩენი ჟიურის მარშრუტები უცვლელი რჩება — თორემ ლოგი გამოუსადეგარი გახდებოდა.</summary>
    [Theory]
    [InlineData("/api/jury/logout")]
    [InlineData("/api/jury/submissions")]
    [InlineData("/api/jury/submissions/8e0d1c2b-3a49-4c5d-8e7f-0a1b2c3d4e5f/evaluation")]
    [InlineData("/api/jury/files/8e0d1c2b-3a49-4c5d-8e7f-0a1b2c3d4e5f")]
    [InlineData("/api/forms/a1b2c3d4e5f60718293a4b5c6d7e8f90")]
    [InlineData("/api/auth/login")]
    public void Other_paths_stay_readable(string path) =>
        Assert.Equal(path, LogSafePath.Mask(path));

    /// <summary>ნიღაბი მხოლოდ ჟიურის პრეფიქსზე მოქმედებს — სხვაგან იგივე ფორმის მნიშვნელობა არ იმალება.</summary>
    [Fact]
    public void Mask_applies_only_to_the_jury_prefix() =>
        Assert.Equal($"/api/other/{Token}", LogSafePath.Mask($"/api/other/{Token}"));

    [Fact]
    public void Empty_path_is_handled() => Assert.Equal(string.Empty, LogSafePath.Mask(null));
}
