import { Component, OnInit, computed, inject, signal } from '@angular/core';
import { Router, RouterLink } from '@angular/router';
import { Observable } from 'rxjs';
import { FormStatus, FormSummary, apiErrorMessage, saveBlob } from 'shared-lib';
import { Roles } from '../../core/roles';
import { AuthService } from '../../core/services/auth.service';
import { FormsService } from '../../core/services/forms.service';

@Component({
  selector: 'app-forms-list',
  imports: [RouterLink],
  templateUrl: './forms-list.html',
  styleUrl: './forms-list.scss',
})
export class FormsList implements OnInit {
  private readonly service = inject(FormsService);
  private readonly router = inject(Router);
  private readonly auth = inject(AuthService);

  readonly FormStatus = FormStatus;

  /** დამტკიცება მხოლოდ ადმინისტრატორს შეუძლია (სერვერიც ამას ამოწმებს). */
  readonly isAdministrator = this.auth.hasRole(Roles.Administrator);

  readonly forms = signal<FormSummary[]>([]);
  readonly loading = signal(true);

  /**
   * კონკურსის მოძებნა სათაურით. ფილტრი კლიენტზეა: სია ისედაც მთლიანად ჩამოტვირთულია
   * და მასში მონაწილეთა პერსონალური მონაცემები არ არის — თითო კონკურსზე მხოლოდ
   * სათაური, სტატუსი და რაოდენობაა.
   */
  readonly search = signal('');

  readonly visibleForms = computed(() => {
    const needle = this.search().trim().toLocaleLowerCase();
    if (!needle) return this.forms();

    return this.forms().filter((f) => f.title.toLocaleLowerCase().includes(needle));
  });

  /**
   * სერვერის უარი მომხმარებელს უნდა დაენახოს. აქამდე ეს მოქმედებები პასუხს საერთოდ
   * არ ამოწმებდნენ: დამკვირვებელი დახურვას აჭერდა, სერვერი 403-ს აბრუნებდა და
   * გვერდზე *არაფერი* იცვლებოდა — ეგონებოდა, რომ ღილაკი გაფუჭებულია.
   */
  readonly error = signal('');

  /** სტატუსი → ქართული წარწერა. ინდექსის ნაცვლად ცხადი რუკა — ახალი სტატუსი აქ ჩანს. */
  private static readonly StatusLabels: Record<FormStatus, string> = {
    [FormStatus.Draft]: 'მონახაზი',
    [FormStatus.PendingApproval]: 'დასამტკიცებელი',
    [FormStatus.Live]: 'აქტიური',
    [FormStatus.Closed]: 'დახურული',
  };

  ngOnInit(): void {
    this.load();
  }

  load(): void {
    this.service.list().subscribe({
      next: (f) => {
        this.forms.set(f);
        this.loading.set(false);
      },
      error: () => {
        this.error.set('ფორმების სია ვერ ჩაიტვირთა.');
        this.loading.set(false);
      },
    });
  }

  submit(id: string): void {
    this.run(this.service.submitForApproval(id));
  }

  approve(id: string): void {
    this.run(this.service.approve(id));
  }

  close(id: string): void {
    this.run(this.service.close(id));
  }

  exportExcel(id: string, title: string): void {
    this.error.set('');
    this.service.downloadExport(id).subscribe({
      next: (blob) => saveBlob(blob, `${title}.xlsx`),
      error: (e) => this.error.set(apiErrorMessage(e, 'Excel-ის ჩამოტვირთვა ვერ მოხერხდა.')),
    });
  }

  /** სტატუსის ცვლილება: წარმატებაზე სია განახლდება, უარზე მიზეზი ჩანს. */
  private run(request: Observable<void>): void {
    this.error.set('');
    request.subscribe({
      next: () => this.load(),
      error: (e) => this.error.set(apiErrorMessage(e, 'მოქმედება ვერ შესრულდა.')),
    });
  }

  statusLabel(status: FormStatus): string {
    return FormsList.StatusLabels[status] ?? String(status);
  }

  logout(): void {
    this.auth.logout().subscribe(() => this.router.navigate(['/login']));
  }
}
