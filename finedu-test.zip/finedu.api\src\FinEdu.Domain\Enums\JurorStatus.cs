namespace FinEdu.Domain.Enums;

/// <summary>
/// ჟიურის მოწვევის მდგომარეობა.
///
/// <para>მოდერატორს ჟიურის დამატება შეუძლია, მაგრამ წვდომას ადმინისტრატორი იძლევა —
/// იგივე ორდონიანი წესი, რაც ფორმის დამტკიცებაზეა (Draft → PendingApproval → Live).</para>
/// </summary>
public enum JurorStatus
{
    /// <summary>მოდერატორმა დაამატა, ადმინისტრატორის დადასტურებას ელოდება. წერილი ჯერ არ გაგზავნილა.</summary>
    PendingApproval = 1,

    /// <summary>დადასტურებულია — ბმული და PIN გაგზავნილია, შეფასება შეუძლია.</summary>
    Approved = 2
}
