﻿using System.Text.RegularExpressions;
using FinEdu.Application.Common.Models;
using FinEdu.Domain.Enums;
using FinEdu.Domain.ValueObjects;
using FluentValidation;

namespace FinEdu.Application.Forms.Validators;

/// <summary>
/// ფორმის აღწერის წესები — ერთხელ დაწერილი, ორივესთვის (შექმნა და რედაქტირება).
/// ადრე ორ ცალკე ვალიდატორში სიტყვასიტყვით იმეორებოდა: ერთში წესის შეცვლა მეორეს
/// არ ეხებოდა და რედაქტირებით ისეთი მონაცემის ჩაწერა შეიძლებოდა, რომელსაც შექმნა კრძალავდა.
/// </summary>
public class FormDefinitionValidator<T> : AbstractValidator<T> where T : IFormDefinitionRequest
{
    public FormDefinitionValidator()
    {
        // ზღვარი მარკირებას ითვლის: `<span style="color: rgb(230,0,0)">` მარტო ~40 სიმბოლოა,
        // ხოლო ტექსტური ვერსია სერვერზე ისედაც 300-ზე იჭრება (FormService.PlainTitle).
        RuleFor(x => x.Title).NotEmpty().MaximumLength(2000);
        RuleFor(x => x.RetentionDays).GreaterThan(0);
        RuleFor(x => x.MaxParticipants).GreaterThan(0).When(x => x.MaxParticipants.HasValue);
        RuleFor(x => x.Fields).NotEmpty().WithMessage("მინიმუმ ერთი ველი უნდა იყოს.");
        RuleForEach(x => x.Fields).ChildRules(f =>
        {
            f.RuleFor(z => z.Label).NotEmpty().MaximumLength(500);

            // doc §3.2: ფორმატები მკაცრად განსაზღვრულია. ფაილის ველზე ადმინი ირჩევს, რომელი
            // დაუშვას — სურათების კონკურსზე ვიდეო რომ ვერავინ ატვირთოს. ცარიელი სია
            // „ყველაფერი დაშვებულია"-ს ნიშნავდა, ამიტომ ფაილის ველზე ის აღარ მიიღება.
            f.RuleFor(z => z.Config)
                .Must(c => c?.AllowedExtensions is { Count: > 0 } exts &&
                           exts.All(e => FileUploadPolicy.TryGetRule(e, out _)))
                .When(z => z.Type == FieldType.FileUpload)
                .WithMessage(z => $"ველს „{z.Label}\" მინიმუმ ერთი დასაშვები ფორმატი უნდა ჰქონდეს.");
        });

        // PDP §4.1 + კომენტარი #12: თანხმობის მონიშვნა პირობების გახსნის გარეშე შეუძლებელი
        // უნდა იყოს. ცარიელ პირობებზე საჯარო გვერდი გასახსნელს არაფერს აჩვენებდა და
        // მოსანიშნი მაშინვე აქტიური იქნებოდა — ანუ თანხმობა არაფერზე.
        RuleFor(x => x.PrivacyNoticeHtml)
            .Must(HasText)
            .WithMessage("პერსონალურ მონაცემთა დამუშავების პირობების შევსება სავალდებულოა.");
    }

    /// <summary>მარკირების გარეშეც რჩება ტექსტი? `&lt;p&gt;&lt;br&gt;&lt;/p&gt;` შევსებულად არ ითვლება.</summary>
    private static bool HasText(string? html) =>
        !string.IsNullOrWhiteSpace(html) &&
        !string.IsNullOrWhiteSpace(Markup.Replace(html, " ").Replace("&nbsp;", " "));

    private static readonly Regex Markup = new("<[^>]*>", RegexOptions.Compiled);
}

/// <summary>სტატიკური ვალიდაცია ფორმის შექმნისას (FluentValidation).</summary>
public class CreateFormRequestValidator : AbstractValidator<CreateFormRequest>
{
    public CreateFormRequestValidator() => Include(new FormDefinitionValidator<CreateFormRequest>());
}

/// <summary>რედაქტირების ვალიდაცია — იგივე წესები, რაც შექმნისას.</summary>
public class UpdateFormRequestValidator : AbstractValidator<UpdateFormRequest>
{
    public UpdateFormRequestValidator() => Include(new FormDefinitionValidator<UpdateFormRequest>());
}

/// <summary>
/// კონკურსზე წვდომის მინიჭება. ანგარიშის *არსებობა* AD-ში აქ არ მოწმდება: LDAP-ს
/// მხოლოდ შესვლისას ვიყენებთ (მომხმარებელი თავისი პაროლით bind-დება), სერვისული
/// ანგარიში კი არ გვაქვს — ანუ ძებნა შესვლის გარეშე ტექნიკურად შეუძლებელია.
/// არარსებულ ანგარიშზე მიცემული წვდომა უბრალოდ ვერავის გამოადგება.
/// </summary>
public class GrantFormAccessRequestValidator : AbstractValidator<GrantFormAccessRequest>
{
    public GrantFormAccessRequestValidator()
    {
        RuleFor(x => x.AdAccount)
            .NotEmpty().WithMessage("მიუთითეთ AD ანგარიში.")
            .MaximumLength(256)
            .Must(a => a is not null && !a.Any(char.IsControl))
            .WithMessage("ანგარიში შეიცავს დაუშვებელ სიმბოლოებს.");

        RuleFor(x => x.AccessLevel).IsInEnum().WithMessage("წვდომის დონე არასწორია.");
    }
}
