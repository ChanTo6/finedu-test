using System.Diagnostics;
using FinEdu.Domain.Entities;
using FinEdu.Infrastructure.Persistence;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;

namespace FinEdu.Infrastructure.Http;

public static class RequestLoggingMiddleware
{
    public static IApplicationBuilder UseDbRequestLogging(this IApplicationBuilder app) =>
        app.Use(async (ctx, next) =>
        {
            var sw = Stopwatch.StartNew();
            string? exception = null;

            try
            {
                await next();
            }
            catch (Exception ex)
            {
                exception = Truncate(ex.ToString(), 4000);
                throw;
            }
            finally
            {
                sw.Stop();

                try
                {
                    var db = ctx.RequestServices.GetRequiredService<AppDbContext>();
                    db.HttpRequestLogs.Add(new HttpRequestLog
                    {
                        Method = ctx.Request.Method,
                        Path = Truncate(LogSafePath.Of(ctx.Request.Path), 2000) ?? string.Empty,
                        StatusCode = ctx.Response.StatusCode,
                        ElapsedMs = sw.ElapsedMilliseconds,
                        IpAddress = Truncate(ctx.Connection.RemoteIpAddress?.ToString(), 64),
                        VisitorId = Truncate(VisitorCookie.Current(ctx), 64),
                        UserAgent = Truncate(ctx.Request.Headers.UserAgent.ToString(), 512),
                        Exception = exception
                    });

                    await db.SaveChangesAsync(CancellationToken.None);
                }
                catch (Exception ex)
                {
                    var logger = ctx.RequestServices.GetService<ILogger<HttpRequestLog>>();
                    logger?.LogWarning(ex, "HTTP request log ბაზაში ჩაწერა ვერ მოხერხდა");
                }
            }
        });

    private static string? Truncate(string? value, int maxLength) =>
        value is null ? null : value.Length <= maxLength ? value : value[..maxLength];
}
