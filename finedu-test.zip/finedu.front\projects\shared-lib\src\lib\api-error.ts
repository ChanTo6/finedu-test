/**
 * სერვერის შეცდომიდან მომხმარებლისთვის საჩვენებელი ტექსტი.
 *
 * backend ორ ფორმატს აბრუნებს: ველების შეცდომებს (`errors`, 400) და ერთ შეტყობინებას
 * (`message` — 403, 404, 409, 503). ორივე შემთხვევაში სერვერის ტექსტი ჯობია ზოგადს:
 * მასში წერია, *რატომ* არ გამოვიდა და რა ქნას მომხმარებელმა.
 *
 * <p>ეს ფუნქცია ექვს კომპონენტში სიტყვასიტყვით იყო გადაწერილი — ერთში შესწორება
 * დანარჩენებს არ ეხებოდა და ერთი და იგივე შეცდომა სხვადასხვა გვერდზე სხვადასხვანაირად
 * ჩანდა.</p>
 */
export function apiErrorMessage(error: unknown, fallback: string): string {
  const body = (error as { error?: { message?: string; errors?: Record<string, string[]> } })
    ?.error;

  const fieldErrors = Object.values(body?.errors ?? {}).flat();
  if (fieldErrors.length > 0) return fieldErrors.join(' ');

  return body?.message ?? fallback;
}
