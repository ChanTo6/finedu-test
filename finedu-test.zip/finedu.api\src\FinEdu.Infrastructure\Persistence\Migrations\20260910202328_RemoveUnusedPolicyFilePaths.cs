﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace FinEdu.Infrastructure.Persistence.Migrations
{
    /// <summary>
    /// ორი გამოუყენებელი სვეტის ჩამოშლა: კონკურსის პირობებისა და პერს. მონაცემთა
    /// პოლიტიკის ფაილების გზები.
    ///
    /// <para>შეთანხმდა, რომ პირობები ტექსტად, იქვე უნდა იკითხებოდეს და მისი გახსნის
    /// გარეშე თანხმობის მონიშვნა შეუძლებელი უნდა იყოს — ამას ფაილის ჩამოტვირთვა ვერ
    /// უზრუნველყოფდა. ტექსტი <c>PrivacyNoticeHtml</c>-ში ინახება, ეს ორი სვეტი კი
    /// არასდროს შევსებულა (გაშვებამდე შემოწმდა — ორივე ცარიელია).</para>
    /// </summary>
    public partial class RemoveUnusedPolicyFilePaths : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "PrivacyPolicyFilePath",
                table: "Forms");

            migrationBuilder.DropColumn(
                name: "TermsFilePath",
                table: "Forms");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "PrivacyPolicyFilePath",
                table: "Forms",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "TermsFilePath",
                table: "Forms",
                type: "nvarchar(max)",
                nullable: true);
        }
    }
}
