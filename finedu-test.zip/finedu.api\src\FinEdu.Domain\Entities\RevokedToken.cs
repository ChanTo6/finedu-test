using FinEdu.Domain.Common;

namespace FinEdu.Domain.Entities;

/// <summary>
/// Logout-ისას გაუქმებული JWT. ბაზაში ინახება და არა მეხსიერებაში — რესტარტის შემდეგ
/// გაუქმებული ტოკენი ისევ ვალიდური რომ არ გახდეს.
/// </summary>
public class RevokedToken : BaseEntity
{
    /// <summary>ტოკენის უნიკალური იდენტიფიკატორი (jti claim).</summary>
    public string Jti { get; set; } = string.Empty;

    /// <summary>თავად ტოკენის ვადა — ამის შემდეგ ჩანაწერს აზრი აღარ აქვს და იშლება.</summary>
    public DateTimeOffset ExpiresAt { get; set; }
}
