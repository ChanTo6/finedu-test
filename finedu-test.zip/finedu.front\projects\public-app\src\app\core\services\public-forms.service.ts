import { HttpClient, HttpEvent } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { Observable } from 'rxjs';
import { CreateSubmission, PublicForm, PublicFormListItem } from 'shared-lib';
import { environment } from '../../../environments/environment';

@Injectable({ providedIn: 'root' })
export class PublicFormsService {
  private readonly http = inject(HttpClient);
  private readonly base = environment.apiUrl;

  /** გამოცხადებული კონკურსების სია — ავტორიზაცია არ სჭირდება. */
  list(): Observable<PublicFormListItem[]> {
    return this.http.get<PublicFormListItem[]>(`${this.base}/forms`);
  }

  getByToken(token: string): Observable<PublicForm> {
    return this.http.get<PublicForm>(`${this.base}/forms/${token}`);
  }

  /** ქავერ ფოტოს მისამართი — ფაილი web-root-ის გარეთაა, endpoint-ით გაიცემა. */
  coverUrl(token: string): string {
    return `${this.base}/forms/${token}/cover`;
  }

  /**
   * multipart: payload (JSON), ფაილები (name = fieldId).
   *
   * `observe: 'events'` — რომ ატვირთვის პროგრესი გამოჩნდეს: 200 MB ვიდეო ნელ ინტერნეტზე
   * წუთებს გრძელდება და უკუკავშირის გარეშე მომხმარებელი ფიქრობს, რომ გვერდი გაიჭედა.
   */
  submit(
    token: string,
    payload: CreateSubmission,
    files: Record<string, File[]>,
  ): Observable<HttpEvent<{ id: string }>> {
    const form = new FormData();
    form.append('payload', JSON.stringify(payload));
    for (const [fieldId, list] of Object.entries(files)) {
      for (const file of list) {
        form.append(fieldId, file, file.name);
      }
    }
    return this.http.post<{ id: string }>(`${this.base}/forms/${token}/submissions`, form, {
      reportProgress: true,
      observe: 'events',
    });
  }
}
