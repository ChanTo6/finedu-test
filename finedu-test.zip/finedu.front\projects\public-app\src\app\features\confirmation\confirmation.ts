import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';
import { TPipe } from '../../core/pipes/t.pipe';

@Component({
  selector: 'app-confirmation',
  imports: [RouterLink, TPipe],
  template: `
    <div class="done">
      <span class="mark" aria-hidden="true"></span>
      <h1>{{ 'done.title' | t }}</h1>
      <p>{{ 'done.text' | t }}</p>
      <a routerLink="/" class="back">{{ 'done.back' | t }}</a>
    </div>
  `,
  styleUrl: './confirmation.scss',
})
export class Confirmation {}
