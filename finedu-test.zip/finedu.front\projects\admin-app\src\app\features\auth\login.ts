import { Component, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { environment } from '../../../environments/environment';
import { AuthService } from '../../core/services/auth.service';

/** სატესტო DevAuth ანგარიშები — appsettings.Development.json-ს ემთხვევა.
 *  ლოკალურ build-ში ვაჩვენებთ ტესტერებისთვის, პროდში (`ng build --configuration production`)
 *  ცხდისცხდით ვმალავთ — production build-ს DevAuth-იც არ იტვირთება, ე.ი. აქ ჩვენება
 *  მხოლოდ ცხდისცხდით არასწორ პაროლს გამოიწვევდა. */
const TEST_ACCOUNTS: readonly { role: string; username: string; password: string }[] = [
  { role: 'ადმინი', username: 'test', password: 'devpass123' },
  { role: 'მოდერატორი', username: 'moderator', password: 'modpass123' },
];

@Component({
  selector: 'app-login',
  imports: [FormsModule],
  template: `
    <div class="login">
      <header class="brand">
        <span class="brand-mark" aria-hidden="true"></span>
        <span class="brand-org">საქართველოს ეროვნული ბანკი</span>
        <span class="brand-name">ფინედუ — ადმინისტრირება</span>
      </header>

      <div class="panel">
        <label>
          მომხმარებელი (AD)
          <input [(ngModel)]="username" name="username" autocomplete="username" />
        </label>

        <label>
          პაროლი
          <input
            type="password"
            name="password"
            autocomplete="current-password"
            [(ngModel)]="password"
            (keyup.enter)="submit()"
          />
        </label>

        @if (error()) {
          <p class="err" role="alert">{{ error() }}</p>
        }

        <button (click)="submit()" [disabled]="loading()">
          {{ loading() ? 'შესვლა…' : 'შესვლა' }}
        </button>

        @if (showTestAccounts) {
          <div class="test-accounts" role="note">
            <p class="test-title">სატესტო ანგარიშები</p>
            <ul>
              @for (a of accounts; track a.username) {
                <li>
                  <button
                    type="button"
                    class="fill"
                    (click)="fill(a.username, a.password)"
                    [title]="'შევსება: ' + a.username"
                  >
                    {{ a.role }}: <strong>{{ a.username }}</strong> / {{ a.password }}
                  </button>
                </li>
              }
            </ul>
            <p class="test-hint">ღილაკზე დაჭერით ავტომატურად ივსება ველები.</p>
          </div>
        }
      </div>

      <p class="note">წვდომა შესაძლებელია მხოლოდ დაშვებული AD ჯგუფის წევრებისთვის.</p>
    </div>
  `,
  styleUrl: './login.scss',
})
export class Login {
  private readonly auth = inject(AuthService);
  private readonly router = inject(Router);
  private readonly route = inject(ActivatedRoute);

  username = '';
  password = '';
  readonly error = signal<string | null>(null);
  readonly loading = signal(false);

  readonly showTestAccounts = !environment.production;
  readonly accounts = TEST_ACCOUNTS;

  fill(username: string, password: string): void {
    this.username = username;
    this.password = password;
  }

  /**
   * მისამართი აუცილებლად ამავე აპლიკაციისა უნდა იყოს — `//evil.example` ბრაუზერისთვის
   * გარე მისამართია და ღია გადამისამართებას გამოიწვევდა.
   */
  private returnUrl(): string {
    const url = this.route.snapshot.queryParamMap.get('returnUrl');
    return url?.startsWith('/') && !url.startsWith('//') ? url : '/forms';
  }

  submit(): void {
    if (!this.username.trim()) {
      this.error.set('გთხოვთ შეიყვანოთ მომხმარებელი.');
      return;
    }
    if (!this.password) {
      this.error.set('გთხოვთ შეიყვანოთ პაროლი.');
      return;
    }

    this.loading.set(true);
    this.error.set(null);
    this.auth.login(this.username, this.password).subscribe({
      next: () => this.router.navigateByUrl(this.returnUrl()),
      error: (e) => {
        this.error.set(e?.error?.message ?? 'შესვლა ვერ მოხერხდა.');
        this.loading.set(false);
      },
    });
  }
}
