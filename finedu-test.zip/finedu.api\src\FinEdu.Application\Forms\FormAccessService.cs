using FinEdu.Application.Common.Audit;
using FinEdu.Application.Common.Exceptions;
using FinEdu.Application.Common.Interfaces;
using FinEdu.Application.Common.Models;
using FinEdu.Application.Common.Security;
using FinEdu.Domain.Entities;
using Microsoft.EntityFrameworkCore;

namespace FinEdu.Application.Forms;

/// <summary>
/// ვის რომელ კონკურსზე აქვს წვდომა (doc §4.1 — per-project იზოლაცია).
///
/// <para>
/// <b>ეს არ არის მომხმარებლების მართვა.</b> თანამშრომლები, მათი პაროლები, სახელები და
/// ჯგუფები AD-შია და იქვე რჩება — აქ მხოლოდ ერთი კავშირი ინახება: „ამ AD ანგარიშს ამ
/// კონკურსზე ეს დონე აქვს". ანგარიშის შექმნა, გამორთვა ან სახელის შეცვლა ისევ AD-ის
/// საქმეა და ამ სისტემას არ ეხება.
/// </para>
///
/// <para>
/// წვდომას იძლევა ის, ვისაც კონკურსის მართვა შეუძლია — მმართველი (მაგ. შემქმნელი) ან
/// ადმინისტრატორი. იგივე წესია ფორმის რედაქტირებაზე, დახურვასა და ჟიურის მართვაზე,
/// ანუ ცალკე გამონაკლისი აქ არ ჩნდება.
/// </para>
/// </summary>
public interface IFormAccessService
{
    Task<IReadOnlyList<FormAccessDto>> ListAsync(Guid formId, CancellationToken ct = default);

    /// <summary>ახალი წვდომა ან არსებულის დონის შეცვლა.</summary>
    Task GrantAsync(Guid formId, GrantFormAccessRequest request, CancellationToken ct = default);

    Task RevokeAsync(Guid formId, Guid accessId, CancellationToken ct = default);
}

public class FormAccessService(
    IAppDbContext db,
    IFormAccessGuard accessGuard,
    ICurrentUser currentUser,
    IAuditLogger audit) : IFormAccessService
{
    public async Task<IReadOnlyList<FormAccessDto>> ListAsync(Guid formId, CancellationToken ct = default)
    {
        // ვის რა უფლება აქვს — ესეც კონკურსის მონაცემია, ანუ კითხვის წვდომას ითხოვს
        await accessGuard.EnsureCanAccessAsync(formId, ct);

        return await db.FormAccessList.AsNoTracking()
            .Where(a => a.FormId == formId)
            .OrderByDescending(a => a.AccessLevel)
            .ThenBy(a => a.AdAccount)
            .Select(a => new FormAccessDto(a.Id, a.AdAccount, a.AccessLevel, a.CreatedAt, a.CreatedBy))
            .ToListAsync(ct);
    }

    public async Task GrantAsync(Guid formId, GrantFormAccessRequest request, CancellationToken ct = default)
    {
        await accessGuard.EnsureCanManageAsync(formId, ct);

        // ფორმის არსებობა ცხადად: ადმინისტრატორისთვის guard არაფერს ამოწმებს და
        // არარსებულ კონკურსზე წვდომის ჩაწერა ჩუმად გაივლიდა.
        var formExists = await db.Forms.AsNoTracking().AnyAsync(f => f.Id == formId, ct);
        if (!formExists) throw new NotFoundException(nameof(Form), formId);

        var account = request.AdAccount.Trim();

        var existing = await db.FormAccessList
            .FirstOrDefaultAsync(a => a.FormId == formId && a.AdAccount == account, ct);

        if (existing is not null)
        {
            // დონის შეცვლა და არა მეორე ჩანაწერი — უნიკალური ინდექსი ისედაც ერთს უშვებს,
            // ხოლო „უკვე აქვს წვდომა" შეცდომა მომხმარებელს დონის აწევას შეუძლებელს გახდიდა.
            if (existing.AccessLevel == request.AccessLevel) return;

            existing.AccessLevel = request.AccessLevel;
        }
        else
        {
            db.FormAccessList.Add(new FormAccess
            {
                FormId = formId,
                AdAccount = account,
                AccessLevel = request.AccessLevel,
                CreatedBy = currentUser.Account
            });
        }

        await db.SaveChangesAsync(ct);
        await audit.LogAsync(AuditActions.FormAccessGranted, nameof(FormAccess), formId.ToString(),
            $"account={account}; level={request.AccessLevel}", ct);
    }

    public async Task RevokeAsync(Guid formId, Guid accessId, CancellationToken ct = default)
    {
        await accessGuard.EnsureCanManageAsync(formId, ct);

        // FormId-ს ცხადად ვამოწმებთ: სხვისი კონკურსის ჩანაწერის id-ის მითითება
        // წვდომის შემოწმებას გვერდს აუვლიდა.
        var access = await db.FormAccessList
            .FirstOrDefaultAsync(a => a.Id == accessId && a.FormId == formId, ct)
            ?? throw new NotFoundException(nameof(FormAccess), accessId);

        // საკუთარი წვდომის მოხსნა კონკურსზე შესვლას მაშინვე შეუძლებელს გახდიდა და
        // მისი დაბრუნება მხოლოდ ადმინისტრატორს შეეძლებოდა — კლასიკური თვითდაბლოკვა.
        if (!currentUser.IsAdministrator &&
            string.Equals(access.AdAccount, currentUser.Account, StringComparison.OrdinalIgnoreCase))
        {
            throw new DomainException("საკუთარ წვდომას ვერ მოიხსნით — სთხოვეთ ადმინისტრატორს.");
        }

        db.FormAccessList.Remove(access);
        await db.SaveChangesAsync(ct);

        await audit.LogAsync(AuditActions.FormAccessRevoked, nameof(FormAccess), formId.ToString(),
            $"account={access.AdAccount}", ct);
    }
}
