using System.Net;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text.Json;
using Microsoft.AspNetCore.Hosting;

namespace FinEdu.IntegrationTests;

/// <summary>ტოკენს უარყოფითი ვადა აქვს — ანუ გაცემისთანავე ვადაგასულია.</summary>
public class ExpiredTokenApiFactory : AdminApiFactory
{
    protected override void ConfigureWebHost(IWebHostBuilder builder)
    {
        base.ConfigureWebHost(builder);
        builder.UseSetting("Jwt:ExpiryMinutes", "-1");
    }
}

/// <summary>
/// ვადის შემოწმება ცალკე მოწმდება: <c>ValidateLifetime</c>-ის შემთხვევით გამორთვა
/// ვერცერთ სხვა ტესტს ვერ დაეჭირებოდა — ისინი ყველა ახალი ტოკენით მუშაობს.
///
/// <para>ClockSkew 30 წამია, ამიტომ ვადა −1 წუთით უკან ცხადად გარეთაა.</para>
/// </summary>
public class ExpiredTokenTests : IAsyncLifetime
{
    private readonly ExpiredTokenApiFactory _factory = new();
    private HttpClient _client = null!;
    private string _token = "";

    public async Task InitializeAsync()
    {
        _client = _factory.CreateClient();

        var login = await _client.PostAsJsonAsync("/api/auth/login",
            new { username = "tester", password = "test-password" });

        // შესვლა თავისთავად წარმატებულია — ტოკენი გაიცემა, უბრალოდ უკვე ვადაგასული
        login.EnsureSuccessStatusCode();
        _token = (await login.Content.ReadFromJsonAsync<JsonElement>()).GetProperty("token").GetString()!;
    }

    public Task DisposeAsync()
    {
        _factory.Dispose();
        return Task.CompletedTask;
    }

    [Fact]
    public async Task Expired_token_is_rejected()
    {
        _client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", _token);

        var response = await _client.GetAsync("/api/forms");

        Assert.Equal(HttpStatusCode.Unauthorized, response.StatusCode);
    }

    /// <summary>ვადაგასული ტოკენით გასვლაც არ გამოდის — სესია ისედაც აღარ არსებობს.</summary>
    [Fact]
    public async Task Expired_token_cannot_log_out()
    {
        _client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", _token);

        var response = await _client.PostAsync("/api/auth/logout", null);

        Assert.Equal(HttpStatusCode.Unauthorized, response.StatusCode);
    }
}
