﻿using FinEdu.Application.Common.Audit;
using FinEdu.Application.Common.Interfaces;
using FinEdu.Application.Common.Models;
using FinEdu.Application.Common.Options;
using FinEdu.Application.Common.Security;
using FinEdu.Application.Files;
using FinEdu.Application.Submissions;
using FinEdu.Domain.Entities;
using FinEdu.Domain.Enums;
using FinEdu.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Diagnostics;
using Microsoft.EntityFrameworkCore.InMemory.Infrastructure.Internal;
using Microsoft.Extensions.Logging.Abstractions;
using Microsoft.Extensions.Options;
using Xunit;

namespace FinEdu.UnitTests;

/// <summary>
/// retention-ის წაშლა სისტემაში ერთადერთი არააღდგენადი ოპერაციაა — და ერთადერთი,
/// რომელსაც ადამიანი არ უყურებს (ფონური job-ია). ამიტომ სამივე პირობა ცხადად მოწმდება:
/// ვადაგასული ქრება, ვადაში მყოფი რჩება და ფაილიც დისკიდან იშლება.
///
/// <para>In-memory პროვაიდერს ტრანზაქცია არ აქვს — გაფრთხილება ჩახშობილია, რომ
/// *ლოგიკა* შემოწმდეს. ტრანზაქციის რეალური ქცევა SQL Server-ის საქმეა.</para>
/// </summary>
public class RetentionPurgeTests : IDisposable
{
    private readonly AppDbContext _db;
    private readonly FakeStorage _storage = new();
    private readonly RecordingAudit _audit = new();

    public RetentionPurgeTests()
    {
        var options = new DbContextOptionsBuilder<AppDbContext>()
            .UseInMemoryDatabase($"retention-{Guid.NewGuid()}")
            .ConfigureWarnings(w => w.Ignore(InMemoryEventId.TransactionIgnoredWarning))
            .Options;
        _db = new AppDbContext(options);
    }

    public void Dispose() => _db.Dispose();

    [Fact]
    public async Task Expired_submissions_and_their_files_are_removed()
    {
        var expired = SeedForm(retentionUntil: DateTimeOffset.UtcNow.AddDays(-1));

        var count = await Service().DeleteExpiredAsync();

        Assert.Equal(1, count);
        Assert.Empty(await _db.Submissions.ToListAsync());

        // ჩანაწერიც და ფაილიც — თორემ პერსონალური მონაცემი დისკზე დარჩებოდა
        Assert.Empty(await _db.SubmissionFiles.ToListAsync());
        Assert.Empty(await _db.SubmissionValues.ToListAsync());
        Assert.Equal([$"/files/{expired}.pdf"], _storage.Deleted);

        // არააღდგენადი წაშლა უკვალოდ ვერ მოხდება
        Assert.Equal(1, _audit.Count(AuditActions.RetentionPurged));
    }

    [Fact]
    public async Task Submissions_still_within_retention_are_untouched()
    {
        SeedForm(retentionUntil: DateTimeOffset.UtcNow.AddDays(30));

        var count = await Service().DeleteExpiredAsync();

        Assert.Equal(0, count);
        Assert.Single(await _db.Submissions.ToListAsync());
        Assert.Empty(_storage.Deleted);
        Assert.Equal(0, _audit.Count(AuditActions.RetentionPurged));
    }

    /// <summary>დახურვამდე RetentionUntil ცარიელია — ასეთი კონკურსი წაშლაში არ ხვდება.</summary>
    [Fact]
    public async Task Open_form_is_never_purged()
    {
        SeedForm(retentionUntil: null);

        Assert.Equal(0, await Service().DeleteExpiredAsync());
        Assert.Single(await _db.Submissions.ToListAsync());
    }

    // ── დამხმარეები ─────────────────────────────────────────────────

    /// <summary>ერთი კონკურსი + ერთი განაცხადი, პასუხითა და ფაილით. აბრუნებს ფაილის ნიშანს.</summary>
    private Guid SeedForm(DateTimeOffset? retentionUntil)
    {
        var form = new Form
        {
            Title = "კონკურსი",
            Status = FormStatus.Closed,
            RetentionDays = 30,
            RetentionUntil = retentionUntil
        };
        var field = new FormField { FormId = form.Id, Order = 1, Type = FieldType.ShortAnswer, Label = "სახელი" };
        var submission = new Submission
        {
            FormId = form.Id,
            Status = SubmissionStatus.Completed,
            ConsentDataProcessing = true
        };
        submission.Values.Add(new SubmissionValue
        {
            SubmissionId = submission.Id,
            FieldId = field.Id,
            Value = "ნიკა"
        });
        submission.Files.Add(new SubmissionFile
        {
            SubmissionId = submission.Id,
            FieldId = field.Id,
            OriginalFileName = "cv.pdf",
            StoredPath = $"/files/{submission.Id}.pdf",
            ContentType = "application/pdf",
            ScanStatus = ScanStatus.Clean
        });

        _db.Forms.Add(form);
        _db.FormFields.Add(field);
        _db.Submissions.Add(submission);
        _db.SaveChanges();

        return submission.Id;
    }

    private SubmissionService Service() => new(
        _db,
        null!,   // IFileService — მხოლოდ განაცხადის მიღებისას გამოიყენება
        null!,   // IEmailSender — იგივე
        _storage,
        null!,   // IFormAccessGuard — მხოლოდ ადმინის სიაში
        _audit,
        TestUser.System(),
        Options.Create(new SubmissionGuardOptions()),
        NullLogger<SubmissionService>.Instance);
}
