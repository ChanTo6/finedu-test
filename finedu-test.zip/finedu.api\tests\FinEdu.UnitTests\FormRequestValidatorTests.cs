using FinEdu.Application.Common.Models;
using FinEdu.Application.Forms.Validators;
using FinEdu.Domain.Enums;
using FinEdu.Domain.ValueObjects;
using Xunit;

namespace FinEdu.UnitTests;

/// <summary>
/// შექმნისა და რედაქტირების წესები ერთი და იგივე უნდა იყოს. ადრე ორ ცალკე ვალიდატორში
/// იმეორებოდა — ერთში გამკაცრება მეორეს არ ეხებოდა და რედაქტირებით ისეთი მონაცემის
/// ჩაწერა შეიძლებოდა, რომელსაც შექმნა კრძალავდა.
/// </summary>
public class FormRequestValidatorTests
{
    private static readonly List<CreateFieldRequest> OneField =
        [new(1, FieldType.ShortAnswer, "სახელი", true, new FieldConfig())];

    private const string Notice = "<p>მონაცემები მუშავდება კონკურსის ჩასატარებლად.</p>";

    private static CreateFormRequest Create(string title = "კონკურსი", int retentionDays = 30,
        int? maxParticipants = null, List<CreateFieldRequest>? fields = null, string? notice = Notice) =>
        new(title, null, null, maxParticipants, retentionDays, notice, null, fields ?? OneField);

    private static UpdateFormRequest Update(string title = "კონკურსი", int retentionDays = 30,
        int? maxParticipants = null, List<CreateFieldRequest>? fields = null, string? notice = Notice) =>
        new(title, null, null, maxParticipants, retentionDays, notice, null, fields ?? OneField);

    [Fact]
    public void Valid_request_passes_both_validators()
    {
        Assert.True(new CreateFormRequestValidator().Validate(Create()).IsValid);
        Assert.True(new UpdateFormRequestValidator().Validate(Update()).IsValid);
    }

    [Fact]
    public void Empty_title_is_rejected_by_both()
    {
        Assert.False(new CreateFormRequestValidator().Validate(Create(title: "")).IsValid);
        Assert.False(new UpdateFormRequestValidator().Validate(Update(title: "")).IsValid);
    }

    [Fact]
    public void Form_without_fields_is_rejected_by_both()
    {
        Assert.False(new CreateFormRequestValidator().Validate(Create(fields: [])).IsValid);
        Assert.False(new UpdateFormRequestValidator().Validate(Update(fields: [])).IsValid);
    }

    /// <summary>retention 0 ნიშნავს „არასდროს წაიშალოს" — პერსონალური მონაცემები ვადის გარეშე დარჩებოდა.</summary>
    [Fact]
    public void Non_positive_retention_is_rejected_by_both()
    {
        Assert.False(new CreateFormRequestValidator().Validate(Create(retentionDays: 0)).IsValid);
        Assert.False(new UpdateFormRequestValidator().Validate(Update(retentionDays: 0)).IsValid);
    }

    [Fact]
    public void Non_positive_participant_limit_is_rejected_by_both()
    {
        Assert.False(new CreateFormRequestValidator().Validate(Create(maxParticipants: 0)).IsValid);
        Assert.False(new UpdateFormRequestValidator().Validate(Update(maxParticipants: 0)).IsValid);
    }

    /// <summary>
    /// PDP §4.1: თანხმობა პირობების გაცნობის შემდეგ. ცარიელ პირობებზე მოსანიშნი
    /// წასაკითხის გარეშე აქტიურდებოდა. მარტო მარკირება (რედაქტორის ცარიელი აბზაცი) ტექსტი არ არის.
    /// </summary>
    [Theory]
    [InlineData(null)]
    [InlineData("")]
    [InlineData("   ")]
    [InlineData("<p><br></p>")]
    [InlineData("<p>&nbsp;</p>")]
    public void Missing_privacy_notice_is_rejected_by_both(string? notice)
    {
        Assert.False(new CreateFormRequestValidator().Validate(Create(notice: notice)).IsValid);
        Assert.False(new UpdateFormRequestValidator().Validate(Update(notice: notice)).IsValid);
    }

    private static List<CreateFieldRequest> FileField(List<string>? extensions) =>
        [new(1, FieldType.FileUpload, "ნახატი", true, new FieldConfig { AllowedExtensions = extensions })];

    /// <summary>doc §3.2: ფაილის ველზე ფორმატი ცხადად უნდა იყოს არჩეული — ცარიელი ყველაფერს უშვებდა.</summary>
    [Fact]
    public void File_field_without_formats_is_rejected_by_both()
    {
        Assert.False(new CreateFormRequestValidator().Validate(Create(fields: FileField(null))).IsValid);
        Assert.False(new CreateFormRequestValidator().Validate(Create(fields: FileField([]))).IsValid);
        Assert.False(new UpdateFormRequestValidator().Validate(Update(fields: FileField([]))).IsValid);
    }

    /// <summary>სპეციფიკაციის გარეთ ფორმატი (არქივი, exe) ფაილის ველზე ვერ დაემატება.</summary>
    [Theory]
    [InlineData("zip")]
    [InlineData("exe")]
    public void File_field_with_format_outside_the_spec_is_rejected(string extension)
    {
        Assert.False(new CreateFormRequestValidator()
            .Validate(Create(fields: FileField(["png", extension]))).IsValid);
    }

    [Fact]
    public void File_field_with_spec_formats_passes()
    {
        Assert.True(new CreateFormRequestValidator()
            .Validate(Create(fields: FileField(["jpg", "jpeg", "png"]))).IsValid);
    }
}
