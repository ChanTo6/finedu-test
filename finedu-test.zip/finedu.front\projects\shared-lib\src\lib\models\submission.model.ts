export interface SubmissionValueInput {
  fieldId: string;
  value: string | null;
}

export interface CreateSubmission {
  values: SubmissionValueInput[];
  consentDataProcessing: boolean;
  notificationEmail?: string | null;
}
