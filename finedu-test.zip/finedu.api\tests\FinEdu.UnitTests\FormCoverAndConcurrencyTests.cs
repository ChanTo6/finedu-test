﻿using FinEdu.Application.Common.Audit;
using FinEdu.Application.Common.Exceptions;
using FinEdu.Application.Common.Interfaces;
using FinEdu.Application.Common.Models;
using FinEdu.Application.Common.Security;
using FinEdu.Application.Forms;
using FinEdu.Domain.Entities;
using FinEdu.Domain.Enums;
using FinEdu.Infrastructure.Persistence;
using FinEdu.Infrastructure.Security;
using Microsoft.EntityFrameworkCore;
using Xunit;

namespace FinEdu.UnitTests;

/// <summary>
/// ორი ერთმანეთთან დაკავშირებული წესი: ქავერის სიცოცხლის ციკლი (ჩანაცვლება, წაშლა,
/// ობოლების გასუფთავება) და კონკურენტული რედაქტირების დაცვა.
///
/// <para>ქავერების გასუფთავება არააღდგენადია — ამიტომ აქ ცალკე მოწმდება *რას არ შლის*:
/// მოქმედს, ახლახან ატვირთულს და უცხო ფაილს.</para>
/// </summary>
public class FormCoverAndConcurrencyTests : IDisposable
{
    private const string CoverA = "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa.jpg";
    private const string CoverB = "bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb.png";
    private const string CoverC = "cccccccccccccccccccccccccccccccc.gif";

    private readonly AppDbContext _db;
    private readonly FakeStorage _storage = new();
    private readonly RecordingAudit _audit = new();

    public FormCoverAndConcurrencyTests()
    {
        var options = new DbContextOptionsBuilder<AppDbContext>()
            .UseInMemoryDatabase($"cover-{Guid.NewGuid()}")
            .Options;
        _db = new AppDbContext(options);
    }

    public void Dispose() => _db.Dispose();

    // ── ქავერის ჩანაცვლება და წაშლა ─────────────────────────────────

    [Fact]
    public async Task Replacing_the_cover_deletes_the_previous_file()
    {
        var form = SeedForm(cover: CoverA);

        await Service().UpdateAsync(form.Id, Update(cover: CoverB));

        Assert.Equal(CoverB, (await _db.Forms.FindAsync(form.Id))!.CoverImagePath);
        Assert.Equal([CoverA], _storage.DeletedCovers);
    }

    /// <summary>ცარიელი სტრიქონი = ცხადი წაშლა (null-ისგან განსხვავებით).</summary>
    [Fact]
    public async Task Empty_cover_removes_it()
    {
        var form = SeedForm(cover: CoverA);

        await Service().UpdateAsync(form.Id, Update(cover: ""));

        Assert.Null((await _db.Forms.FindAsync(form.Id))!.CoverImagePath);
        Assert.Equal([CoverA], _storage.DeletedCovers);
    }

    /// <summary>null = „არ შემიცვლია" — რედაქტირებამ ქავერი არ უნდა დაკარგოს.</summary>
    [Fact]
    public async Task Missing_cover_keeps_the_existing_one()
    {
        var form = SeedForm(cover: CoverA);

        await Service().UpdateAsync(form.Id, Update(cover: null));

        Assert.Equal(CoverA, (await _db.Forms.FindAsync(form.Id))!.CoverImagePath);
        Assert.Empty(_storage.DeletedCovers);
    }

    /// <summary>თვითნებური გზა არ მიიღება — მხოლოდ ჩვენ მიერ გაცემული ფორმატი.</summary>
    [Theory]
    [InlineData("../../etc/passwd")]
    [InlineData("evil.exe")]
    [InlineData("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa.svg")]
    public async Task Foreign_cover_name_is_refused(string name)
    {
        var form = SeedForm(cover: CoverA);

        await Assert.ThrowsAsync<ValidationException>(
            () => Service().UpdateAsync(form.Id, Update(cover: name)));
    }

    // ── ობოლების გასუფთავება ────────────────────────────────────────

    [Fact]
    public async Task Old_unreferenced_cover_is_purged()
    {
        SeedForm(cover: CoverA);
        _storage.Covers.Add(new StoredCover(CoverA, Old));
        _storage.Covers.Add(new StoredCover(CoverB, Old));   // ვერცერთი ფორმა არ იყენებს

        var purged = await Covers().PurgeOrphansAsync();

        Assert.Equal(1, purged);
        Assert.Equal([CoverB], _storage.DeletedCovers);
        Assert.Equal(1, _audit.Count(AuditActions.CoversPurged));
    }

    /// <summary>მოქმედი ქავერი არ უნდა წაიშალოს — რაც არ უნდა ძველი იყოს.</summary>
    [Fact]
    public async Task Referenced_cover_is_never_purged()
    {
        SeedForm(cover: CoverA);
        _storage.Covers.Add(new StoredCover(CoverA, DateTimeOffset.UtcNow.AddYears(-3)));

        Assert.Equal(0, await Covers().PurgeOrphansAsync());
        Assert.Empty(_storage.DeletedCovers);
    }

    /// <summary>დახურული კონკურსის ქავერიც მოქმედია — სტატუსი გასუფთავებას არ ეხება.</summary>
    [Fact]
    public async Task Cover_of_a_closed_contest_is_kept()
    {
        SeedForm(cover: CoverA, status: FormStatus.Closed);
        _storage.Covers.Add(new StoredCover(CoverA, Old));

        Assert.Equal(0, await Covers().PurgeOrphansAsync());
        Assert.Empty(_storage.DeletedCovers);
    }

    /// <summary>
    /// ყველაზე მნიშვნელოვანი დაცვა: ატვირთვასა და ფორმის შენახვას შორის ფაილი
    /// ჯერ ვერცერთ ფორმას არ უკავშირდება — მისი წაშლა ღია ფორმას გაუფუჭებდა ადმინს.
    /// </summary>
    [Fact]
    public async Task Freshly_uploaded_cover_is_kept()
    {
        _storage.Covers.Add(new StoredCover(CoverC, DateTimeOffset.UtcNow.AddHours(-1)));

        Assert.Equal(0, await Covers().PurgeOrphansAsync());
        Assert.Empty(_storage.DeletedCovers);
    }

    /// <summary>უცხო ფაილს საერთოდ არ ვეხებით — გასუფთავება მხოლოდ ჩვენს სახელებს ცნობს.</summary>
    [Theory]
    [InlineData("readme.txt")]
    [InlineData("logo.png")]
    [InlineData("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa.exe")]
    public async Task Foreign_files_are_left_alone(string name)
    {
        _storage.Covers.Add(new StoredCover(name, Old));

        Assert.Equal(0, await Covers().PurgeOrphansAsync());
        Assert.Empty(_storage.DeletedCovers);
    }

    // ── კონკურენტული რედაქტირება ────────────────────────────────────

    /// <summary>ვერსია რომ არ დაბრუნდეს, ცვლილება არ გატარდება — ჩუმი გადაწერა გამორიცხულია.</summary>
    [Fact]
    public async Task Update_without_the_version_is_refused()
    {
        var form = SeedForm(rowVersion: [1, 0, 0, 0]);

        var error = await Assert.ThrowsAsync<ValidationException>(
            () => Service().UpdateAsync(form.Id, Update(rowVersion: null)));

        Assert.Contains("RowVersion", error.Errors.Keys);
    }

    [Fact]
    public async Task Update_with_a_malformed_version_is_refused()
    {
        var form = SeedForm(rowVersion: [1, 0, 0, 0]);

        await Assert.ThrowsAsync<ValidationException>(
            () => Service().UpdateAsync(form.Id, Update(rowVersion: "not-base64!!")));
    }

    [Fact]
    public async Task Update_with_the_current_version_succeeds()
    {
        var form = SeedForm(rowVersion: [1, 0, 0, 0]);

        await Service().UpdateAsync(form.Id, Update(rowVersion: Convert.ToBase64String([1, 0, 0, 0])));

        Assert.Equal("განახლებული", (await _db.Forms.FindAsync(form.Id))!.Title);
    }

    /// <summary>
    /// მეორე რედაქტორის ვერსია მოძველებულია — ცვლილება უნდა შეჩერდეს და კონფლიქტად
    /// დაბრუნდეს (409), და არა ჩუმად გადაეწეროს პირველის ნამუშევარს.
    /// </summary>
    [Fact]
    public async Task Update_with_a_stale_version_conflicts()
    {
        var form = SeedForm(rowVersion: [1, 0, 0, 0]);

        var error = await Assert.ThrowsAsync<DomainException>(
            () => Service().UpdateAsync(form.Id, Update(rowVersion: Convert.ToBase64String([9, 9, 9, 9]))));

        Assert.Contains("სხვამ შეცვალა", error.Message);

        // და ცვლილება ნამდვილად არ გატარებულა
        Assert.Equal("საწყისი", (await _db.Forms.AsNoTracking().FirstAsync(f => f.Id == form.Id)).Title);
    }

    /// <summary>
    /// ველების რედაქტირებაც ფორმის ცვლილებაა და ვერსიის შემოწმებას უნდა ექვემდებარებოდეს.
    ///
    /// <para>⚠️ ეს ტესტი ამ წესის *მცველი არ არის*: in-memory პროვაიდერი ვერსიას ისედაც
    /// ამოწმებს, SQL Server კი UPDATE-ს საერთოდ არ გამოსცემდა, თუ სკალარული ველი არ
    /// შეცვლილა — ანუ ვერსია არ იზრდებოდა. სწორედ ამიტომ დგას FormService-ში ცხადი
    /// <c>EntityState.Modified</c>. ხარვეზი რეალურ ბაზაზე გამოჩნდა და იქვე დადასტურდა
    /// გასწორება; აქ მხოლოდ მოსალოდნელი ქცევა იწერება.</para>
    /// </summary>
    [Fact]
    public async Task Field_only_edit_is_also_version_checked()
    {
        var form = SeedForm(rowVersion: [1, 0, 0, 0]);

        // სათაური იგივეა — იცვლება მხოლოდ ველი
        var stale = new UpdateFormRequest(
            "საწყისი", null, null, null, 30, null, null,
            [new CreateFieldRequest(0, FieldType.ShortAnswer, "სხვა ველი", false, new())],
            Convert.ToBase64String([9, 9, 9, 9]));

        await Assert.ThrowsAsync<DomainException>(() => Service().UpdateAsync(form.Id, stale));
    }

    // ── დამხმარეები ─────────────────────────────────────────────────

    /// <summary>დაცდის ვადაზე (24სთ) აშკარად ძველი.</summary>
    private static DateTimeOffset Old => DateTimeOffset.UtcNow.AddDays(-7);

    private Form SeedForm(string? cover = null, FormStatus status = FormStatus.Draft, byte[]? rowVersion = null)
    {
        var form = new Form
        {
            Title = "საწყისი",
            Status = status,
            RetentionDays = 30,
            CoverImagePath = cover,
            CreatedBy = "nino",
            RowVersion = rowVersion
        };
        form.AccessList.Add(new FormAccess { AdAccount = "nino", AccessLevel = AccessLevel.Manager });

        _db.Forms.Add(form);
        _db.SaveChanges();
        _db.ChangeTracker.Clear();   // რედაქტირება ისე უნდა წავიდეს, როგორც ახალ მოთხოვნაში

        return form;
    }

    private static UpdateFormRequest Update(string? cover = null, string? rowVersion = null) => new(
        "განახლებული", null, null, null, 30, null, cover,
        [new CreateFieldRequest(0, FieldType.ShortAnswer, "სახელი", false, new())],
        rowVersion);

    private FormService Service()
    {
        var user = new TestUser("nino", IsAdministrator: false);
        return new FormService(_db, user, _audit, _storage, new FormAccessGuard(_db, user), new HtmlContent());
    }

    /// <summary>ქავერების სიცოცხლის ციკლი ცალკე სერვისშია — იხ. IFormCoverService.</summary>
    private FormCoverService Covers()
    {
        var user = new TestUser("nino", IsAdministrator: false);
        return new FormCoverService(_db, _storage, new FormAccessGuard(_db, user), _audit);
    }
}
