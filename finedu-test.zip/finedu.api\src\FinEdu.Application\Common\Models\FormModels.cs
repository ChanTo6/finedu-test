﻿using FinEdu.Domain.Enums;
using FinEdu.Domain.ValueObjects;

namespace FinEdu.Application.Common.Models;

// ── ადმინის მხარე ───────────────────────────────────────────────────

/// <summary>
/// შექმნისა და რედაქტირების საერთო, შესამოწმებელი ნაწილი. ორივეს ერთი და იგივე წესები აქვს
/// და ეს ინტერფეისი მათ ერთ ვალიდატორში აერთიანებს — ადრე წესები ორ ფაილში იყო გამეორებული
/// და ერთში შესწორება მეორეს ჩუმად ვერ სწვდებოდა.
///
/// <para>ტიპები თავად განზრახ ცალკე რჩება: რედაქტირებას მომავალში სხვა შეზღუდვები
/// შეიძლება დასჭირდეს (მაგ. retention-ის შეცვლის აკრძალვა გამოქვეყნების შემდეგ).</para>
/// </summary>
public interface IFormDefinitionRequest
{
    string Title { get; }
    int? MaxParticipants { get; }
    int RetentionDays { get; }
    string? PrivacyNoticeHtml { get; }
    List<CreateFieldRequest> Fields { get; }
}

public record CreateFormRequest(
    string Title,
    string? Description,
    DateTimeOffset? CloseDate,
    int? MaxParticipants,
    int RetentionDays,
    string? PrivacyNoticeHtml,
    string? CoverImagePath,
    List<CreateFieldRequest> Fields,
    string? ConfirmationEmailSubject = null,
    string? ConfirmationEmailBody = null) : IFormDefinitionRequest;

public record UpdateFormRequest(
    string Title,
    string? Description,
    DateTimeOffset? CloseDate,
    int? MaxParticipants,
    int RetentionDays,
    string? PrivacyNoticeHtml,
    /// <summary>
    /// <c>null</c> — ქავერი არ იცვლება; ცარიელი სტრიქონი — ცხადი წაშლა;
    /// სახელი — ჩანაცვლება. სამივე შემთხვევა განზრახ განსხვავდება, თორემ
    /// „წაშლა" და „არ შემიცვლია" ერთმანეთისგან ვერ გაირჩეოდა.
    /// </summary>
    string? CoverImagePath,
    List<CreateFieldRequest> Fields,
    /// <summary>
    /// ფორმის ვერსია, რომელიც კლიენტმა ჩატვირთვისას მიიღო. თუ ამ დროში სხვამ
    /// შეცვალა, ცვლილება არ გატარდება და კონფლიქტი დაბრუნდება (იხ. Form.RowVersion).
    /// </summary>
    string? RowVersion = null,
    string? ConfirmationEmailSubject = null,
    string? ConfirmationEmailBody = null) : IFormDefinitionRequest;

/// <summary>ქავერის წასაკითხად — გზა + content type (extension-ის მიხედვით, არა ატვირთულის ნდობით).</summary>
public record CoverImage(Stream Content, string ContentType);

public record CreateFieldRequest(
    int Order,
    FieldType Type,
    string Label,
    bool IsRequired,
    FieldConfig Config,
    /// <summary>ხედავს თუ არა ჟიური ამ ველის პასუხს (იხ. <c>FormField.VisibleToJury</c>).</summary>
    bool VisibleToJury = false);

public record FormDto(
    Guid Id,
    string Title,
    /// <summary>სათაური გაფორმებით — რედაქტორი სწორედ ამას ტვირთავს.</summary>
    string? TitleHtml,
    string? Description,
    DateTimeOffset? CloseDate,
    int? MaxParticipants,
    int RetentionDays,
    string? PrivacyNoticeHtml,
    string? CoverImagePath,
    FormStatus Status,
    string PublicToken,
    List<FormFieldDto> Fields,
    /// <summary>ვერსია კონკურენტული რედაქტირებისთვის — რედაქტირებისას უკან უნდა დაბრუნდეს.</summary>
    string? RowVersion = null,
    string? ConfirmationEmailSubject = null,
    string? ConfirmationEmailBody = null);

public record FormFieldDto(
    Guid Id,
    int Order,
    FieldType Type,
    string Label,
    bool IsRequired,
    FieldConfig Config,
    bool VisibleToJury = false);

public record FormSummaryDto(
    Guid Id,
    string Title,
    FormStatus Status,
    DateTimeOffset? CloseDate,
    int SubmissionCount);

// ── საჯარო მხარე (მხოლოდ Live ფორმა, token-ით) ──────────────────────

// HasCover — მხოლოდ ნიშანი, აქვს თუ არა ქავერი. დისკის რეალური გზა საჯაროდ არასდროს გადის;
// ფოტო ცალკე endpoint-ით გაიცემა token-ის მიხედვით.

/// <summary>გამოცხადებული კონკურსის ჩანაწერი საჯარო კატალოგში (ავტორიზაციის გარეშე).</summary>
public record PublicFormListItemDto(
    string Title,
    string? Description,
    bool HasCover,
    DateTimeOffset? CloseDate,
    string PublicToken);

public record PublicFormDto(
    /// <summary>ტექსტური სათაური — ბრაუზერის ჩანართისა და გაფორმების არარსებობის შემთხვევისთვის.</summary>
    string Title,
    /// <summary>გაფორმებული სათაური გვერდის თავზე. <c>null</c> — ძველი კონკურსი, გაფორმების გარეშე.</summary>
    string? TitleHtml,
    string? Description,
    bool HasCover,
    string? PrivacyNoticeHtml,
    List<FormFieldDto> Fields,
    UploadLimitsDto UploadLimits);

/// <summary>
/// ატვირთვის სერვერული ლიმიტები კლიენტისთვის — რომ ბრაუზერმა ატვირთვამდე გააფრთხილოს.
/// წყარო ერთია (<c>FileUploadPolicy</c>): კლიენტში ხელით გამეორებული რიცხვები დროთა
/// განმავლობაში სერვერისას აუცილებლად აცდებოდა.
/// </summary>
public record UploadLimitsDto(int MaxFilesPerSubmission, IReadOnlyDictionary<string, long> MaxBytesByExtension);
