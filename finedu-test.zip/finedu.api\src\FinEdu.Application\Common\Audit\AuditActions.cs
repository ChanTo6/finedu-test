﻿namespace FinEdu.Application.Common.Audit;

/// <summary>
/// აუდიტის მოქმედებების სრული ლექსიკონი. სტრიქონები ხელით რომ არ იწერებოდეს:
/// ლოგს აპლიკაციიდან ვერავინ კითხულობს (იხ. <c>IAppDbContext</c>), ანუ შემოწმება
/// SQL-ით ხდება — ერთი აკრეფილი ასო მთელ მოქმედებას უხილავს გახდიდა შემმოწმებლისთვის.
///
/// ფორმატი: <c>domain.action</c>, ყველა პატარა ასოთი.
/// </summary>
public static class AuditActions
{
    // ── ავთენტიფიკაცია (ადმინი) ──────────────────────────────────────
    public const string LoginSucceeded = "auth.login";
    public const string LoginFailed = "auth.login.failed";
    public const string Logout = "auth.logout";

    // ── ფორმა/კონკურსი ──────────────────────────────────────────────
    public const string FormCreated = "form.created";
    public const string FormUpdated = "form.updated";
    public const string FormSubmittedForApproval = "form.submitted";
    public const string FormApproved = "form.approved";
    public const string FormClosed = "form.closed";
    public const string FormAutoClosed = "form.autoclosed";
    public const string CoverUploaded = "form.cover.uploaded";

    /// <summary>ობოლი ქავერების ავტომატური წაშლა (ფონური job).</summary>
    public const string CoversPurged = "form.cover.purged";

    /// <summary>ვის მიეცა წვდომა კონკურსზე — ეს უფლების გაცემაა და ჟურნალში უნდა ჩანდეს.</summary>
    public const string FormAccessGranted = "form.access.granted";

    public const string FormAccessRevoked = "form.access.revoked";


    // ── განაცხადი ───────────────────────────────────────────────────
    public const string SubmissionCreated = "submission.created";

    /// <summary>განაცხადების სიის ნახვა — პერსონალურ მონაცემებზე *წვდომაც* აღირიცხება, არა მხოლოდ ცვლილება.</summary>
    public const string SubmissionsViewed = "submission.viewed";

    public const string FileDownloaded = "submission.file.downloaded";
    public const string ExportDownloaded = "submission.exported";

    /// <summary>retention-ის არააღდგენადი წაშლა (ფონური job).</summary>
    public const string RetentionPurged = "submission.retention.purged";

    // ── ჟიური ───────────────────────────────────────────────────────

    /// <summary>ადმინისტრატორმა დაამატა — მაშინვე ძალაშია.</summary>
    public const string JuryAdded = "jury.added";

    /// <summary>მოდერატორმა დაამატა — ადმინისტრატორის დადასტურებას ელოდება.</summary>
    public const string JuryRequested = "jury.requested";

    /// <summary>ადმინისტრატორმა დაადასტურა — აქედან იგზავნება ბმული და PIN.</summary>
    public const string JuryApproved = "jury.approved";

    /// <summary>ადმინისტრატორმა დაუდასტურებელი მოთხოვნა წაშალა.</summary>
    public const string JuryRequestDeleted = "jury.request.deleted";

    public const string JuryInviteResent = "jury.invite.resent";
    public const string JuryActiveChanged = "jury.active.changed";
    public const string JuryUnlocked = "jury.unlocked";
    public const string JuryLoginSucceeded = "jury.login";
    public const string JuryLoginFailed = "jury.login.failed";
    public const string JuryLogout = "jury.logout";
    public const string JuryPinReset = "jury.pin.reset";
    public const string JuryEvaluated = "jury.evaluated";
    public const string JuryFileOpened = "jury.file.opened";

    // ── მომსახურე job-ები ───────────────────────────────────────────
    public const string RevokedTokensPurged = "maintenance.tokens.purged";
}
