using FinEdu.Application.Resources;

namespace FinEdu.Application.Common.Exceptions;

/// <summary>ვალიდაციის შეცდომები (ველი → შეტყობინებები). API 400-ად აბრუნებს.</summary>
public class ValidationException : Exception
{
    public IReadOnlyDictionary<string, string[]> Errors { get; }

    public ValidationException(IDictionary<string, string[]> errors)
        : base(Messages.ValidationFailed)
        => Errors = new Dictionary<string, string[]>(errors);

    public ValidationException(string field, string message)
        : this(new Dictionary<string, string[]> { [field] = new[] { message } }) { }
}

/// <summary>entity ვერ მოიძებნა → 404.</summary>
public class NotFoundException(string name, object key)
    : Exception(Messages.NotFound(name, key));

/// <summary>ბიზნეს-წესის დარღვევა → 409/400.</summary>
public class DomainException(string message) : Exception(message);

/// <summary>ავტორიზებულია, მაგრამ ამ კონკრეტულ მონაცემზე წვდომა არ აქვს → 403.</summary>
public class ForbiddenException(string message) : Exception(message);

/// <summary>
/// ვინაობა ვერ დადასტურდა (მაგ. ჟიურის ბმული/PIN) → 401.
/// შეტყობინება განზრახ ზოგადია — არ უნდა ირკვეოდეს, ბმული იყო არასწორი თუ PIN.
/// </summary>
public class UnauthenticatedException(string message) : Exception(message);

/// <summary>
/// გარე სერვისი (მაგ. ანტივირუსი) მიუწვდომელია → 503.
/// ეს მომხმარებლის შეცდომა არაა: 400-ად დაბრუნება მას აფიქრებინებდა, რომ მისი ფაილი გამოუსადეგარია.
/// </summary>
public class ServiceUnavailableException(string message) : Exception(message);
