import { HttpClient } from '@angular/common/http';
import { Injectable, inject, signal } from '@angular/core';
import { firstValueFrom } from 'rxjs';
import { TextParams, fillText } from 'shared-lib';
import { environment } from '../../../environments/environment';

export type Lang = 'ka' | 'en';

const STORAGE_KEY = 'finedu-lang';

/**
 * საიტის ენა. წარწერები სერვერიდან მოდის (/api/ui-texts/{ka|en}); პირველი ჩატვირთვა
 * აპლიკაციის გაშვებამდე სრულდება (app.config), რომ გვერდი ცარიელი წარწერებით არ დაიხატოს.
 * არჩეული ენა სერვერს ყოველ მოთხოვნაზე მიდის (languageInterceptor) — შეცდომებიც იმავე ენაზე მოდის.
 */
@Injectable({ providedIn: 'root' })
export class I18nService {
  private readonly http = inject(HttpClient);
  private readonly texts = signal<Record<string, string>>({});

  readonly lang = signal<Lang>(this.storedLang());

  /** სერვერი მიუწვდომელია — გვერდი მაინც იხსნება, წარწერების ნაცვლად გასაღებებით. */
  async init(): Promise<void> {
    try {
      await this.load(this.lang());
    } catch {
      // შეცდომას ქვემოთ გვერდები აჩვენებს (კატალოგი, ფორმა) — აქ დამატებით არაფერია საჩვენებელი
    }
  }

  /** ახალი ტექსტი ჩამოდის და მხოლოდ შემდეგ იცვლება — ვერ ჩამოვიდა და ენა ძველი რჩება. */
  async switchTo(lang: Lang): Promise<void> {
    if (lang === this.lang()) return;
    try {
      await this.load(lang);
    } catch {
      return;
    }
    try {
      localStorage.setItem(STORAGE_KEY, lang);
    } catch {
      // საცავი დაბლოკილია — არჩევანი მხოლოდ ამ ვიზიტზე იმოქმედებს
    }
  }

  t(key: string, params?: TextParams): string {
    return fillText(this.texts()[key] ?? key, params);
  }

  private async load(lang: Lang): Promise<void> {
    const texts = await firstValueFrom(
      this.http.get<Record<string, string>>(`${environment.apiUrl}/ui-texts/${lang}`),
    );
    this.texts.set(texts);
    this.lang.set(lang);
    document.documentElement.lang = lang;
    document.title = texts['app.name'] ?? document.title;
  }

  private storedLang(): Lang {
    try {
      return localStorage.getItem(STORAGE_KEY) === 'en' ? 'en' : 'ka';
    } catch {
      return 'ka';
    }
  }
}
