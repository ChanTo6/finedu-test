using FinEdu.Domain.Common;

namespace FinEdu.Domain.Entities;

/// <summary>აუდიტის ჩანაწერი (doc §4 — user/service ლოგირება).</summary>
public class AuditLog : BaseEntity
{
    public string Actor { get; set; } = string.Empty;   // user ან service account
    public string Action { get; set; } = string.Empty;
    public string? EntityType { get; set; }
    public string? EntityId { get; set; }
    public string? Details { get; set; }
    public string? IpAddress { get; set; }

    /// <summary>
    /// ბრაუზერის ანონიმური ნიშანი (cookie). IP იცვლება (მობილური, NAT, საზიარო ქსელი) —
    /// ეს ნიშანი კი ერთი მოწყობილობის მოქმედებებს ერთმანეთს უკავშირებს.
    /// </summary>
    public string? VisitorId { get; set; }

    /// <summary>ბრაუზერის ხელწერა — ავტომატიზებული მოთხოვნების ამოცნობისთვის.</summary>
    public string? UserAgent { get; set; }
}
