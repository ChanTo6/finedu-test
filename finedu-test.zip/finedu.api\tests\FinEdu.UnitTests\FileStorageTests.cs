using FinEdu.Infrastructure.Files;
using FinEdu.Infrastructure.Options;
using Microsoft.Extensions.Options;
using Xunit;

namespace FinEdu.UnitTests;

/// <summary>
/// ფაილსაცავის ბოლო ბარიერი: გზა საკუთარ საქაღალდეებს არ უნდა სცდებოდეს.
///
/// <para>გზას სისტემა თვითონ აგენერირებს და ბაზაში ინახავს, ანუ დღეს მისი გაყალბება
/// გარედან შეუძლებელია. შემოწმება მაინც აქ დგას: სწორედ ვარაუდი „ბაზაში მხოლოდ
/// ჩვენი მონაცემია" ირღვევა ჩუმად მიგრაციის ან იმპორტის შემდეგ, ხოლო ორივე მეთოდი
/// ბაზიდან წაკითხულ სტრიქონს პირდაპირ ფაილურ სისტემას გადასცემს.</para>
/// </summary>
public class FileStorageTests : IDisposable
{
    private readonly string _root = Path.Combine(Path.GetTempPath(), $"finedu-{Guid.NewGuid():N}");
    private readonly FileSystemStorage _storage;

    public FileStorageTests()
    {
        _storage = new FileSystemStorage(Options.Create(new StorageOptions
        {
            QuarantinePath = Path.Combine(_root, "quarantine"),
            PermanentPath = Path.Combine(_root, "permanent"),
            CoverPath = Path.Combine(_root, "covers")
        }));
    }

    public void Dispose()
    {
        if (Directory.Exists(_root)) Directory.Delete(_root, recursive: true);
    }

    [Fact]
    public async Task Stored_file_can_be_read_back()
    {
        var path = await _storage.SaveToQuarantineAsync(new MemoryStream([1, 2, 3]), "a.pdf");

        await using var stream = await _storage.OpenReadAsync(path);

        Assert.Equal(3, stream.Length);
    }

    [Theory]
    [InlineData("../../../windows/win.ini")]
    [InlineData("C:\\Windows\\win.ini")]
    [InlineData("/etc/passwd")]
    [InlineData("")]
    public async Task Path_outside_the_store_is_refused(string path)
    {
        await Assert.ThrowsAsync<UnauthorizedAccessException>(() => _storage.OpenReadAsync(path));
        await Assert.ThrowsAsync<UnauthorizedAccessException>(() => _storage.DeleteAsync(path));
    }

    /// <summary>წაშლა უცნობ გზაზეც უნდა გაჩერდეს — თორემ ბარიერი მხოლოდ ნახევრად იდგა.</summary>
    [Fact]
    public async Task Delete_stays_inside_the_store()
    {
        var outside = Path.Combine(_root, "outside.txt");
        Directory.CreateDirectory(_root);
        await File.WriteAllTextAsync(outside, "x");

        await Assert.ThrowsAsync<UnauthorizedAccessException>(() => _storage.DeleteAsync(outside));

        Assert.True(File.Exists(outside));
    }

    /// <summary>ქავერს იგივე წესი ჰქონდა აქამდეც — ტესტი მას ერთ ადგილას ინახავს.</summary>
    [Theory]
    [InlineData("../secret.png")]
    [InlineData("sub/dir.png")]
    public async Task Cover_name_with_a_path_is_refused(string name)
    {
        await Assert.ThrowsAsync<UnauthorizedAccessException>(() => _storage.OpenCoverAsync(name));
    }
}
