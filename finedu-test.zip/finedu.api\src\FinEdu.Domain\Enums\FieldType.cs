namespace FinEdu.Domain.Enums;

/// <summary>ფორმის ველის ტიპები (doc §3.1). frontend-ის enum-ს იდენტური უნდა იყოს.</summary>
public enum FieldType
{
    ShortAnswer = 1,    // მაქს. 50 სიტყვა
    LongAnswer = 2,     // მაქს. 500 სიტყვა
    MultipleChoice = 3,
    Checkboxes = 4,
    LinearScale = 5,
    FileUpload = 6
}
