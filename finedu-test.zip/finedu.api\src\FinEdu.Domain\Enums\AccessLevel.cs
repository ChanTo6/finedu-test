namespace FinEdu.Domain.Enums;

/// <summary>per-project წვდომის დონე (doc — მონაცემების იზოლაცია).</summary>
public enum AccessLevel
{
    Viewer = 1,     // მხოლოდ ნახვა/ექსპორტი
    Manager = 2     // ფორმის მართვა
}
