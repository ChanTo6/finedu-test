using FinEdu.Application.Common.Models;
using FinEdu.Domain.Entities;

namespace FinEdu.Application.Files;

public interface IFileService
{
    /// <summary>quarantine-ში ინახავს → ClamAV → clean-ს permanent-ში გადააქვს. infected → შლის და აგდებს.</summary>
    Task<SubmissionFile> SaveAndScanAsync(Guid fieldId, SubmissionFileInput input, CancellationToken ct = default);

    /// <summary>ადმინის authenticated download (არასდროს პირდაპირი URL).</summary>
    Task<FileDownload> OpenForDownloadAsync(Guid fileId, CancellationToken ct = default);
}
