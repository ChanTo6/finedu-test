using System.Net;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text.Json;

namespace FinEdu.IntegrationTests;

/// <summary>
/// ფორმის რედაქტირება. ველების ჩანაცვლება EF-ის change tracker-ის დახვეწილ ქცევას ეყრდნობა —
/// ერთხელ უკვე გატყდა (ახალ ველებზე INSERT-ის ნაცვლად UPDATE გენერირდებოდა), ამიტომ ცალკე იფარება.
/// </summary>
public class FormEditingTests(AdminApiFactory factory) : IClassFixture<AdminApiFactory>
{
    private readonly HttpClient _client = factory.CreateClient();

    private async Task AuthorizeAsync()
    {
        var login = await _client.PostAsJsonAsync("/api/auth/login",
            new { username = "tester", password = "test-password" });
        login.EnsureSuccessStatusCode();

        var token = (await login.Content.ReadFromJsonAsync<JsonElement>()).GetProperty("token").GetString();
        _client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
    }

    private static object FormPayload(string title, params string[] fieldLabels) => new
    {
        title,
        retentionDays = 30,
        privacyNoticeHtml = "<p>პირობები</p>",
        fields = fieldLabels.Select((label, i) => new
        {
            order = i,
            type = 1,
            label,
            isRequired = false,
            config = new { }
        }).ToArray()
    };

    private async Task<string> CreateFormAsync(string title, params string[] fieldLabels)
    {
        var response = await _client.PostAsJsonAsync("/api/forms", FormPayload(title, fieldLabels));
        response.EnsureSuccessStatusCode();

        return (await response.Content.ReadFromJsonAsync<JsonElement>()).GetProperty("id").GetString()!;
    }

    [Fact]
    public async Task Update_replaces_fields_and_persists_them()
    {
        await AuthorizeAsync();
        var id = await CreateFormAsync("საწყისი", "ძველი ველი");

        var update = await _client.PutAsJsonAsync($"/api/forms/{id}",
            FormPayload("განახლებული", "ახალი ველი ერთი", "ახალი ველი ორი"));
        Assert.Equal(HttpStatusCode.NoContent, update.StatusCode);

        var reloaded = await _client.GetFromJsonAsync<JsonElement>($"/api/forms/{id}");
        Assert.Equal("განახლებული", reloaded.GetProperty("title").GetString());

        var labels = reloaded.GetProperty("fields").EnumerateArray()
            .Select(f => f.GetProperty("label").GetString() ?? "")
            .ToList();
        Assert.Equal(new List<string> { "ახალი ველი ერთი", "ახალი ველი ორი" }, labels);
    }

    [Fact]
    public async Task Update_of_unknown_form_is_not_found()
    {
        await AuthorizeAsync();

        var response = await _client.PutAsJsonAsync($"/api/forms/{Guid.NewGuid()}", FormPayload("აქ არაფერია", "ველი"));
        Assert.Equal(HttpStatusCode.NotFound, response.StatusCode);
    }
}
