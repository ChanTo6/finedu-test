namespace FinEdu.Application.Export;

public interface IExportService
{
    /// <summary>ფორმის განაცხადების Excel (.xlsx) — თითო ველი ცალკე სვეტი (doc §3.8).</summary>
    Task<byte[]> ExportFormAsync(Guid formId, CancellationToken ct = default);
}
