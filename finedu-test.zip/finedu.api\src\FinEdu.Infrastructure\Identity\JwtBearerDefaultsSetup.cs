using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using FinEdu.Application.Common.Interfaces;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.IdentityModel.Tokens;

namespace FinEdu.Infrastructure.Identity;

/// <summary>
/// ორივე ზონის (ადმინი და ჟიური) JWT-ის ერთნაირი წესები. ადრე ეს ბლოკი ორივე
/// setup-ში სიტყვასიტყვით იყო გამეორებული — ერთში შესწორებული უსაფრთხოების
/// პარამეტრი მეორეში ჩუმად ძველი რჩებოდა.
///
/// <para>განსხვავებული მხოლოდ გასაღები, issuer-ი და audience-ია — სწორედ ისინი,
/// რაც ორ ზონას ერთმანეთისგან მიჯნავს.</para>
/// </summary>
internal static class JwtBearerDefaultsSetup
{
    /// <summary>ვადაგასულ ტოკენს ნაგულისხმევი 5 წუთი ზედმეტად ახანგრძლივებს.</summary>
    private static readonly TimeSpan AllowedClockSkew = TimeSpan.FromSeconds(30);

    public static void Configure(JwtBearerOptions o, byte[] signingKey, string? issuer, string? audience)
    {
        // ნაგულისხმევად claim-ების სახელები ჩუმად ითარგმნება WS-Federation-ის URI-ებად,
        // რის გამოც „jti" სხვა სახელით აღმოჩნდებოდა და გაუქმების შემოწმება ვერ იმუშავებდა.
        o.MapInboundClaims = false;

        o.TokenValidationParameters = new TokenValidationParameters
        {
            ValidateIssuer = true,
            ValidIssuer = issuer,
            ValidateAudience = true,
            ValidAudience = audience,
            ValidateIssuerSigningKey = true,
            IssuerSigningKey = new SymmetricSecurityKey(signingKey),
            ValidateLifetime = true,
            ClockSkew = AllowedClockSkew,
            // მხოლოდ სიმეტრიული ალგორითმი — „alg: none"/RS256-ით ხელმოწერის გაყალბების წინააღმდეგ
            ValidAlgorithms = [SecurityAlgorithms.HmacSha256],
            // mapping გამორთულია — ცხადად ვამბობთ, რომელი claim არის სახელი და რომელი როლი
            NameClaimType = JwtRegisteredClaimNames.UniqueName,
            RoleClaimType = JwtTokenService.RoleClaim
        };

        // ხელმოწერა ვალიდურია, მაგრამ logout-ის შემდეგ ტოკენი აღარ უნდა მუშაობდეს
        o.Events = new JwtBearerEvents
        {
            OnTokenValidated = async ctx =>
            {
                var jti = ctx.Principal?.FindFirstValue(JwtRegisteredClaimNames.Jti);
                if (jti is null)
                {
                    ctx.Fail("ტოკენს jti არ აქვს.");
                    return;
                }

                var store = ctx.HttpContext.RequestServices.GetRequiredService<ITokenRevocationStore>();
                if (await store.IsRevokedAsync(jti, ctx.HttpContext.RequestAborted))
                    ctx.Fail("ტოკენი გაუქმებულია.");
            }
        };
    }
}
