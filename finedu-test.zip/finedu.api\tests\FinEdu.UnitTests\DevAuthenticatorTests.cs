using FinEdu.Application.Common.Security;
using FinEdu.Infrastructure.Identity;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.FileProviders;
using Microsoft.Extensions.Hosting;
using Xunit;

namespace FinEdu.UnitTests;

/// <summary>
/// ლოკალური შესვლა AD-ის გარეშე — ადმინისა და მოდერატორის სატესტო ანგარიშები.
/// მოდერატორს ადმინისტრატორის როლი არასდროს უნდა მოხვდეს: სწორედ მისით მოწმდება
/// ხელით ორდონიანი წესი (მოდერატორი აგზავნის, ადმინი ამტკიცებს).
/// </summary>
public class DevAuthenticatorTests
{
    private sealed class DevEnvironment : IHostEnvironment
    {
        public string EnvironmentName { get; set; } = Environments.Development;
        public string ApplicationName { get; set; } = "Tests";
        public string ContentRootPath { get; set; } = "";
        public IFileProvider ContentRootFileProvider { get; set; } = null!;
    }

    private static DevAuthenticator Create(string? moderatorPassword)
    {
        var config = new ConfigurationBuilder()
            .AddInMemoryCollection(new Dictionary<string, string?>
            {
                ["DevAuth:Username"] = "test",
                ["DevAuth:Password"] = "admin-pass",
                ["DevAuth:Moderator:Username"] = "moderator",
                ["DevAuth:Moderator:Password"] = moderatorPassword
            })
            .Build();

        return new DevAuthenticator(config, new DevEnvironment());
    }

    [Fact]
    public async Task Moderator_account_gets_only_the_moderator_role()
    {
        var user = await Create("mod-pass").AuthenticateAsync("moderator", "mod-pass");

        Assert.NotNull(user);
        Assert.Equal([Roles.Moderator], user.Roles);
    }

    [Fact]
    public async Task Admin_account_is_unchanged_next_to_the_moderator()
    {
        var user = await Create("mod-pass").AuthenticateAsync("test", "admin-pass");

        Assert.NotNull(user);
        Assert.Contains(Roles.Administrator, user.Roles);
        Assert.Contains(Roles.Moderator, user.Roles);
    }

    /// <summary>ერთი ანგარიშის პაროლით მეორეში შესვლა შეუძლებელია.</summary>
    [Fact]
    public async Task Passwords_are_not_interchangeable()
    {
        var auth = Create("mod-pass");

        Assert.Null(await auth.AuthenticateAsync("moderator", "admin-pass"));
        Assert.Null(await auth.AuthenticateAsync("test", "mod-pass"));
    }

    /// <summary>
    /// პაროლის გარეშე მოდერატორი არ ჩაირთვება, ადმინის შესვლა კი არ ფუჭდება — იმ
    /// კომპიუტერზე, სადაც ეს საიდუმლო ჯერ არ დაყენებულა, ყველაფერი ძველებურად მუშაობს.
    /// ცარიელი პაროლი იგივეა, რაც არარსებული: მისით შესვლა არ უნდა გაიხსნოს.
    /// </summary>
    [Theory]
    [InlineData(null)]
    [InlineData("")]
    [InlineData("   ")]
    public async Task Moderator_without_a_password_is_disabled(string? password)
    {
        var auth = Create(password);

        Assert.Null(await auth.AuthenticateAsync("moderator", password ?? ""));
        Assert.NotNull(await auth.AuthenticateAsync("test", "admin-pass"));
    }
}
