using System.Security.Cryptography;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;

namespace FinEdu.Infrastructure.Http;

/// <summary>
/// ყოველ ვიზიტორს ანონიმური, გამოუცნობი ნიშანი ეძლევა — cookie-ს სახით, პირველივე
/// მოთხოვნაზე. ვინაობას არ ადგენს და მომხმარებელს არაფერს ეკითხება, მაგრამ:
///
/// <list type="bullet">
/// <item>ერთი მოწყობილობის მოქმედებებს ერთმანეთს უკავშირებს (IP საზიაროა და ცვალებადი);</item>
/// <item>გაორმაგებული განაცხადის ამოცნობის საშუალებას იძლევა;</item>
/// <item>ინციდენტის შემდეგ კვალის აღდგენას აადვილებს.</item>
/// </list>
///
/// <para>
/// ნიშანი მხოლოდ დამცავ დანიშნულებას ემსახურება (თაღლითობის პრევენცია) — არა
/// ანალიტიკას და არა ტრეკინგს; მისი შინაარსი შემთხვევითი რიცხვია, პიროვნებაზე
/// არაფერს ამბობს. cookie HttpOnly-ია, ანუ გვერდის სკრიპტი მას ვერ კითხულობს.
/// </para>
/// </summary>
public static class VisitorCookie
{
    public const string CookieName = "finedu_vid";
    private const string ItemsKey = "finedu.visitor";

    /// <summary>1 წელი — უფრო ხანმოკლე ვადა გაორმაგებულ განაცხადს ვადის შემდეგ გაატარებდა.</summary>
    private static readonly TimeSpan Lifetime = TimeSpan.FromDays(365);

    public static IApplicationBuilder UseVisitorCookie(this IApplicationBuilder app) =>
        app.Use(async (ctx, next) =>
        {
            var id = ctx.Request.Cookies[CookieName];

            if (!IsValid(id))
            {
                id = Convert.ToHexString(RandomNumberGenerator.GetBytes(16)).ToLowerInvariant();

                // cookie პასუხის გაგზავნის წინ ემატება და არა ახლა: შეცდომის დამმუშავებელი
                // middleware პასუხს ასუფთავებს (Response.Clear()) და ჩვენი header დაიკარგებოდა —
                // ანუ სწორედ ის ვიზიტორი დარჩებოდა უნიშნოდ, ვისი მოთხოვნაც შეცდომით მთავრდება
                // (არასწორი ბმული, 401, ლიმიტის გადაჭარბება) — ესენი ყველაზე საეჭვო ვიზიტებია.
                var newId = id;
                ctx.Response.OnStarting(() =>
                {
                    ctx.Response.Cookies.Append(CookieName, newId, new CookieOptions
                    {
                        HttpOnly = true,            // JavaScript-ისთვის მიუწვდომელი
                        Secure = true,              // მხოლოდ HTTPS-ზე
                        SameSite = SameSiteMode.Lax,
                        IsEssential = true,         // დამცავი დანიშნულება, არა ანალიტიკა
                        Expires = DateTimeOffset.UtcNow.Add(Lifetime),
                        Path = "/"
                    });
                    return Task.CompletedTask;
                });
            }

            // request-ის განმავლობაში ხელმისაწვდომი — ICurrentUser აქედან იღებს
            ctx.Items[ItemsKey] = id;
            await next();
        });

    /// <summary>request-ის ვიზიტორის ნიშანი (middleware-ის შემდეგ ყოველთვის არსებობს).</summary>
    public static string? Current(HttpContext? ctx) => ctx?.Items[ItemsKey] as string;

    /// <summary>
    /// კლიენტს cookie-ს შინაარსი თავისუფლად ეწერება, ამიტომ ფორმატს ვამოწმებთ:
    /// ვალიდაციის გარეშე მოგონილი მნიშვნელობა პირდაპირ ბაზაში ჩავარდებოდა.
    /// </summary>
    private static bool IsValid(string? id) =>
        id is { Length: 32 } && id.All(c => c is >= '0' and <= '9' or >= 'a' and <= 'f');
}
