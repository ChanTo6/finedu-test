﻿using FinEdu.Application.Files;
using FinEdu.Application.Common.Security;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace FinEdu.AdminApi.Controllers;

[ApiController]
[Route("api/files")]
[Authorize(Policy = Roles.Moderator)]
public class FilesController(IFileService files) : ControllerBase
{
    /// <summary>authenticated download — ფაილი web-root-ის გარეთ, stream-ით.</summary>
    [HttpGet("{id:guid}")]
    public async Task<IActionResult> Download(Guid id, CancellationToken ct)
    {
        var file = await files.OpenForDownloadAsync(id, ct);
        return File(file.Content, file.ContentType, file.FileName);
    }
}
