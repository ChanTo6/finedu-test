﻿using FinEdu.Application.Export;
using FinEdu.Application.Files;
using FinEdu.Application.Forms;
using FinEdu.Application.Forms.Validators;
using FluentValidation;
using Microsoft.Extensions.DependencyInjection;

namespace FinEdu.Application;

public static class DependencyInjection
{
    public static IServiceCollection AddApplication(this IServiceCollection services)
    {
        services.AddScoped<Common.Security.IFormAccessGuard, Common.Security.FormAccessGuard>();
        services.AddScoped<IFormService, FormService>();
        services.AddScoped<IFormAccessService, FormAccessService>();
        services.AddScoped<IFormCoverService, FormCoverService>();
        services.AddScoped<Submissions.ISubmissionService, Submissions.SubmissionService>();
        services.AddScoped<IFileService, FileService>();
        services.AddScoped<IExportService, ExportService>();

        services.AddValidatorsFromAssemblyContaining<CreateFormRequestValidator>();
        return services;
    }
}
