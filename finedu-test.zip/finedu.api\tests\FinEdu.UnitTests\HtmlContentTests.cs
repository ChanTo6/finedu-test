﻿using FinEdu.Infrastructure.Security;
using Xunit;

namespace FinEdu.UnitTests;

/// <summary>
/// ადმინის შედგენილი ტექსტი ორ ადგილას გამოჩნდება: საჯარო გვერდზე და წერილში.
/// წერილში Angular-ის sanitizer არ მონაწილეობს, ამიტომ გაწმენდა სერვერზე
/// ერთადერთი რეალური ბარიერია — და სწორედ ეს ტესტები იცავს მას.
/// </summary>
public class HtmlContentTests
{
    private readonly HtmlContent _html = new();

    // ── რა უნდა მოიჭრას ───────────────────────────────────────────

    [Theory]
    [InlineData("<script>alert(1)</script>")]
    [InlineData("<iframe src=\"https://evil.example\"></iframe>")]
    [InlineData("<object data=\"x\"></object>")]
    [InlineData("<style>body{display:none}</style>")]
    public void Dangerous_tags_are_removed(string input)
    {
        var clean = _html.Sanitize($"<p>ტექსტი</p>{input}") ?? "";

        Assert.DoesNotContain("<script", clean, StringComparison.OrdinalIgnoreCase);
        Assert.DoesNotContain("<iframe", clean, StringComparison.OrdinalIgnoreCase);
        Assert.DoesNotContain("<object", clean, StringComparison.OrdinalIgnoreCase);
        Assert.DoesNotContain("<style", clean, StringComparison.OrdinalIgnoreCase);
        Assert.Contains("ტექსტი", clean);
    }

    [Theory]
    [InlineData("<p onclick=\"steal()\">ტექსტი</p>", "onclick")]
    [InlineData("<p onmouseover=\"steal()\">ტექსტი</p>", "onmouseover")]
    [InlineData("<img src=x onerror=\"steal()\">", "onerror")]
    public void Event_handlers_are_removed(string input, string handler)
    {
        var clean = _html.Sanitize(input) ?? "";

        Assert.DoesNotContain(handler, clean, StringComparison.OrdinalIgnoreCase);
    }

    /// <summary>ბმულის სქემა ყველაზე ხშირი გვერდის ავლის გზაა.</summary>
    [Theory]
    [InlineData("javascript:alert(1)")]
    [InlineData("JaVaScRiPt:alert(1)")]
    [InlineData("data:text/html;base64,PHNjcmlwdD4=")]
    public void Dangerous_link_schemes_are_removed(string href)
    {
        var clean = _html.Sanitize($"<a href=\"{href}\">დააჭირე</a>") ?? "";

        Assert.DoesNotContain("javascript", clean, StringComparison.OrdinalIgnoreCase);
        Assert.DoesNotContain("data:", clean, StringComparison.OrdinalIgnoreCase);
    }

    // ── რა უნდა შემორჩეს ──────────────────────────────────────────

    [Fact]
    public void Formatting_the_editor_produces_is_kept()
    {
        const string input =
            "<p><strong>მნიშვნელოვანი</strong> და <em>დახრილი</em> " +
            "<span style=\"color: rgb(230, 0, 0); font-size: 18px;\">ფერადი</span></p>" +
            "<ul><li>პირველი</li><li>მეორე</li></ul>";

        var clean = _html.Sanitize(input) ?? "";

        Assert.Contains("<strong>", clean);
        Assert.Contains("<em>", clean);
        Assert.Contains("color", clean);
        Assert.Contains("font-size", clean);
        Assert.Contains("<li>", clean);
        Assert.Contains("მნიშვნელოვანი", clean);
    }

    /// <summary>ჩვეულებრივი ბმული რჩება, ოღონდ უსაფრთხო ატრიბუტებით.</summary>
    [Fact]
    public void Safe_link_is_kept_and_hardened()
    {
        var clean = _html.Sanitize("<p><a href=\"https://nbg.gov.ge\">ეროვნული ბანკი</a></p>") ?? "";

        Assert.Contains("https://nbg.gov.ge", clean);
        Assert.Contains("noopener", clean);
        Assert.Contains("_blank", clean);
    }

    [Fact]
    public void Empty_input_stays_null()
    {
        Assert.Null(_html.Sanitize(null));
        Assert.Null(_html.Sanitize("   "));

        // მხოლოდ სკრიპტისგან შემდგარი ტექსტი ცარიელი ხდება და არა ცარიელი ტეგი
        Assert.Null(_html.Sanitize("<script>alert(1)</script>"));
    }

    /// <summary>
    /// კლასი არ გადის: გაფორმებას რედაქტორი `style`-ით წერს, კლასი კი ავტორს
    /// ჩვენივე გვერდის გაფორმების ჩამოკიდების საშუალებას მისცემდა.
    /// </summary>
    [Fact]
    public void Class_attribute_is_dropped_but_the_text_stays()
    {
        var clean = _html.Sanitize("<p class=\"topbar\">ტექსტი</p>") ?? "";

        Assert.DoesNotContain("class", clean);
        Assert.Contains("ტექსტი", clean);
    }

    /// <summary>რედაქტორის გამოსავალი სრულად უნდა გადარჩეს — ეს მისი ტიპური სახეა.</summary>
    [Fact]
    public void Editor_output_survives_intact()
    {
        const string html =
            "<p style=\"text-align: center;\"><strong>სათაური</strong></p>" +
            "<ul><li><span style=\"color: rgb(230, 0, 0); font-size: 20px;\">პუნქტი</span></li></ul>";

        var clean = _html.Sanitize(html) ?? "";

        Assert.Contains("text-align", clean);
        Assert.Contains("<strong>", clean);
        Assert.Contains("<ul>", clean);
        Assert.Contains("color", clean);
        Assert.Contains("font-size", clean);
    }

    // ── ტექსტად გადაყვანა (კატალოგის ბარათებისთვის) ───────────────

    [Fact]
    public void Plain_text_strips_tags_and_decodes_entities()
    {
        var text = _html.ToPlainText("<p><b>ფინანსური</b> წიგნიერება &amp; განათლება</p>", 100);

        Assert.Equal("ფინანსური წიგნიერება & განათლება", text);
    }

    [Fact]
    public void Plain_text_is_shortened()
    {
        var text = _html.ToPlainText("<p>" + new string('ა', 200) + "</p>", 50) ?? "";

        Assert.Equal(51, text.Length);   // 50 + „…"
        Assert.EndsWith("…", text);
    }

    /// <summary>დაშიფრული ტეგი ტექსტად გადაყვანისას ხელახლა ტეგი ვერ უნდა გახდეს.</summary>
    [Fact]
    public void Encoded_tags_do_not_reappear()
    {
        var text = _html.ToPlainText("<p>&lt;script&gt;alert(1)&lt;/script&gt;</p>", 200) ?? "";

        // დაშიფვრის მოხსნის შემდეგ ეს ნამდვილი ტეგი ხდება და უნდა მოიჭრას
        Assert.DoesNotContain("<", text);
        Assert.DoesNotContain(">", text);
        Assert.Equal("alert(1)", text);
    }
}
