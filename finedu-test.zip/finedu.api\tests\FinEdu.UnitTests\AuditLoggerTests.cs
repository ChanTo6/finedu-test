using FinEdu.Application.Common.Audit;
using FinEdu.Application.Common.Interfaces;
using FinEdu.Infrastructure.Logging;
using FinEdu.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;
using Xunit;

namespace FinEdu.UnitTests;

/// <summary>
/// აუდიტის ჟურნალი შემმოწმებლის ერთადერთი წყაროა — მასში actor და IP ყოველთვის
/// უნდა იყოს. „system"-ის ნაცვლად ანონიმური მოქალაქე თუ ჩაიწერა, ჟურნალი
/// მოქალაქის მოქმედებას სერვისის მოქმედებად აჩვენებდა.
/// </summary>
public class AuditLoggerTests : IDisposable
{
    private readonly AppDbContext _db;

    private sealed record TestUser(string? Account, string? IpAddress,
        string? VisitorId = null, string? UserAgent = null) : ICurrentUser
    {
        public bool IsAdministrator => false;
    }

    public AuditLoggerTests()
    {
        var options = new DbContextOptionsBuilder<AppDbContext>()
            .UseInMemoryDatabase($"audit-{Guid.NewGuid()}")
            .Options;
        _db = new AppDbContext(options);
    }

    public void Dispose() => _db.Dispose();

    private async Task<Domain.Entities.AuditLog> LogAsync(string? account, string? ip)
    {
        var logger = new AuditLogger(_db, new TestUser(account, ip));
        await logger.LogAsync(AuditActions.SubmissionCreated, "Submission", Guid.NewGuid().ToString(), "form=x");
        return await _db.AuditLogs.AsNoTracking().SingleAsync();
    }

    [Fact]
    public async Task Admin_action_records_account_and_ip()
    {
        var entry = await LogAsync("nchanturia", "10.1.2.3");

        Assert.Equal("nchanturia", entry.Actor);
        Assert.Equal("10.1.2.3", entry.IpAddress);
        Assert.Equal("submission.created", entry.Action);
    }

    /// <summary>საჯარო განაცხადი: ვინაობა არ არის, მაგრამ IP არის — ეს „anonymous"-ია, არა „system".</summary>
    [Fact]
    public async Task Anonymous_citizen_is_not_recorded_as_system()
    {
        var entry = await LogAsync(null, "212.72.155.1");

        Assert.Equal("anonymous", entry.Actor);
        Assert.Equal("212.72.155.1", entry.IpAddress);
    }

    /// <summary>ფონური job — HTTP მოთხოვნა არ არსებობს, ანუ IP-ც არა.</summary>
    [Fact]
    public async Task Background_job_is_recorded_as_system()
    {
        var entry = await LogAsync(null, null);

        Assert.Equal("system", entry.Actor);
        Assert.Null(entry.IpAddress);
    }

    /// <summary>შესვლის მომენტში ვინაობა კონტექსტში ჯერ არ არის — actor ხელით მიეთითება.</summary>
    [Fact]
    public async Task Login_records_the_attempted_account_as_actor()
    {
        var logger = new AuditLogger(_db, new TestUser(null, "10.1.2.3"));

        await logger.LogForActorAsync("mallory", AuditActions.LoginFailed, "Auth");

        var entry = await _db.AuditLogs.AsNoTracking().SingleAsync();
        Assert.Equal("mallory", entry.Actor);
        Assert.Equal("10.1.2.3", entry.IpAddress);
    }

    /// <summary>
    /// actor-ში მომხმარებლის შეყვანილი ტექსტი ხვდება. სვეტზე გრძელი მნიშვნელობა
    /// INSERT-ს ჩააგდებდა — ანუ გრძელი სახელით შესვლა 500-ის გამოწვევის იარაღი გახდებოდა.
    /// </summary>
    [Fact]
    public async Task Overlong_and_control_characters_do_not_break_the_write()
    {
        var logger = new AuditLogger(_db, new TestUser(null, "10.1.2.3"));

        await logger.LogForActorAsync(new string('a', 500) + "\r\nინექცია", AuditActions.LoginFailed, "Auth");

        var entry = await _db.AuditLogs.AsNoTracking().SingleAsync();
        Assert.Equal(256, entry.Actor.Length);
        Assert.DoesNotContain('\n', entry.Actor);
    }

    /// <summary>ჟურნალი დანართია და არა ჟურნალის რედაქტირება: ყოველი ჩანაწერი დროის ბეჭდით ცალკე რიგია.</summary>
    [Fact]
    public async Task Every_action_appends_a_new_row()
    {
        var logger = new AuditLogger(_db, new TestUser("nchanturia", "10.1.2.3"));

        await logger.LogAsync(AuditActions.SubmissionsViewed, "Form", "f1");
        await logger.LogAsync(AuditActions.ExportDownloaded, "Form", "f1");

        var rows = await _db.AuditLogs.AsNoTracking().OrderBy(a => a.CreatedAt).ToListAsync();

        Assert.Equal(2, rows.Count);
        Assert.All(rows, r => Assert.NotEqual(default, r.CreatedAt));
        Assert.Equal([AuditActions.SubmissionsViewed, AuditActions.ExportDownloaded], rows.Select(r => r.Action));
    }
}
