namespace FinEdu.Domain.ValueObjects;

/// <summary>
/// ველის ტიპზე დამოკიდებული კონფიგი. FormField-ში ინახება JSON სვეტად.
/// მხოლოდ შესაბამისი ველები ივსება თითო FieldType-ისთვის.
/// </summary>
public class FieldConfig
{
    // Short / Long answer
    public int? MaxWords { get; set; }

    // MultipleChoice / Checkboxes
    public List<string>? Options { get; set; }

    // LinearScale
    public int? ScaleMin { get; set; }
    public int? ScaleMax { get; set; }
    public string? ScaleMinLabel { get; set; }
    public string? ScaleMaxLabel { get; set; }

    // FileUpload
    public int? MaxFiles { get; set; }
    public List<string>? AllowedExtensions { get; set; }
    public long? MaxFileSizeBytes { get; set; }
}
