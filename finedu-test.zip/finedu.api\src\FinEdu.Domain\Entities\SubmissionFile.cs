using FinEdu.Domain.Common;
using FinEdu.Domain.Enums;

namespace FinEdu.Domain.Entities;

/// <summary>ატვირთული ფაილი. web-root-ის გარეთ ინახება; ClamAV-ს გადის.</summary>
public class SubmissionFile : BaseEntity
{
    public Guid SubmissionId { get; set; }
    public Submission? Submission { get; set; }

    public Guid FieldId { get; set; }

    public string OriginalFileName { get; set; } = string.Empty;
    public string StoredPath { get; set; } = string.Empty;
    public long SizeBytes { get; set; }
    public string ContentType { get; set; } = string.Empty;

    public ScanStatus ScanStatus { get; set; } = ScanStatus.Pending;
}
