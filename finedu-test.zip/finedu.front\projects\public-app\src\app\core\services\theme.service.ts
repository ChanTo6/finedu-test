import { Injectable, signal } from '@angular/core';

export type Theme = 'light' | 'dark';

const STORAGE_KEY = 'finedu-theme';

/**
 * დღის/ღამის რეჟიმი. საწყის მნიშვნელობას public/theme-init.js ადგენს გვერდის დახატვამდე;
 * აქ მხოლოდ გადართვა და დამახსოვრებაა.
 */
@Injectable({ providedIn: 'root' })
export class ThemeService {
  readonly theme = signal<Theme>(
    document.documentElement.getAttribute('data-theme') === 'dark' ? 'dark' : 'light',
  );

  constructor() {
    // სანამ მომხმარებელს თვითონ არ აურჩევია, სისტემის პარამეტრს მივყვებით — გვერდის გახსნის შემდეგაც
    window.matchMedia?.('(prefers-color-scheme: dark)').addEventListener('change', (e) => {
      if (!this.stored()) this.apply(e.matches ? 'dark' : 'light');
    });
  }

  toggle(): void {
    const next: Theme = this.theme() === 'dark' ? 'light' : 'dark';
    this.apply(next);
    try {
      localStorage.setItem(STORAGE_KEY, next);
    } catch {
      // საცავი დაბლოკილია — არჩევანი მხოლოდ ამ ვიზიტზე იმოქმედებს
    }
  }

  private apply(theme: Theme): void {
    document.documentElement.setAttribute('data-theme', theme);
    this.theme.set(theme);
  }

  private stored(): string | null {
    try {
      return localStorage.getItem(STORAGE_KEY);
    } catch {
      return null;
    }
  }
}
