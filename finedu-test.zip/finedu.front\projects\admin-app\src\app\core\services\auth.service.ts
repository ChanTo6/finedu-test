import { HttpClient } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { Observable, catchError, finalize, of, tap } from 'rxjs';
import { environment } from '../../../environments/environment';
import { LoginResponse } from '../models/form-requests';

@Injectable({ providedIn: 'root' })
export class AuthService {
  private readonly http = inject(HttpClient);
  private readonly base = environment.apiUrl;

  private readonly tokenKey = 'finedu_token';
  private readonly rolesKey = 'finedu_roles';

  // sessionStorage — ტოკენი ტაბის დახურვისთანავე ქრება და სხვა ტაბს არ გადაეცემა.
  private readonly store = sessionStorage;

  login(username: string, password: string): Observable<LoginResponse> {
    return this.http
      .post<LoginResponse>(`${this.base}/auth/login`, { username, password })
      .pipe(tap((r) => this.setSession(r)));
  }

  /**
   * მომხმარებლის ინიციატივით გასვლა — სერვერზეც ვაუქმებთ, თორემ ტოკენი
   * ვადის ბოლომდე ვალიდური დარჩებოდა. ლოკალური გასუფთავება ნებისმიერ შემთხვევაში ხდება.
   */
  logout(): Observable<void> {
    return this.http.post<void>(`${this.base}/auth/logout`, {}).pipe(
      catchError(() => of(void 0)),
      finalize(() => this.clearSession()),
    );
  }

  /** ლოკალური გასუფთავება სერვერზე მიმართვის გარეშე — 401-ზე ტოკენი ისედაც აღარ მუშაობს. */
  clearSession(): void {
    this.store.removeItem(this.tokenKey);
    this.store.removeItem(this.rolesKey);
  }

  get token(): string | null {
    return this.store.getItem(this.tokenKey);
  }

  get roles(): string[] {
    const raw = this.store.getItem(this.rolesKey);
    return raw ? (JSON.parse(raw) as string[]) : [];
  }

  isLoggedIn(): boolean {
    return this.token !== null;
  }

  hasRole(role: string): boolean {
    return this.roles.includes(role);
  }

  private setSession(r: LoginResponse): void {
    this.store.setItem(this.tokenKey, r.token);
    this.store.setItem(this.rolesKey, JSON.stringify(r.roles));
  }
}
