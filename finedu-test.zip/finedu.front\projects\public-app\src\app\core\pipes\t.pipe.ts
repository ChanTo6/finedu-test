import { Pipe, PipeTransform, inject } from '@angular/core';
import { TextParams } from 'shared-lib';
import { I18nService } from '../services/i18n.service';

/**
 * `{{ 'landing.title' | t }}`, `{{ 'form.uploading' | t: { percent: 40 } }}`.
 * pure: false — ენის გადართვისას გასაღები იგივე რჩება, შედეგი კი უნდა შეიცვალოს.
 */
@Pipe({ name: 't', pure: false })
export class TPipe implements PipeTransform {
  private readonly i18n = inject(I18nService);

  transform(key: string, params?: TextParams): string {
    return this.i18n.t(key, params);
  }
}
