using FinEdu.Infrastructure.Identity;
using FinEdu.Infrastructure.Options;
using Microsoft.Extensions.Logging.Abstractions;
using Microsoft.Extensions.Options;
using Xunit;

namespace FinEdu.UnitTests;

/// <summary>
/// ავთენტიფიკაციის საზღვრის regression ტესტები — აქ დაშვებული შეცდომა
/// ადმინ-პანელში უცხო ადამიანს შეუშვებდა.
/// </summary>
public class LdapAuthenticatorTests
{
    private static LdapAuthenticator Build(Action<LdapOptions>? configure = null)
    {
        var opts = new LdapOptions
        {
            Host = "dc.example.local",
            Port = 636,
            UseSsl = true,
            BaseDn = "DC=example,DC=local",
            AdminGroup = "FinEdu-Admins",
            StandardGroup = "FinEdu-Users"
        };
        configure?.Invoke(opts);
        return new LdapAuthenticator(Options.Create(opts), NullLogger<LdapAuthenticator>.Instance);
    }

    // ── ცარიელი პაროლი ────────────────────────────────────────────────
    // LDAP-ში ცარიელი პაროლით bind „unauthenticated bind"-ია და სერვერი წარმატებას აბრუნებს.
    // ქსელამდე მისვლის გარეშე უნდა შეწყდეს — თორემ ნებისმიერი username-ით შესვლა გამოვიდოდა.

    [Theory]
    [InlineData("")]
    [InlineData(" ")]
    [InlineData("\t")]
    [InlineData(null)]
    public async Task ცარიელი_პაროლი_უარყოფილია(string? password)
    {
        var result = await Build().AuthenticateAsync("ntchanturia", password!);
        Assert.Null(result);
    }

    [Theory]
    [InlineData("")]
    [InlineData("   ")]
    [InlineData(null)]
    public async Task ცარიელი_მომხმარებელი_უარყოფილია(string? username)
    {
        var result = await Build().AuthenticateAsync(username!, "რეალური-პაროლი");
        Assert.Null(result);
    }

    // ── დაშიფვრა სავალდებულოა ─────────────────────────────────────────

    [Fact]
    public async Task დაშიფვრის_გარეშე_ავთენტიფიკაცია_არ_სრულდება()
    {
        var auth = Build(o =>
        {
            o.UseSsl = false;
            o.UseStartTls = false;
            o.AllowUnencrypted = false;
        });

        await Assert.ThrowsAsync<InvalidOperationException>(
            () => auth.AuthenticateAsync("ntchanturia", "პაროლი"));
    }

    // ── ჯგუფი → როლი ──────────────────────────────────────────────────

    [Fact]
    public void ჯგუფი_სახელით_ემთხვევა_სრულ_DN_ს()
    {
        Assert.True(LdapAuthenticator.IsGroup(
            "CN=FinEdu-Admins,OU=Groups,DC=example,DC=local", "FinEdu-Admins"));
    }

    [Fact]
    public void ჯგუფი_სრული_DN_ით_ემთხვევა()
    {
        const string dn = "CN=FinEdu-Admins,OU=Groups,DC=example,DC=local";
        Assert.True(LdapAuthenticator.IsGroup(dn, dn));
    }

    [Fact]
    public void სხვა_ჯგუფი_არ_ემთხვევა()
    {
        Assert.False(LdapAuthenticator.IsGroup(
            "CN=FinEdu-Users,OU=Groups,DC=example,DC=local", "FinEdu-Admins"));
    }

    /// <summary>პრეფიქსით დამთხვევა ჯგუფის უფლებებს უცხო ჯგუფს გადასცემდა.</summary>
    [Fact]
    public void მსგავსი_სახელის_ჯგუფი_არ_ემთხვევა()
    {
        Assert.False(LdapAuthenticator.IsGroup(
            "CN=FinEdu-Admins-Readonly,OU=Groups,DC=example,DC=local", "FinEdu-Admins"));
    }

    /// <summary>ცარიელი კონფიგი ყველაფერს არ უნდა დაემთხვეს.</summary>
    [Fact]
    public void ცარიელი_კონფიგი_არაფერს_ემთხვევა()
    {
        Assert.False(LdapAuthenticator.IsGroup("CN=FinEdu-Admins,DC=example,DC=local", ""));
        Assert.False(LdapAuthenticator.IsGroup("CN=FinEdu-Admins,DC=example,DC=local", "   "));
    }

    // ── LDAP ფილტრის injection ────────────────────────────────────────

    [Theory]
    [InlineData("*", "\\2a")]
    [InlineData("(", "\\28")]
    [InlineData(")", "\\29")]
    [InlineData("\\", "\\5c")]
    public void ფილტრის_სპეციალური_სიმბოლოები_ეკრანირდება(string input, string expected)
    {
        Assert.Equal(expected, LdapAuthenticator.EscapeFilter(input));
    }

    [Fact]
    public void ფილტრში_injection_მცდელობა_განეიტრალებულია()
    {
        var escaped = LdapAuthenticator.EscapeFilter("admin)(objectClass=*");

        Assert.DoesNotContain('(', escaped);
        Assert.DoesNotContain(')', escaped);
        Assert.DoesNotContain('*', escaped);
    }

    [Fact]
    public void ჩვეულებრივი_მომხმარებელი_უცვლელი_რჩება()
    {
        Assert.Equal("ntchanturia", LdapAuthenticator.EscapeFilter("ntchanturia"));
    }
}
