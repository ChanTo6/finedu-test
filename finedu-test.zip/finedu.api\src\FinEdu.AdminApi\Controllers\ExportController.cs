﻿using FinEdu.Application.Export;
using FinEdu.Application.Common.Security;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace FinEdu.AdminApi.Controllers;

[ApiController]
[Route("api/forms/{formId:guid}/export")]
[Authorize(Policy = Roles.Moderator)]
public class ExportController(IExportService export) : ControllerBase
{
    private const string XlsxMime = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";

    [HttpGet]
    public async Task<IActionResult> Export(Guid formId, CancellationToken ct)
    {
        var bytes = await export.ExportFormAsync(formId, ct);
        return File(bytes, XlsxMime, $"form-{formId}.xlsx");
    }
}
