// დღის/ღამის რეჟიმი გვერდის დახატვამდე — თორემ ღამის რეჟიმში გახსნისას ეკრანი წამით თეთრდებოდა.
// ცალკე ფაილია და არა index.html-ში ჩაწერილი: სერვერის CSP (script-src 'self') inline სკრიპტს ბლოკავს.
(function () {
  var theme = null;
  try {
    theme = localStorage.getItem('finedu-theme');
  } catch (e) {
    // private რეჟიმი ან დაბლოკილი საცავი — სისტემის პარამეტრს მივყვებით
  }
  if (theme !== 'light' && theme !== 'dark') {
    theme = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
  }
  document.documentElement.setAttribute('data-theme', theme);
})();
