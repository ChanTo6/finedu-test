import {
  ApplicationConfig,
  inject,
  provideAppInitializer,
  provideBrowserGlobalErrorListeners,
} from '@angular/core';
import { provideHttpClient, withInterceptors } from '@angular/common/http';
import { provideRouter } from '@angular/router';
import { UI_TEXT } from 'shared-lib';

import { routes } from './app.routes';
import { languageInterceptor } from './core/interceptors/language-interceptor';
import { I18nService } from './core/services/i18n.service';

export const appConfig: ApplicationConfig = {
  providers: [
    provideBrowserGlobalErrorListeners(),
    provideRouter(routes),
    provideHttpClient(withInterceptors([languageInterceptor])),
    provideAppInitializer(() => inject(I18nService).init()),
    {
      provide: UI_TEXT,
      useFactory: () => {
        const i18n = inject(I18nService);
        return i18n.t.bind(i18n);
      },
    },
  ],
};
