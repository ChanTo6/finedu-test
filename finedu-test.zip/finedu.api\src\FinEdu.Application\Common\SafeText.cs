namespace FinEdu.Application.Common;

/// <summary>
/// გარედან მოსული ტექსტის გაწმენდა ბაზაში ჩაწერამდე. სამივე წესი ერთ ადგილას მოვიდა —
/// ადრე იგივე ლოგიკა სამჯერ იყო დაწერილი (აუდიტი, ფაილის სახელი, User-Agent) და
/// სამივეგან ოდნავ განსხვავებულად იქცეოდა.
///
/// <para>რას აკეთებს და რატომ:</para>
/// <list type="bullet">
/// <item><b>საკონტროლო სიმბოლოების მოცილება</b> — ახალი ხაზი ლოგში ერთ ჩანაწერს ორად აჩვენებდა.</item>
/// <item><b>სიგრძის შეზღუდვა</b> — სვეტზე გრძელი მნიშვნელობა INSERT-ს ჩააგდებდა და
/// მომხმარებლის შეცდომა სერვერის შეცდომად (500) გადაიქცეოდა.</item>
/// </list>
/// </summary>
public static class SafeText
{
    /// <summary>გაწმენდილი ტექსტი ან <c>null</c>, თუ გაწმენდის შემდეგ არაფერი დარჩა.</summary>
    public static string? Clean(string? value, int maxLength)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        var cleaned = new string(value.Where(c => !char.IsControl(c)).ToArray()).Trim();
        if (cleaned.Length == 0) return null;

        return cleaned.Length > maxLength ? cleaned[..maxLength] : cleaned;
    }

    /// <summary>
    /// საჩვენებელი ფაილის სახელი: გზის სეგმენტების გარეშე. გრძელ სახელს *ბოლო* ნაწილი რჩება,
    /// რომ გაფართოება არ დაიკარგოს (სახელით ხომ მომხმარებელი ცნობს ფაილს).
    /// </summary>
    public static string FileName(string value, int maxLength = 200)
    {
        var cleaned = Clean(Path.GetFileName(value), int.MaxValue) ?? "file";
        return cleaned.Length > maxLength ? cleaned[^maxLength..] : cleaned;
    }
}
