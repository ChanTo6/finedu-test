﻿using FinEdu.Domain.Common;
using FinEdu.Domain.Enums;

namespace FinEdu.Domain.Entities;

/// <summary>ღონისძიება/კონკურსი. იზოლაციის საზღვარი — per-project წვდომა ამას ებმის.</summary>
public class Form : BaseEntity
{
    /// <summary>
    /// სათაური ჩვეულებრივი ტექსტით. ეს ვერსია მიდის იქ, სადაც გაფორმება ვერ დაიხატება —
    /// წერილის თემაში, Excel-ის ფაილის სახელში, კატალოგის ბარათსა და ჟურნალში.
    /// </summary>
    public string Title { get; set; } = string.Empty;

    /// <summary>
    /// იგივე სათაური გაფორმებით — მხოლოდ კონკურსის საჯარო გვერდისთვის.
    ///
    /// <para>ორივე ერთი და იმავე შევსებული ველიდან იწერება: ორგანიზატორი ერთხელ წერს,
    /// სერვერი კი ტექსტურ ვერსიას თვითონ გამოჰყოფს. ამიტომ ორი სათაური ერთმანეთს
    /// ვერასდროს აცდება.</para>
    /// </summary>
    public string? TitleHtml { get; set; }

    public string? Description { get; set; }
    public string? CoverImagePath { get; set; }

    public DateTimeOffset? CloseDate { get; set; }
    public int? MaxParticipants { get; set; }

    public int RetentionDays { get; set; }
    public DateTimeOffset? RetentionUntil { get; set; }

    public FormStatus Status { get; set; } = FormStatus.Draft;

    /// <summary>
    /// პერს. მონაცემთა დამუშავების პირობები — გაფორმებული ტექსტი, რომელიც ფორმის
    /// შევსებამდე ცალკე ფანჯარაში ჩანს. ჩაწერამდე სერვერზე იწმინდება (იხ. IHtmlContent).
    ///
    /// <para>ორი ცალკე ფაილი (პირობების და პოლიტიკის ატვირთვა) აქ განზრახ აღარ არის:
    /// შეთანხმდა, რომ ტექსტი იქვე უნდა იკითხებოდეს და მისი გახსნის გარეშე თანხმობის
    /// მონიშვნა შეუძლებელი უნდა იყოს — ფაილის ჩამოტვირთვა ამას ვერ უზრუნველყოფდა.</para>
    /// </summary>
    public string? PrivacyNoticeHtml { get; set; }

    // ── ავტო-პასუხი (doc §3.5) ──────────────────────────────────────
    //
    // ტექსტი თითო კონკურსზე იწერება: „მადლობა კონკურსში X მონაწილეობისთვის" და
    // „განაცხადი მიღებულია ეროვნულ ჯილდოზე" ერთი და იგივე ვერ იქნება.
    // ცარიელი = ნაგულისხმევი ტექსტი (იხ. SubmissionService).

    public string? ConfirmationEmailSubject { get; set; }

    /// <summary>გაფორმებული ტექსტი. ჩაწერამდე სერვერზე იწმინდება (იხ. IHtmlContent).</summary>
    public string? ConfirmationEmailBody { get; set; }

    /// <summary>საჯარო ბმულის უნიკალური, გამოუცნობი token.</summary>
    public string PublicToken { get; set; } = Guid.NewGuid().ToString("N");

    public string? ApprovedBy { get; set; }
    public DateTimeOffset? ApprovedAt { get; set; }

    /// <summary>
    /// კონკურენტული რედაქტირების დამცავი. SQL Server-ის <c>rowversion</c>: ყოველ
    /// ცვლილებაზე ავტომატურად იზრდება, ანუ დეველოპერს მისი განახლება არ ავიწყდება.
    ///
    /// <para>კლიენტი მას ფორმასთან ერთად იღებს და რედაქტირებისას უკან აბრუნებს. თუ ამ
    /// დროში სხვამ შეცვალა, UPDATE ვერცერთ სტრიქონს ვერ იპოვის და EF კონფლიქტს იძახებს —
    /// ჩუმი გადაწერის ნაცვლად მომხმარებელი შეტყობინებას იღებს.</para>
    ///
    /// <para><c>null</c> მხოლოდ იმ პროვაიდერზეა შესაძლებელი, რომელიც rowversion-ს არ
    /// აგენერირებს (ტესტების in-memory ბაზა) — იხ. FormService.ApplyExpectedVersion.</para>
    /// </summary>
    public byte[]? RowVersion { get; set; }

    public ICollection<FormField> Fields { get; set; } = new List<FormField>();
    public ICollection<Submission> Submissions { get; set; } = new List<Submission>();
    public ICollection<FormAccess> AccessList { get; set; } = new List<FormAccess>();

    /// <summary>ამ კონკურსის ჟიური — გარე შემფასებლები, AD ანგარიშის გარეშე.</summary>
    public ICollection<Juror> Jurors { get; set; } = new List<Juror>();

    // ── იღებს თუ არა განაცხადებს (doc §3.4) ─────────────────────────
    //
    // ერთი და იგივე წესი სამ ადგილას სჭირდება: საჯარო კატალოგში (რომ დახურული არ გამოჩნდეს),
    // განაცხადის მიღებისას და ავტო-დახურვის job-ში. ადრე სამივეგან ხელით იყო გამეორებული —
    // ერთში შესწორება დანარჩენებს არ ეხებოდა და კატალოგში შეიძლებოდა ისეთი კონკურსი
    // გამოჩენილიყო, რომელიც განაცხადს უკვე აღარ იღებდა.
    //
    // ორი სახე განზრახ: AcceptingSubmissions ბაზაში ითარგმნება (საჯარო კატალოგი),
    // ქვემოთა ორი მეთოდი კი უკვე ჩატვირთულ ობიექტზე მუშაობს (submit და ავტო-დახურვა).
    // ორივეს ერთი და იგივე ორი პირობა უდევს საფუძვლად.

    /// <summary>ვადა ჯერ არ ამოწურულა?</summary>
    public bool IsWithinCloseDate(DateTimeOffset now) => CloseDate is null || CloseDate > now;

    /// <summary>მონაწილეთა ლიმიტს ჯერ არ მიუღწევია?</summary>
    public bool HasFreeCapacity(int submissionCount) =>
        MaxParticipants is null || submissionCount < MaxParticipants;

    /// <summary>
    /// იგივე წესი ბაზისთვის — რიცხვს თვითონ SQL ითვლის, ანუ ყველა განაცხადის ჩატვირთვა
    /// არ სჭირდება. <c>Rejected</c> სტატუსი ლიმიტში არ ითვლება.
    /// </summary>
    public static System.Linq.Expressions.Expression<Func<Form, bool>> AcceptingSubmissions(DateTimeOffset now) =>
        f => f.Status == FormStatus.Live
             && (f.CloseDate == null || f.CloseDate > now)
             && (f.MaxParticipants == null ||
                 f.Submissions.Count(s => s.Status != SubmissionStatus.Rejected) < f.MaxParticipants);
}
