﻿using System.DirectoryServices.Protocols;
using System.Net;
using System.Text;
using FinEdu.Application.Common.Interfaces;
using FinEdu.Application.Common.Security;
using FinEdu.Infrastructure.Options;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace FinEdu.Infrastructure.Identity;

/// <summary>
/// AD/LDAP ავთენტიფიკაცია (System.DirectoryServices.Protocols — cross-platform).
/// AD იუზერები უკვე არსებობს — bind-ს ვამოწმებთ, შემდეგ memberOf-იდან როლს ვადგენთ.
/// </summary>
public class LdapAuthenticator(IOptions<LdapOptions> opts, ILogger<LdapAuthenticator> logger) : IAdAuthenticator
{
    private readonly LdapOptions _opts = opts.Value;

    public Task<AdUser?> AuthenticateAsync(string username, string password, CancellationToken ct = default)
    {
        // ცარიელი პაროლით bind LDAP-ში „unauthenticated bind"-ია და სერვერი წარმატებას აბრუნებს —
        // ანუ არსებული username ცარიელი პაროლით შემოვიდოდა. აქვე ვწყვეტთ.
        if (string.IsNullOrWhiteSpace(username) || string.IsNullOrWhiteSpace(password))
            return Task.FromResult<AdUser?>(null);

        try
        {
            using var conn = new LdapConnection(new LdapDirectoryIdentifier(_opts.Host, _opts.Port))
            {
                AuthType = AuthType.Basic
            };

            // AD-ს LDAPv3 სჭირდება; ნაგულისხმევი v2-ით search ვერ იმუშავებს.
            conn.SessionOptions.ProtocolVersion = 3;

            // არხი bind-ამდე უნდა დაიშიფროს — თორემ პაროლი ღია ტექსტით წავა ქსელში.
            if (_opts.UseSsl)
                conn.SessionOptions.SecureSocketLayer = true;
            else if (_opts.UseStartTls)
                conn.SessionOptions.StartTransportLayerSecurity(null);
            else if (!_opts.AllowUnencrypted)
                throw new InvalidOperationException(
                    "LDAP დაშიფვრის გარეშე გამორთულია. ჩართეთ Ldap:UseSsl ან Ldap:UseStartTls.");

            var bindName = string.Format(_opts.UserDnFormat ?? "{0}", username);
            conn.Bind(new NetworkCredential(bindName, password));   // ჩავარდნა → LdapException

            var (displayName, roles) = LookupUser(conn, username);

            // ჯგუფის გარეშე წვდომა არ ეძლევა: ბანკის ყველა თანამშრომელი ვალიდურად bind-დება,
            // მაგრამ ადმინ-პანელი მხოლოდ დანიშნულ ჯგუფებს ეკუთვნის.
            if (roles.Count == 0)
            {
                logger.LogWarning("LDAP: {User} ვერცერთ დაშვებულ ჯგუფში არ არის", username);
                return Task.FromResult<AdUser?>(null);
            }

            return Task.FromResult<AdUser?>(new AdUser(username, displayName ?? username, roles));
        }
        catch (LdapException ex)
        {
            logger.LogWarning(ex, "LDAP bind ჩავარდა {User}", username);
            return Task.FromResult<AdUser?>(null);
        }
    }

    /// <summary>ავთენტიფიცირებული კავშირით ეძებს მომხმარებელს და ჯგუფებს როლებად თარგმნის.</summary>
    private (string? DisplayName, List<string> Roles) LookupUser(LdapConnection conn, string username)
    {
        var roles = new List<string>();

        if (string.IsNullOrWhiteSpace(_opts.BaseDn))
        {
            logger.LogWarning("LDAP: BaseDn არ არის კონფიგურირებული — ჯგუფები ვერ შემოწმდა");
            return (null, roles);
        }

        var filter = $"(&(objectClass=user)(sAMAccountName={EscapeFilter(username)}))";
        var request = new SearchRequest(_opts.BaseDn, filter, SearchScope.Subtree, "displayName", "memberOf");

        if (conn.SendRequest(request) is not SearchResponse { Entries.Count: > 0 } response)
            return (null, roles);

        var entry = response.Entries[0];
        var displayName = entry.Attributes["displayName"]?[0]?.ToString();

        var groups = entry.Attributes["memberOf"];
        if (groups is null) return (displayName, roles);

        return (displayName, MapRoles(groups.GetValues(typeof(string)).Cast<string>(), _opts));
    }

    /// <summary>
    /// AD ჯგუფები → აპლიკაციის როლები. ეს ის ერთადერთი ადგილია, სადაც წყდება, ვინ არის
    /// ადმინისტრატორი და ვინ მოდერატორი — შესაბამისად ცალკე მეთოდია და ტესტდება
    /// LDAP-თან კავშირის გარეშე (იგივე მიდგომა, რაც <see cref="IsGroup"/>-ზე).
    ///
    /// <para>ჯგუფის სახელები კონფიგშია და AD-ის მხარეს ეკუთვნის; აპლიკაცია მათ
    /// მხოლოდ კითხულობს — ჯგუფის შექმნა ან წევრობის შეცვლა აქედან შეუძლებელია.</para>
    /// </summary>
    internal static List<string> MapRoles(IEnumerable<string> memberOf, LdapOptions opts)
    {
        var roles = new List<string>();

        foreach (var value in memberOf)
        {
            if (IsGroup(value, opts.AdminGroup)) roles.Add(Roles.Administrator);
            if (IsGroup(value, opts.StandardGroup)) roles.Add(Roles.Moderator);
        }

        // ადმინისტრატორი მოდერატორის უფლებებსაც მოიცავს
        if (roles.Contains(Roles.Administrator) && !roles.Contains(Roles.Moderator))
            roles.Add(Roles.Moderator);

        return roles.Distinct().ToList();
    }

    /// <summary>
    /// memberOf სრულ DN-ს აბრუნებს ("CN=FinEdu-Admins,OU=Groups,DC=..").
    /// კონფიგში შეიძლება ეწეროს ან სრული DN, ან მხოლოდ ჯგუფის სახელი.
    /// </summary>
    internal static bool IsGroup(string memberOfDn, string configured)
    {
        if (string.IsNullOrWhiteSpace(configured)) return false;

        if (configured.Contains('='))
            return memberOfDn.Equals(configured, StringComparison.OrdinalIgnoreCase);

        var firstComponent = memberOfDn.Split(',')[0];
        return firstComponent.StartsWith("CN=", StringComparison.OrdinalIgnoreCase) &&
               firstComponent[3..].Equals(configured, StringComparison.OrdinalIgnoreCase);
    }

    /// <summary>RFC 4515 — მომხმარებლის შეყვანილი ტექსტი ფილტრში სპეციალურ სიმბოლოდ არ უნდა იქცეს.</summary>
    internal static string EscapeFilter(string value)
    {
        var sb = new StringBuilder(value.Length);
        foreach (var c in value)
        {
            sb.Append(c switch
            {
                '\\' => "\\5c",
                '*' => "\\2a",
                '(' => "\\28",
                ')' => "\\29",
                '\0' => "\\00",
                '/' => "\\2f",
                _ => c.ToString()
            });
        }
        return sb.ToString();
    }
}
