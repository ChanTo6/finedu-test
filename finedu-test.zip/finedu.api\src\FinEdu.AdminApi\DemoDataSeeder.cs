using FinEdu.Application.Common.Interfaces;
using FinEdu.Domain.Entities;
using FinEdu.Domain.Enums;
using FinEdu.Domain.ValueObjects;
using Microsoft.EntityFrameworkCore;

namespace FinEdu.AdminApi;

/// <summary>
/// ═══════════════════════════════════════════════════════════════════════════
/// სადემონსტრაციო კონკურსები — დროებითი ფაილი, ჩვენებისთვის.
///
/// რას აკეთებს: აპლიკაციის პირველ გაშვებაზე ბაზაში ამატებს 5 გამოცხადებულ
/// (Live) კონკურსს, რომ საჯარო კატალოგი ცარიელი არ იყოს. მონაცემები ნამდვილია —
/// განაცხადის შევსება, გაგზავნა, ადმინში ნახვა და Excel-ექსპორტი სრულად მუშაობს.
///
/// ⚠️ სრულად წასაშლელად:
///     1. წაშალეთ ეს ფაილი
///     2. Program.cs-ში წაშალეთ ერთი ხაზი: await app.SeedDemoDataAsync();
///        (ფაილის წაშლის შემდეგ build სწორედ იმ ხაზზე გაჩერდება და გაჩვენებთ)
///     3. ბაზიდან ჩანაწერების მოსაშორებლად იხ. RemoveAsync მეთოდი ქვემოთ
///
/// უსაფრთხოება: მუშაობს მხოლოდ Development გარემოში. პროდაქშენში გაშვებისას
/// მდუმარედ არაფერს აკეთებს, თუნდაც ხაზი Program.cs-ში დარჩეს.
/// ═══════════════════════════════════════════════════════════════════════════
/// </summary>
public static class DemoDataSeeder
{
    /// <summary>ამ ნიშნით იძებნება დემო ჩანაწერები წაშლისას — რეალურ მონაცემებს არ ეხება.</summary>
    private const string Marker = "demo-seed";

    /// <summary>
    /// ფიქსირებული ID-ები: ხელახლა გაშვებისას იგივე ჩანაწერები უნდა იცნოს,
    /// რომ დუბლიკატები არ დააგროვოს.
    /// </summary>
    private static readonly Guid[] FormIds =
    [
        new("de300001-0000-4000-8000-000000000001"),
        new("de300002-0000-4000-8000-000000000002"),
        new("de300003-0000-4000-8000-000000000003"),
        new("de300004-0000-4000-8000-000000000004"),
        new("de300005-0000-4000-8000-000000000005")
    ];

    public static async Task SeedDemoDataAsync(this WebApplication app)
    {
        if (!app.Environment.IsDevelopment()) return;

        using var scope = app.Services.CreateScope();
        var db = scope.ServiceProvider.GetRequiredService<IAppDbContext>();
        var logger = scope.ServiceProvider.GetRequiredService<ILoggerFactory>()
            .CreateLogger(nameof(DemoDataSeeder));

        try
        {
            if (await db.Forms.AnyAsync(f => f.CreatedBy == Marker)) return;

            foreach (var form in BuildForms()) db.Forms.Add(form);
            await db.SaveChangesAsync();

            logger.LogInformation("დემო კონკურსები დაემატა ({Count} ცალი)", FormIds.Length);
        }
        catch (Exception ex)
        {
            // დემო მონაცემების ჩავარდნამ აპლიკაციის გაშვება არ უნდა შეაფერხოს
            // (მაგ. ბაზა ჯერ არ არსებობს — მიგრაცია ჯერ არ გაშვებულა).
            logger.LogWarning(ex, "დემო კონკურსები ვერ დაემატა — გააგრძელეთ მიგრაციის გაშვების შემდეგ");
        }
    }

    /// <summary>ბაზიდან დემო ჩანაწერების მოცილება. გამოიძახეთ ხელით, როცა აღარ გჭირდებათ.</summary>
    public static async Task RemoveAsync(IAppDbContext db, CancellationToken ct = default)
    {
        var ids = await db.Forms.Where(f => f.CreatedBy == Marker).Select(f => f.Id).ToListAsync(ct);
        if (ids.Count == 0) return;

        // თანმიმდევრობა მნიშვნელოვანია: SubmissionValues → FormFields-ზე Restrict-ია
        var submissionIds = await db.Submissions.Where(s => ids.Contains(s.FormId))
            .Select(s => s.Id).ToListAsync(ct);

        await db.SubmissionValues.Where(v => submissionIds.Contains(v.SubmissionId)).ExecuteDeleteAsync(ct);
        await db.SubmissionFiles.Where(f => submissionIds.Contains(f.SubmissionId)).ExecuteDeleteAsync(ct);
        await db.Submissions.Where(s => ids.Contains(s.FormId)).ExecuteDeleteAsync(ct);
        await db.FormFields.Where(f => ids.Contains(f.FormId)).ExecuteDeleteAsync(ct);
        await db.FormAccessList.Where(a => ids.Contains(a.FormId)).ExecuteDeleteAsync(ct);
        await db.Forms.Where(f => ids.Contains(f.Id)).ExecuteDeleteAsync(ct);
    }

    // ── მონაცემები ──────────────────────────────────────────────────────────

    private static IEnumerable<Form> BuildForms()
    {
        var now = DateTimeOffset.UtcNow;

        yield return NewForm(FormIds[0], now,
            title: "ფინანსური წიგნიერების ოლიმპიადა 2026",
            description: "ეროვნული ოლიმპიადა საშუალო სკოლის მოსწავლეებისთვის. გამარჯვებულები მიიღებენ სტიპენდიას და მოწვეულნი იქნებიან ეროვნულ ბანკში სასწავლო ვიზიტზე.",
            token: "a1b2c3d4e5f60718293a4b5c6d7e8f90",
            closeDate: new DateTimeOffset(2026, 11, 30, 18, 0, 0, TimeSpan.FromHours(4)),
            maxParticipants: 500,
            retentionDays: 365,
            privacyNotice: "<p>განაცხადში მითითებული მონაცემები გამოიყენება მხოლოდ ოლიმპიადის ორგანიზების მიზნით და ინახება კონკურსის დასრულებიდან 1 წლის განმავლობაში.</p>",
            fields:
            [
                Field(0, FieldType.ShortAnswer, "სახელი და გვარი", required: true),
                Field(1, FieldType.ShortAnswer, "სკოლა", required: true),
                Field(2, FieldType.MultipleChoice, "კლასი", required: true,
                    config: new FieldConfig { Options = ["X კლასი", "XI კლასი", "XII კლასი"] }),
                Field(3, FieldType.LongAnswer, "რატომ გსურთ მონაწილეობა?", required: false,
                    config: new FieldConfig { MaxWords = 200 })
            ]);

        yield return NewForm(FormIds[1], now,
            title: "ესეების კონკურსი — ეკონომიკა და საზოგადოება",
            description: "სტუდენტებისთვის. საუკეთესო სამი ნაშრომი გამოქვეყნდება ეროვნული ბანკის ბიულეტენში.",
            token: "b2c3d4e5f60718293a4b5c6d7e8f90a1",
            closeDate: new DateTimeOffset(2026, 10, 15, 23, 59, 0, TimeSpan.FromHours(4)),
            maxParticipants: null,
            retentionDays: 180,
            privacyNotice: "<p>ნაშრომები მოწმდება პლაგიატზე. მონაცემები ინახება 180 დღის განმავლობაში.</p>",
            fields:
            [
                Field(0, FieldType.ShortAnswer, "სახელი და გვარი", required: true),
                Field(1, FieldType.ShortAnswer, "უნივერსიტეტი", required: true),
                Field(2, FieldType.LongAnswer, "ესეს მოკლე აღწერა", required: false,
                    config: new FieldConfig { MaxWords = 150 }),
                Field(3, FieldType.FileUpload, "ესეს ფაილი", required: true,
                    config: new FieldConfig { MaxFiles = 1, AllowedExtensions = ["pdf", "docx"] })
            ]);

        yield return NewForm(FormIds[2], now,
            title: "ზაფხულის სასწავლო პროგრამა",
            description: "ორკვირიანი ინტენსივი ეროვნულ ბანკში — მაკროეკონომიკა, საბანკო ზედამხედველობა და მონეტარული პოლიტიკა. ადგილების რაოდენობა შეზღუდულია.",
            token: "c3d4e5f60718293a4b5c6d7e8f90a1b2",
            closeDate: null,
            maxParticipants: 30,
            retentionDays: 365,
            privacyNotice: null,
            fields:
            [
                Field(0, FieldType.ShortAnswer, "სახელი და გვარი", required: true),
                Field(1, FieldType.MultipleChoice, "საფეხური", required: true,
                    config: new FieldConfig { Options = ["ბაკალავრი", "მაგისტრი", "დოქტორანტი"] }),
                Field(2, FieldType.LongAnswer, "მოტივაციის წერილი", required: true,
                    config: new FieldConfig { MaxWords = 300 }),
                Field(3, FieldType.FileUpload, "CV", required: true,
                    config: new FieldConfig { MaxFiles = 1, AllowedExtensions = ["pdf"] })
            ]);

        yield return NewForm(FormIds[3], now,
            title: "მასწავლებელთა ტრენინგი — ფინანსური განათლება სკოლაში",
            description: "უფასო ტრენინგი საჯარო სკოლის მასწავლებლებისთვის. მონაწილეები მიიღებენ სერტიფიკატს.",
            token: "d4e5f60718293a4b5c6d7e8f90a1b2c3",
            closeDate: new DateTimeOffset(2026, 12, 20, 17, 0, 0, TimeSpan.FromHours(4)),
            maxParticipants: 120,
            retentionDays: 365,
            privacyNotice: null,
            fields:
            [
                Field(0, FieldType.ShortAnswer, "სახელი და გვარი", required: true),
                Field(1, FieldType.ShortAnswer, "სკოლა და ქალაქი", required: true),
                Field(2, FieldType.Checkboxes, "რომელი თემები გაინტერესებთ?", required: true,
                    config: new FieldConfig
                    {
                        Options =
                        [
                            "ბიუჯეტის დაგეგმვა", "დანაზოგი", "კრედიტი და ვალდებულებები",
                            "ინვესტიციები", "ციფრული უსაფრთხოება"
                        ]
                    }),
                Field(3, FieldType.LinearScale, "როგორ შეაფასებდით საკუთარ გამოცდილებას ამ სფეროში?", required: true,
                    config: new FieldConfig
                    {
                        ScaleMin = 1, ScaleMax = 5,
                        ScaleMinLabel = "დამწყები", ScaleMaxLabel = "გამოცდილი"
                    })
            ]);

        yield return NewForm(FormIds[4], now,
            title: "ვიდეორგოლების კონკურსი „ფული და მე\"",
            description: "შექმენით 60-წამიანი ვიდეორგოლი ფინანსური გადაწყვეტილებების შესახებ. კონკურსი ღიაა 14-დან 25 წლამდე ასაკის მონაწილეებისთვის.",
            token: "e5f60718293a4b5c6d7e8f90a1b2c3d4",
            closeDate: new DateTimeOffset(2026, 9, 30, 23, 59, 0, TimeSpan.FromHours(4)),
            maxParticipants: 200,
            retentionDays: 180,
            privacyNotice: "<p>გამოგზავნილი ვიდეო შეიძლება გამოყენებულ იქნას ეროვნული ბანკის საგანმანათლებლო მასალებში ავტორის მითითებით.</p>",
            fields:
            [
                Field(0, FieldType.ShortAnswer, "სახელი და გვარი", required: true),
                Field(1, FieldType.ShortAnswer, "ასაკი", required: true),
                Field(2, FieldType.LongAnswer, "ვიდეოს იდეის აღწერა", required: false,
                    config: new FieldConfig { MaxWords = 100 }),
                Field(3, FieldType.FileUpload, "ვიდეორგოლი", required: true,
                    config: new FieldConfig { MaxFiles = 1, AllowedExtensions = ["mp4", "mov"] })
            ]);
    }

    // ── დამხმარეები ─────────────────────────────────────────────────────────

    private static Form NewForm(
        Guid id, DateTimeOffset now, string title, string description, string token,
        DateTimeOffset? closeDate, int? maxParticipants, int retentionDays,
        string? privacyNotice, List<FormField> fields) => new()
        {
            Id = id,
            Title = title,
            Description = description,
            PublicToken = token,
            CloseDate = closeDate,
            MaxParticipants = maxParticipants,
            RetentionDays = retentionDays,
            PrivacyNoticeHtml = privacyNotice,
            // უკვე დამტკიცებული და გამოცხადებული — საჯარო კატალოგში მაშინვე ჩანს
            Status = FormStatus.Live,
            ApprovedBy = Marker,
            ApprovedAt = now,
            CreatedAt = now,
            CreatedBy = Marker,
            Fields = fields
        };

    private static FormField Field(int order, FieldType type, string label, bool required,
        FieldConfig? config = null) => new()
        {
            Order = order,
            Type = type,
            Label = label,
            IsRequired = required,
            Config = config ?? new FieldConfig(),
            CreatedBy = Marker
        };
}
