﻿using FinEdu.Application.Common.Models;
using FinEdu.Application.Common.Validation;
using FinEdu.Application.Common.Security;
using FinEdu.Application.Forms;
using FluentValidation;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace FinEdu.AdminApi.Controllers;

[ApiController]
[Route("api/forms")]
[Authorize(Policy = Roles.Moderator)]
public class FormsController(
    IFormService forms,
    IFormCoverService covers,
    IValidator<CreateFormRequest> createValidator,
    IValidator<UpdateFormRequest> updateValidator) : ControllerBase
{
    [HttpGet]
    public async Task<IActionResult> List(CancellationToken ct)
        => Ok(await forms.ListAsync(ct));

    [HttpGet("{id:guid}")]
    public async Task<IActionResult> Get(Guid id, CancellationToken ct)
        => Ok(await forms.GetByIdAsync(id, ct));

    [HttpPost]
    public async Task<IActionResult> Create([FromBody] CreateFormRequest request, CancellationToken ct)
    {
        (await createValidator.ValidateAsync(request, ct)).ThrowIfInvalid();

        var id = await forms.CreateAsync(request, ct);
        return CreatedAtAction(nameof(Get), new { id }, new { id });
    }

    /// <summary>ქავერ ფოტოს ატვირთვა — აბრუნებს გზას, რომელიც ფორმის შენახვისას იგზავნება.</summary>
    [HttpPost("cover")]
    [RequestSizeLimit(12_000_000)] // 10MB სურათი + overhead
    public async Task<IActionResult> UploadCover(IFormFile file, CancellationToken ct)
    {
        if (file is null || file.Length == 0)
            return BadRequest(new { message = "ფაილი არ არის არჩეული." });

        await using var stream = file.OpenReadStream();
        // უკან ბრუნდება მხოლოდ ფაილის სახელი — სერვერის გზა კლიენტამდე არასდროს მიდის
        var coverName = await covers.UploadAsync(stream, file.FileName, file.Length, ct);
        return Ok(new { coverName });
    }

    /// <summary>
    /// უკვე ატვირთული ქავერის ნახვა. ფაილი web-root-ის გარეთაა, ამიტომ stream-ით მიეწოდება —
    /// ისევე, როგორც საჯარო მხარეს (იგივე შემოწმებები, სხვა წვდომის წესი).
    /// </summary>
    [HttpGet("{id:guid}/cover")]
    public async Task<IActionResult> Cover(Guid id, CancellationToken ct)
    {
        var cover = await covers.GetForFormAsync(id, ct);
        Response.Headers["X-Content-Type-Options"] = "nosniff";   // ბრაუზერმა ტიპი არ „გამოიცნოს"
        return File(cover.Content, cover.ContentType);
    }

    [HttpPut("{id:guid}")]
    public async Task<IActionResult> Update(Guid id, [FromBody] UpdateFormRequest request, CancellationToken ct)
    {
        (await updateValidator.ValidateAsync(request, ct)).ThrowIfInvalid();

        await forms.UpdateAsync(id, request, ct);
        return NoContent();
    }

    [HttpPost("{id:guid}/submit")]
    public async Task<IActionResult> SubmitForApproval(Guid id, CancellationToken ct)
    {
        await forms.SubmitForApprovalAsync(id, ct);
        return NoContent();
    }

    // მე-2 დონე — მხოლოდ Administrator
    [HttpPost("{id:guid}/approve")]
    [Authorize(Policy = Roles.Administrator)]
    public async Task<IActionResult> Approve(Guid id, CancellationToken ct)
    {
        await forms.ApproveAsync(id, ct);
        return NoContent();
    }

    [HttpPost("{id:guid}/close")]
    public async Task<IActionResult> Close(Guid id, CancellationToken ct)
    {
        await forms.CloseAsync(id, ct);
        return NoContent();
    }
}
