namespace FinEdu.Application.Common.Models;

/// <summary>საჯარო ფორმის შევსება (values + GDPR თანხმობა). ფაილები ცალკე მოდის (SubmissionFileInput).</summary>
public record CreateSubmissionRequest(
    List<SubmissionValueInput> Values,
    bool ConsentDataProcessing,
    string? NotificationEmail);

public record SubmissionValueInput(Guid FieldId, string? Value);

/// <summary>ატვირთული ფაილი — controller-ი IFormFile-იდან ავსებს.</summary>
public class SubmissionFileInput
{
    public Guid FieldId { get; set; }
    public required Stream Content { get; set; }
    public required string FileName { get; set; }
    public required string ContentType { get; set; }
    public long SizeBytes { get; set; }
}

/// <summary>
/// ადმინის ხედი. <c>SameDeviceCount</c>/<c>SameNetworkCount</c> ეჭვიან განმეორებას აჩვენებს —
/// IP და მოწყობილობის ნიშანი თავად ინტერფეისში *არ* გამოდის: ადმინს რიცხვი და გაფრთხილება
/// კმარა, ტექნიკური კვალი კი აუდიტის ჟურნალშია.
/// </summary>
public record SubmissionDto(
    Guid Id,
    DateTimeOffset SubmittedAt,
    bool ConsentDataProcessing,
    List<SubmissionValueDto> Values,
    List<SubmissionFileDto> Files,
    int SameDeviceCount,
    int SameNetworkCount);

public record SubmissionValueDto(Guid FieldId, string Label, string? Value);

public record SubmissionFileDto(Guid Id, Guid FieldId, string OriginalFileName, long SizeBytes);

public record FileDownload(Stream Content, string FileName, string ContentType);
