using FinEdu.Application.Common;
using FinEdu.Application.Common.Interfaces;
using FinEdu.Domain.Entities;
using FinEdu.Infrastructure.Persistence;

namespace FinEdu.Infrastructure.Logging;

/// <summary>
/// აუდიტის ჩანაწერს ბაზაში წერს (doc §4 — user/service ლოგირება).
///
/// <para>
/// კონკრეტულ <see cref="AppDbContext"/>-ზეა დამოკიდებული და არა <see cref="IAppDbContext"/>-ზე:
/// ჟურნალის DbSet აბსტრაქციიდან განზრახ ამოღებულია, რომ აპლიკაციის სხვა არცერთ კლასს
/// მისი წაკითხვის საშუალება არ ჰქონდეს. context იგივე scoped ინსტანციაა, ანუ ჩანაწერი
/// გამომძახებლის ტრანზაქციაშივე ჯდება.
/// </para>
/// </summary>
public class AuditLogger(AppDbContext db, ICurrentUser currentUser) : IAuditLogger
{
    /// <summary>ვინაობის გარეშე მოქმედი მოქალაქე (მაგ. საჯარო განაცხადი) — მისი კვალი IP-ია.</summary>
    private const string Anonymous = "anonymous";

    /// <summary>ფონური job — HTTP მოთხოვნა არ არსებობს, ანუ IP-ც არ არის.</summary>
    private const string System = "system";

    public Task LogAsync(string action, string? entityType = null, string? entityId = null,
        string? details = null, CancellationToken ct = default) =>
        // „system" მხოლოდ მაშინ, როცა HTTP მოთხოვნა არ არის. ანონიმური მოქალაქე
        // „system"-ად რომ ჩაწერილიყო, ჟურნალში მისი მოქმედება სერვისისად ჩანდა.
        Write(currentUser.Account ?? (currentUser.IpAddress is null ? System : Anonymous),
            action, entityType, entityId, details, ct);

    public Task LogForActorAsync(string actor, string action, string? entityType = null,
        string? entityId = null, string? details = null, CancellationToken ct = default) =>
        Write(actor, action, entityType, entityId, details, ct);

    private async Task Write(string actor, string action, string? entityType, string? entityId,
        string? details, CancellationToken ct)
    {
        db.AuditLogs.Add(new AuditLog
        {
            Actor = SafeText.Clean(actor, 256) ?? Anonymous,
            Action = action,
            EntityType = entityType,
            EntityId = SafeText.Clean(entityId, 64),
            Details = SafeText.Clean(details, 2000),
            IpAddress = SafeText.Clean(currentUser.IpAddress, 64),
            VisitorId = SafeText.Clean(currentUser.VisitorId, 64),
            UserAgent = SafeText.Clean(currentUser.UserAgent, 512)
        });

        // შეცდომას განზრახ არ ვიჭერთ: თუ ჟურნალში ჩაწერა ჩავარდა, მოქმედებაც უნდა ჩავარდეს.
        await db.SaveChangesAsync(ct);
    }

}
