using System.Net;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text.Json;

namespace FinEdu.IntegrationTests;

/// <summary>
/// Object-level authorization: id-ის შეცვლა სხვის მონაცემებამდე არ უნდა მიგვიყვანოს.
///
/// <para>ეს ტესტები ცალკეა იმიტომ, რომ ისინი *ყველა* id-იან endpoint-ს გადის — სწორედ
/// ასე ჩანს, თუ რომელიმე ახალ endpoint-ს შემოწმება დაავიწყდა. მოდერატორად ვმუშაობთ:
/// ადმინისტრატორს ყველა კონკურსზე წვდომა აქვს და ის ამ საზღვარს ვერ გამოცდიდა.</para>
/// </summary>
public class IdorTests : IAsyncLifetime
{
    private readonly ModeratorApiFactory _factory = new();
    private HttpClient _client = null!;
    private ForeignForm _foreign = null!;

    public async Task InitializeAsync()
    {
        _client = _factory.CreateClient();

        var login = await _client.PostAsJsonAsync("/api/auth/login",
            new { username = "tester", password = "test-password" });
        login.EnsureSuccessStatusCode();

        var body = await login.Content.ReadFromJsonAsync<JsonElement>();
        _client.DefaultRequestHeaders.Authorization =
            new AuthenticationHeaderValue("Bearer", body.GetProperty("token").GetString());

        _foreign = await _factory.SeedForeignFormAsync();
    }

    public Task DisposeAsync()
    {
        _factory.Dispose();
        return Task.CompletedTask;
    }

    /// <summary>
    /// კითხვის ყველა გზა სხვის კონკურსზე. 403 და არა 404: არსებობასა და „სხვისს"
    /// შორის განსხვავება თავად კონკურსის არსებობას ამხელდა.
    /// </summary>
    [Theory]
    [InlineData("")]
    [InlineData("/cover")]
    [InlineData("/submissions")]
    [InlineData("/export")]
    [InlineData("/jury")]
    [InlineData("/access")]
    public async Task Reading_someone_elses_contest_is_forbidden(string suffix)
    {
        var response = await _client.GetAsync($"/api/forms/{_foreign.FormId}{suffix}");

        Assert.Equal(HttpStatusCode.Forbidden, response.StatusCode);
    }

    /// <summary>შედეგების endpoint ცალკე მარშრუტზეა — მასაც იგივე შემოწმება სჭირდება.</summary>
    [Fact]
    public async Task Reading_someone_elses_scores_is_forbidden()
    {
        var response = await _client.GetAsync($"/api/forms/{_foreign.FormId}/scores");

        Assert.Equal(HttpStatusCode.Forbidden, response.StatusCode);
    }

    /// <summary>ცვლილების ყველა გზა სხვის კონკურსზე.</summary>
    [Theory]
    [InlineData("/submit")]
    [InlineData("/close")]
    public async Task Changing_someone_elses_contest_is_forbidden(string suffix)
    {
        var response = await _client.PostAsync($"/api/forms/{_foreign.FormId}{suffix}", null);

        Assert.Equal(HttpStatusCode.Forbidden, response.StatusCode);
    }

    [Fact]
    public async Task Editing_someone_elses_contest_is_forbidden()
    {
        var response = await _client.PutAsJsonAsync($"/api/forms/{_foreign.FormId}", new
        {
            title = "გატაცებული",
            retentionDays = 30,
            privacyNoticeHtml = "<p>პირობები</p>",
            fields = new[] { new { order = 0, type = 1, label = "ველი", isRequired = false, config = new { } } }
        });

        Assert.Equal(HttpStatusCode.Forbidden, response.StatusCode);
    }

    /// <summary>
    /// ფაილი კონკურსზე წვდომით მოწმდება და არა მხოლოდ id-ით — მარტო id-ის ცოდნა
    /// განმცხადებლის დოკუმენტს არ უნდა ხსნიდეს.
    /// </summary>
    [Fact]
    public async Task Downloading_someone_elses_file_is_forbidden()
    {
        var response = await _client.GetAsync($"/api/files/{_foreign.FileId}");

        Assert.Equal(HttpStatusCode.Forbidden, response.StatusCode);
    }

    /// <summary>ჟიურის მართვა სხვის კონკურსზე — ყველა მოქმედება.</summary>
    [Fact]
    public async Task Managing_someone_elses_jury_is_forbidden()
    {
        var add = await _client.PostAsJsonAsync($"/api/forms/{_foreign.FormId}/jury",
            new { email = "j@example.com", displayName = "ჟ" });
        Assert.Equal(HttpStatusCode.Forbidden, add.StatusCode);

        var resend = await _client.PostAsync(
            $"/api/forms/{_foreign.FormId}/jury/{_foreign.JurorId}/resend", null);
        Assert.Equal(HttpStatusCode.Forbidden, resend.StatusCode);

        var unlock = await _client.PostAsync(
            $"/api/forms/{_foreign.FormId}/jury/{_foreign.JurorId}/unlock", null);
        Assert.Equal(HttpStatusCode.Forbidden, unlock.StatusCode);

        var active = await _client.PostAsJsonAsync(
            $"/api/forms/{_foreign.FormId}/jury/{_foreign.JurorId}/active", new { isActive = false });
        Assert.Equal(HttpStatusCode.Forbidden, active.StatusCode);
    }

    /// <summary>წვდომების სიის შეცვლა სხვის კონკურსზე.</summary>
    [Fact]
    public async Task Changing_someone_elses_access_list_is_forbidden()
    {
        var grant = await _client.PostAsJsonAsync($"/api/forms/{_foreign.FormId}/access",
            new { adAccount = "tester", accessLevel = 2 });
        Assert.Equal(HttpStatusCode.Forbidden, grant.StatusCode);

        var revoke = await _client.DeleteAsync(
            $"/api/forms/{_foreign.FormId}/access/{_foreign.AccessId}");
        Assert.Equal(HttpStatusCode.Forbidden, revoke.StatusCode);
    }

    /// <summary>
    /// სხვისი ჩანაწერის id საკუთარ კონკურსზე — მარშრუტი „ჩემია", ობიექტი კი არა.
    /// ეს ის შემთხვევაა, რომელსაც მხოლოდ formId-ის შემოწმება გამოტოვებდა.
    /// </summary>
    [Fact]
    public async Task Foreign_access_row_cannot_be_revoked_through_own_contest()
    {
        var created = await _client.PostAsJsonAsync("/api/forms", new
        {
            title = "ჩემი კონკურსი",
            retentionDays = 30,
            privacyNoticeHtml = "<p>პირობები</p>",
            fields = new[] { new { order = 0, type = 1, label = "ველი", isRequired = false, config = new { } } }
        });
        created.EnsureSuccessStatusCode();
        var myFormId = (await created.Content.ReadFromJsonAsync<JsonElement>()).GetProperty("id").GetString();

        var response = await _client.DeleteAsync($"/api/forms/{myFormId}/access/{_foreign.AccessId}");

        Assert.Equal(HttpStatusCode.NotFound, response.StatusCode);
    }
}
