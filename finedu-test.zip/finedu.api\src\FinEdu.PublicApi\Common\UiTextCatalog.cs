using System.Collections;
using System.Globalization;
using System.Security.Cryptography;
using System.Text;
using System.Text.Encodings.Web;
using System.Text.Json;
using System.Text.Unicode;
using FinEdu.PublicApi.Resources;

namespace FinEdu.PublicApi.Common;

/// <summary>
/// ინტერფეისის ტექსტი ერთ JSON-ად თითო ენაზე. resx deploy-ის შემდეგ აღარ იცვლება, ამიტომ
/// JSON და მისი ETag გაშვებისას ერთხელ იწყობა და მეხსიერებაში რჩება.
/// </summary>
public sealed class UiTextCatalog
{
    public static readonly IReadOnlyList<string> Languages = ["ka", "en"];

    // ქართული ასოები \uXXXX-ად არ უნდა გადაიქცეს (JSON სამჯერ გაიზრდებოდა);
    // HTML-ის სპეციალური სიმბოლოები კი ისევ ესკეიპდება.
    private static readonly JsonSerializerOptions JsonOpts = new()
    {
        Encoder = JavaScriptEncoder.Create(UnicodeRanges.All),
    };

    private readonly Dictionary<string, Entry> _byLanguage =
        Languages.ToDictionary(l => l, Build, StringComparer.Ordinal);

    public sealed record Entry(IReadOnlyDictionary<string, string> Texts, string Json, string ETag);

    public Entry? Find(string language) => _byLanguage.GetValueOrDefault(language);

    /// <summary>ქართული ფაილის ყველა გასაღები — ინგლისურში გამოტოვებული ქართულად დაბრუნდებოდა.</summary>
    public static IReadOnlyList<string> Keys() =>
        UiTexts.Resources.GetResourceSet(CultureInfo.InvariantCulture, createIfNotExists: true, tryParents: false)!
            .Cast<DictionaryEntry>()
            .Select(e => (string)e.Key)
            .Order(StringComparer.Ordinal)
            .ToList();

    private static Entry Build(string language)
    {
        var culture = CultureInfo.GetCultureInfo(language);
        var texts = Keys().ToDictionary(k => k, k => UiTexts.Resources.GetString(k, culture) ?? "");
        var json = JsonSerializer.Serialize(texts, JsonOpts);
        var hash = Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(json)))[..16];
        return new Entry(texts, json, $"\"{hash}\"");
    }
}
