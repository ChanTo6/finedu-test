﻿using System.Net;
using System.Text.RegularExpressions;
using FinEdu.Application.Common.Interfaces;
using Ganss.Xss;

namespace FinEdu.Infrastructure.Security;

/// <summary>
/// HTML-ის გაწმენდა allowlist-ით (Ganss.Xss). დაშვებულია მხოლოდ ის, რაც რედაქტორს
/// სჭირდება — გამუქება, ფერი, ასოს ზომა, სია, ბმული. ყველაფერი დანარჩენი იჭრება.
///
/// <para>allowlist და არა blocklist: აკრძალულების ჩამოთვლა ყოველთვის არასრულია,
/// დაშვებულების კი — სასრული და შესამოწმებელი.</para>
/// </summary>
public class HtmlContent : IHtmlContent
{
    /// <summary>ტეგებს შორის საზღვარი ტექსტად გადაყვანისას — თორემ სიტყვები ერთმანეთს მიეწებება.</summary>
    private static readonly Regex Tags = new("<[^>]+>", RegexOptions.Compiled);
    private static readonly Regex Spaces = new(@"\s+", RegexOptions.Compiled);

    private readonly HtmlSanitizer _sanitizer = Build();

    private static HtmlSanitizer Build()
    {
        var s = new HtmlSanitizer();

        s.AllowedTags.Clear();
        foreach (var tag in new[]
                 {
                     "p", "br", "b", "strong", "i", "em", "u", "s",
                     "ul", "ol", "li", "blockquote",
                     "h1", "h2", "h3", "h4",
                     "span", "a"
                 })
        {
            s.AllowedTags.Add(tag);
        }

        // `class` განზრახ არ არის დაშვებული: რედაქტორი გაფორმებას `style`-ით წერს
        // (იხ. frontend RichTextEditor), კლასი კი ავტორს ჩვენივე გვერდის გაფორმების
        // ჩამოკიდების საშუალებას მისცემდა.
        s.AllowedAttributes.Clear();
        s.AllowedAttributes.Add("style");
        s.AllowedAttributes.Add("href");
        s.AllowedAttributes.Add("title");
        s.AllowedAttributes.Add("target");
        s.AllowedAttributes.Add("rel");

        s.AllowedCssProperties.Clear();
        foreach (var css in new[] { "color", "background-color", "font-size", "text-align", "font-weight" })
            s.AllowedCssProperties.Add(css);

        // მხოლოდ ეს სქემები: javascript: და data: სწორედ აქ იჭრება
        s.AllowedSchemes.Clear();
        s.AllowedSchemes.Add("http");
        s.AllowedSchemes.Add("https");
        s.AllowedSchemes.Add("mailto");

        // გარე ბმული ახალ ფანჯარაში და opener-ის გარეშე — გახსნილ გვერდს ჩვენს
        // ტაბზე წვდომა არ უნდა ჰქონდეს (reverse tabnabbing)
        s.PostProcessNode += (_, e) =>
        {
            if (e.Node is AngleSharp.Html.Dom.IHtmlAnchorElement a)
            {
                a.SetAttribute("target", "_blank");
                a.SetAttribute("rel", "noopener noreferrer");
            }
        };

        return s;
    }

    public string? Sanitize(string? html)
    {
        if (string.IsNullOrWhiteSpace(html)) return null;

        var clean = _sanitizer.Sanitize(html).Trim();
        return clean.Length == 0 ? null : clean;
    }

    public string? ToPlainText(string? html, int maxLength)
    {
        if (string.IsNullOrWhiteSpace(html)) return null;

        // ჯერ დაშიფვრის მოხსნა, მერე ტეგების მოცილება. შებრუნებული თანმიმდევრობა
        // „&lt;script&gt;"-ს ჯერ ტეგებისგან ასუფთავებდა (არაფერს პოულობდა), მერე კი
        // ნამდვილ „<script>"-ად აქცევდა — ანუ ტექსტი მარკირებით გამოდიოდა.
        var text = Spaces.Replace(Tags.Replace(WebUtility.HtmlDecode(html), " "), " ").Trim();
        if (text.Length == 0) return null;

        return text.Length > maxLength ? text[..maxLength].TrimEnd() + "…" : text;
    }
}
