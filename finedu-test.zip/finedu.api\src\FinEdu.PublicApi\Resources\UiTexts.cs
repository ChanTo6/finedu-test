using System.Resources;

namespace FinEdu.PublicApi.Resources;

/// <summary>
/// საჯარო საიტის ინტერფეისის ტექსტი: ქართული <c>UiTexts.resx</c>-ში, ინგლისური <c>UiTexts.en.resx</c>-ში.
/// ახალი წარწერა ორივე ფაილში ემატება — ერთ-ერთის გამოტოვებას ტესტი იჭერს (UiTextCatalogTests).
/// </summary>
public static class UiTexts
{
    public static readonly ResourceManager Resources = new(typeof(UiTexts));
}
